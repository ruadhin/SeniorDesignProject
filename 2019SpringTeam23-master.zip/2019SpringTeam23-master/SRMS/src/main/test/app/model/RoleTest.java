package app.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;

/**
 * Tests Role class.
 * @author Prem Subedi
 *
 */
public class RoleTest {
	
	@Test
	public void testDefaultRole() {
		Role role = new Role();
		assertNotNull(role);
	}
	
	@Test
	public void testNamedRole() {
		Role r = new Role("Account Manager");
		assertEquals("Account Manager", r.getName());
	}
	
	@Test
	public void testEmptyRole() {
		Role role = new Role();
		assertNull(role.getId());
		assertNull(role.getName());
		assertNull(role.getPrivileges());
		assertNull(role.getUsers());
	}
	
	@Test
	public void testRole() {
		Role role = new Role("ITRMA34", "IT Risk Officer", true);
		assertEquals("ITRMA34", role.getId());
		assertEquals("IT Risk Officer", role.getName());
		assertTrue(role.isMerckEmployee());
		
		Collection<User> ulist = new ArrayList<User>();
		Collection<Privilege> plist = new ArrayList<Privilege>();
		role.setUsers(ulist);
		assertEquals(ulist, role.getUsers());
		role.setPrivileges(plist);
		assertEquals(plist, role.getPrivileges());
		
		
	}

}
