package app.model.forms;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

/**
 * Tests InitialEngagementFactors class.
 * @author Prem Subedi
 *
 */
public class InitialEngagementFactorsTest {
	
	private List<String> serviceType = new ArrayList<String>();
    private String       serviceTypeOther = "Other types";
    private String       serviceTypeOtherText = "Other service types";
    private String       cloudHosted = "Cloud hosted";
    private String       cloudProvider = "Cloud provider";
    private String       cloudProviderOtherText = "Cloud provider other text";
    private String       approval = "approved";
    private String       approvalDate = "04/23/2019";
    
    @Test
    public void testInitialEngagementFactors() {
    	InitialEngagementFactors ief = new InitialEngagementFactors();
    	assertNotNull(ief);
    	
    	//Testing getters and setters
    	
    	ief.setApproval(approval);
    	assertFalse(ief.isComplete());
    	ief.setApprovalDate(approvalDate);
    	assertFalse(ief.isComplete());
    	ief.setCloudHosted(cloudHosted);
    	assertFalse(ief.isComplete());
    	ief.setCloudProvider(cloudProvider);
    	assertFalse(ief.isComplete());
    	ief.setCloudProviderOtherText(cloudProviderOtherText);
    	assertFalse(ief.isComplete());
    	ief.setServiceType(serviceType);
    	assertFalse(ief.isComplete());
    	ief.setServiceTypeOther(serviceTypeOther);
    	assertFalse(ief.isComplete());
    	ief.setServiceTypeOtherText(serviceTypeOtherText);
    	
    	assertEquals(approval, ief.getApproval());
    	assertEquals(approvalDate, ief.getApprovalDate());
    	assertEquals(cloudHosted, ief.getCloudHosted());
    	assertEquals(cloudProvider, ief.getCloudProvider());
    	assertEquals(cloudProviderOtherText, ief.getCloudProviderOtherText());
    	assertEquals(serviceType, ief.getServiceType());
    	assertEquals(serviceTypeOther, ief.getServiceTypeOther());
    	assertEquals(serviceTypeOtherText, ief.getServiceTypeOtherText());
    	
    	//Testing boolean method isComplete
    	serviceType.add("Standard");
    	assertTrue(ief.isComplete());
    	
    	
    	ief.setCloudHosted("Yes");
    	ief.setCloudProvider(null);
    	assertFalse(ief.isComplete());
    	
    	ief.setCloudProvider(cloudProvider);
    	ief.setApproval(null);
    	assertFalse(ief.isComplete());
    	ief.setApproval(approval);
    	ief.setApprovalDate(null);
    	assertFalse(ief.isComplete());
    	ief.setApproval(null);
    	assertFalse(ief.isComplete());
    	
    	ief.setCloudProvider("Other");
    	ief.setCloudProviderOtherText(null);
    	ief.setApproval(approval);
    	ief.setApprovalDate(approvalDate);
    	assertFalse(ief.isComplete());
    	
    	ief.setCloudProvider(cloudProvider);
    	
    	assertTrue(ief.isComplete());
    	
    	ief.setCloudHosted(null);
    	assertFalse(ief.isComplete());
    	
    	
    	
    	
    	
    	
    	
    }

}
