package app.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

/**
 * Tests Supplier model class
 * @author Prem Subedi
 *
 */
public class SupplierTest {
	List<Supplier> list = new ArrayList<Supplier>();

    @Test
    public void testEmptySupplier () {
        Supplier s = new Supplier();
        assertNotNull( s.getScopingQuestions().getAccessAuthentication() );
        assertNotNull( s.getScopingQuestions().getInformationDataElements() );
        assertNotNull( s.getScopingQuestions().getInitialEngagementFactors() );
        assertNotNull( s.getScopingQuestions().getLegalRequirements() );
        assertNotNull( s.getScopingQuestions().getSeverityRiskQuestions() );
        assertNull( s.getId() );
        assertNull( s.getName() );
        assertNull( s.getParentCompany() );
    }

    @Test
    public void testSupplier () {
        Supplier s = new Supplier();
        s.setName( "Google USA" );
        s.setID("Google123");
        s.setParentCompany( "Google" );
        s.setText("Hello");
        s.setDescription("description");
        s.setDUNS(1234L);
        s.setIcon("icon");
        s.setNodes(list);
        s.setRiskAssessmentStatus(3);
        s.setRiskAssessmentStatusColor("Red");
        s.setRiskRating("High");
        s.setRiskRatingColor("Yellow");
        s.setType("Great");
        
        s.setItrmaOverrideUsername("itrmaOverride");
        s.setItrmaOverrode(true);
        s.setOldRiskRating("high");
        s.setOverrideable(false);
        s.setOverrideJustification("New changes");
        
        assertEquals("itrmaOverride", s.getItrmaOverrideUsername());
        assertEquals("high", s.getOldRiskRating());
        assertTrue(s.isItrmaOverrode());
        assertFalse(s.isOverrideable());
        assertEquals("New changes", s.getOverrideJustification());
        
        
        assertEquals( "Google USA", s.getName() );
        assertEquals( "Google", s.getParentCompany() );
        s.setName( "Amazon" );
        assertEquals( "Amazon", s.getName() );
        assertEquals("Amazon", s.getText());
        
        assertEquals("Google123", s.getId());
        assertEquals("description", s.getDescription());
        assertEquals(1234L, s.getDUNS());
        //assertEquals("icon", s.getIcon());
        assertEquals(list, s.getNodes());
        assertEquals(3, s.getRiskAssessmentStatus());
        assertEquals("Red", s.getRiskAssessmentStatusColor());
        assertEquals("High", s.getRiskRating());
        assertEquals("Yellow", s.getRiskRatingColor());
        assertEquals("Great", s.getType());
        
        try {
        	s.setParentCompany("None");
        	assertEquals("grandparentCompany", s.getType());
        } catch (Exception e) {
        	//Do nothing
        }
        
        try {
        	s.setType("project");
        	assertEquals("glyphicon glyphicon-file", s.getIcon());
        } catch (Exception e) {
        	fail();
        	assertEquals("", s.getIcon());
        }
        
        
        s.setRiskRating("Critical");
        assertEquals("red", s.getRiskRatingColor());
        
        s.setRiskRating("Medium");
        assertEquals("yellow", s.getRiskRatingColor());
        
        s.setRiskRating("Low");
        assertEquals("GreenYellow", s.getRiskRatingColor());
        
        
        //Testing setRiskAssessmentStatus()
        try {
        	s.setRiskAssessmentStatus(45);
        	assertEquals("danger", s.getRiskAssessmentStatusColor());
        	
        	s.setRiskAssessmentStatus(95);
        	assertEquals("warning", s.getRiskAssessmentStatusColor());
        	
        	s.setRiskAssessmentStatus(100);
        	assertEquals("success", s.getRiskAssessmentStatusColor());
        	
        } catch (Exception e) {
        	fail();
        }
        
        s.setRiskAssessmentStatus(100);
        s.getScopingQuestions().setComplete(true);
        assertEquals("Low", s.getRiskRating());
        
        
        
    }

}
