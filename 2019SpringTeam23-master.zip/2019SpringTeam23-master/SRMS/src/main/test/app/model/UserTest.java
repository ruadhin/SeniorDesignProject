package app.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;

/**
 * Tests User POJO class.
 * @author Prem Subedi
 *
 */
public class UserTest {
	
	@Test
	public void userTest() {
		User user = new User();
		assertNotNull(user);
		assertNull(user.getEmail());
		assertNull(user.getFirstName());
		assertNull(user.getID());
		assertNull(user.getLastName());
		assertNull(user.getPassword());
		assertNull(user.getRoles());
		assertNotNull(user.getSupplierIds());	
	}
	
	@Test
	public void userConstructorTest() {
		Collection<Role> role = new ArrayList<Role>();
		User user = new User("itrma", "itr1234", role);
		assertEquals("itrma", user.getUsername());
		assertEquals("itr1234", user.getPassword());
		user.setEmail("busown@merck.com");
		user.setFirstName("Gabriel");
		user.setID("IBM");
		user.setLastName("Subedi");
		user.setRoles(role);
		user.setUsername("Prem");
		
		assertEquals("busown@merck.com", user.getEmail());
		assertEquals("Gabriel", user.getFirstName());
		assertEquals("IBM", user.getID());
		assertEquals("Subedi", user.getLastName());
		assertEquals("Prem", user.getUsername());
		assertEquals(role, user.getRoles());
		
		user.setPassword("pksubedi1234");
		assertEquals("pksubedi1234", user.getPassword());
		assertTrue(user.isAccountNonExpired());
		assertTrue(user.isAccountNonLocked());
		assertTrue(user.isCredentialsNonExpired());
		assertTrue(user.isEnabled());
	   	
	}
	
	@Test
	public void testAddSupplierId() {
		User user = new User();
		user.addSupplier("Amazon");
		assertTrue(user.getSupplierIds().contains("Amazon"));
	}
	
	@Test
	public void testToString() {
		Collection<Role> role = new ArrayList<Role>();
		User user = new User("itrma", "itr1234", role);
		
		user.setID("IBM");
		user.setEmail("busown@merck.com");
		user.setFirstName("Gabriel");
		user.setLastName("Subedi");
		
		assertEquals("itrma:IBM:busown@merck.com:Gabriel:Subedi", user.toString());
		
	}

}
