package app.model.forms;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Tests SeverityRiskQuestions class.
 * @author Prem Subedi
 *
 */
public class SeverityRiskQuestionsTest {
	String financial = "financial";
	String reputational = "reputational";
	String legalRegulatoryContractual = "legalRContractual";
	String customerOperational = "customerOperational";
	
	@Test
	public void testGettersAndSetters() {
		SeverityRiskQuestions srq = new SeverityRiskQuestions();
		
		assertFalse(srq.isComplete());
		srq.setCustomerOperational(customerOperational);
		assertFalse(srq.isComplete());
		srq.setFinancial(financial);
		assertFalse(srq.isComplete());
		srq.setLegalRegulatoryContractual(legalRegulatoryContractual);
		assertFalse(srq.isComplete());
		srq.setReputational(reputational);
		assertTrue(srq.isComplete());
		
		assertEquals(customerOperational, srq.getCustomerOperational());
		assertEquals(financial, srq.getFinancial());
		assertEquals("legalRContractual", srq.getLegalRegulatoryContractual());
		assertEquals(reputational, srq.getReputational());
		
		srq.setFinancial(null);
		assertFalse(srq.isComplete());
		
		srq.setFinancial(financial);
		assertTrue(srq.isComplete());
		
		srq.setCustomerOperational(null);
		assertFalse(srq.isComplete());
		
		srq.setCustomerOperational(customerOperational);
		assertTrue(srq.isComplete());
		srq.setLegalRegulatoryContractual(null);
		assertFalse(srq.isComplete());
		
		
	}

}
