package app.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

// import java.awt.List;
import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.springframework.security.core.GrantedAuthority;

/**
 * Tests MongoUserDetails class.
 *
 * @author Prem Subedi
 *
 */
public class MongoUserDetailsTest {

    @Test
    @SuppressWarnings ( "unchecked" )
    public <E> void testUserDetails () {
        Collection< ? extends GrantedAuthority> list = (Collection< ? extends GrantedAuthority>) new ArrayList<E>();
       
        
        MongoUserDetails mud = new MongoUserDetails( "pksubedi", "password", true, true, true, false, list );
        assertNull( mud.getID() );
        mud.setID( "ITRMA" );
        assertEquals( "ITRMA", mud.getID() );
        assertEquals( "pksubedi", mud.getUsername() );
        assertEquals( "password", mud.getPassword() );
        assertTrue( mud.isEnabled() );
        assertFalse( mud.isAccountNonLocked() );
        assertTrue( mud.isAccountNonExpired() );
        assertTrue( mud.isCredentialsNonExpired() );
        assertEquals( list, mud.getAuthorities() );
        mud.setUsername( "username" );
        mud.setPassword( "pass13456" );
        assertEquals( "username", mud.getUsername() );
        assertEquals( "pass13456", mud.getPassword() );
        assertEquals( "null", mud.getRoleName() );
        
    }

}
