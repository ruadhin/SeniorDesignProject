package app.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.Test;

import app.model.forms.AccessAuthentication;
import app.model.forms.InformationDataElements;
import app.model.forms.InitialEngagementFactors;
import app.model.forms.LegalRequirements;
import app.model.forms.SeverityRiskQuestions;

public class SupplierFormsTest {

    @Test
    public void testEmptySupplier () {
        Supplier s = new Supplier();
        assertNotNull( s.getScopingQuestions().getAccessAuthentication() );
        assertNotNull( s.getScopingQuestions().getInformationDataElements() );
        assertNotNull( s.getScopingQuestions().getInitialEngagementFactors() );
        assertNotNull( s.getScopingQuestions().getLegalRequirements() );
        assertNotNull( s.getScopingQuestions().getSeverityRiskQuestions() );
    }

    @Test
    public void testAccessAuthentication () {
        Supplier s = new Supplier();
        AccessAuthentication aa = new AccessAuthentication();

        aa.setAccessMethod( "Merck Intranet" );
        aa.setAuthenticationMethod( "None" );
        aa.setBrandImage( "No" );
        aa.setCustomerPublicAccess( "Information Sent" );
        aa.setDataIntegrity( "Yes" );
        aa.setWebAddress( "google.com" );
        s.getScopingQuestions().setAccessAuthentication( aa );

        assertEquals( "Merck Intranet", s.getScopingQuestions().getAccessAuthentication().getAccessMethod() );
        assertEquals( "None", s.getScopingQuestions().getAccessAuthentication().getAuthenticationMethod() );
        assertEquals( "No", s.getScopingQuestions().getAccessAuthentication().getBrandImage() );
        assertEquals( "Information Sent", s.getScopingQuestions().getAccessAuthentication().getCustomerPublicAccess() );
        assertEquals( "Yes", s.getScopingQuestions().getAccessAuthentication().getDataIntegrity() );
        assertEquals( "google.com", s.getScopingQuestions().getAccessAuthentication().getWebAddress() );
    }

    @Test
    public void testInformationDataElements () {
        Supplier s = new Supplier();
        InformationDataElements ide = new InformationDataElements();

        List<String> biometrics = Stream.of( " Photographic Facial Images or Facial Geometry", " Voiceprint" )
                .collect( Collectors.toList() );
        ide.setBiometricIdentifiers( biometrics );
        List<String> confidential = Stream.of( " Merck Intellectual Property (IP)", " Financial Information" )
                .collect( Collectors.toList() );
        ide.setConfidentialInfo( confidential );
        List<String> countries = Stream.of( " China", " England", " Singapore" ).collect( Collectors.toList() );
        ide.setCountriesOfResidence( countries );
        List<String> financial = Stream.of( " Financial Account Number", " Pre-Paid Card Number" )
                .collect( Collectors.toList() );
        ide.setFinancialInfo( financial );
        List<String> general = Stream.of( " Mother's Maiden Name", " Gender" ).collect( Collectors.toList() );
        ide.setGeneralInfo( general );
        List<String> govmt = Stream.of( " Tax Identification Number", " Military ID Number" )
                .collect( Collectors.toList() );
        ide.setGovernmentInfo( govmt );
        List<String> merck = Stream.of(
                " Restricted - Information that is intended for a very limited group of individuals who should be specified by name." )
                .collect( Collectors.toList() );
        ide.setMerckInfo( merck );
        ide.setMerckNetwork( "Yes" );
        ide.setNetworkInfo( "Other" );
        ide.setNetworkInfoOtherText( "Other text test 123" );
        ide.setNumberOfRecords( "100-499" );
        List<String> sensitive = Stream.of( " Racial or Ethnic Origin", " Sexual Orientation" )
                .collect( Collectors.toList() );
        ide.setSensitiveInfo( sensitive );
        List<String> technical = Stream.of( " None of the above" ).collect( Collectors.toList() );
        ide.setTechnicalIdentifiers( technical );
        List<String> whoseInfo = Stream.of( " Customers", " Health Care Practitioner" ).collect( Collectors.toList() );
        ide.setWhoseInformation( whoseInfo );

        s.getScopingQuestions().setInformationDataElements( ide );

        assertEquals( " Photographic Facial Images or Facial Geometry",
                s.getScopingQuestions().getInformationDataElements().getBiometricIdentifiers().get( 0 ) );
        assertEquals( " Voiceprint",
                s.getScopingQuestions().getInformationDataElements().getBiometricIdentifiers().get( 1 ) );
        assertEquals( " Merck Intellectual Property (IP)",
                s.getScopingQuestions().getInformationDataElements().getConfidentialInfo().get( 0 ) );
        assertEquals( " Financial Information",
                s.getScopingQuestions().getInformationDataElements().getConfidentialInfo().get( 1 ) );
        assertEquals( " China",
                s.getScopingQuestions().getInformationDataElements().getCountriesOfResidence().get( 0 ) );
        assertEquals( " England",
                s.getScopingQuestions().getInformationDataElements().getCountriesOfResidence().get( 1 ) );
        assertEquals( " Singapore",
                s.getScopingQuestions().getInformationDataElements().getCountriesOfResidence().get( 2 ) );
        assertEquals( " Financial Account Number",
                s.getScopingQuestions().getInformationDataElements().getFinancialInfo().get( 0 ) );
        assertEquals( " Pre-Paid Card Number",
                s.getScopingQuestions().getInformationDataElements().getFinancialInfo().get( 1 ) );
        assertEquals( " Mother's Maiden Name",
                s.getScopingQuestions().getInformationDataElements().getGeneralInfo().get( 0 ) );
        assertEquals( " Gender", s.getScopingQuestions().getInformationDataElements().getGeneralInfo().get( 1 ) );
        assertEquals( " Tax Identification Number",
                s.getScopingQuestions().getInformationDataElements().getGovernmentInfo().get( 0 ) );
        assertEquals( " Military ID Number",
                s.getScopingQuestions().getInformationDataElements().getGovernmentInfo().get( 1 ) );
        assertEquals(
                " Restricted - Information that is intended for a very limited group of individuals who should be specified by name.",
                s.getScopingQuestions().getInformationDataElements().getMerckInfo().get( 0 ) );
        assertEquals( "Yes", s.getScopingQuestions().getInformationDataElements().getMerckNetwork() );
        assertEquals( "Other", s.getScopingQuestions().getInformationDataElements().getNetworkInfo() );
        assertEquals( "Other text test 123",
                s.getScopingQuestions().getInformationDataElements().getNetworkInfoOtherText() );
        assertEquals( "100-499", s.getScopingQuestions().getInformationDataElements().getNumberOfRecords() );
        assertEquals( " Racial or Ethnic Origin",
                s.getScopingQuestions().getInformationDataElements().getSensitiveInfo().get( 0 ) );
        assertEquals( " Sexual Orientation",
                s.getScopingQuestions().getInformationDataElements().getSensitiveInfo().get( 1 ) );
        assertEquals( " None of the above",
                s.getScopingQuestions().getInformationDataElements().getTechnicalIdentifiers().get( 0 ) );
        assertEquals( " Customers",
                s.getScopingQuestions().getInformationDataElements().getWhoseInformation().get( 0 ) );
        assertEquals( " Health Care Practitioner",
                s.getScopingQuestions().getInformationDataElements().getWhoseInformation().get( 1 ) );
    }

    @Test
    public void testInitialEngagementFactors () {
        Supplier s = new Supplier();
        InitialEngagementFactors ief = new InitialEngagementFactors();

        ief.setApproval( "No" );
        ief.setApprovalDate( "2019-04-27" );
        ief.setCloudHosted( "No" );
        ief.setCloudProvider( "AWS" );
        List<String> serviceType = Stream.of(
                " Application Service Provider (ASP) - Service providing hosted software solution (e.g. ASP, SaaS (Software as a Service)" )
                .collect( Collectors.toList() );
        ief.setServiceType( serviceType );
        s.getScopingQuestions().setInitialEngagementFactors( ief );

        assertEquals( "No", s.getScopingQuestions().getInitialEngagementFactors().getApproval() );
        assertEquals( "2019-04-27", s.getScopingQuestions().getInitialEngagementFactors().getApprovalDate() );
        assertEquals( "No", s.getScopingQuestions().getInitialEngagementFactors().getCloudHosted() );
        assertEquals( "AWS", s.getScopingQuestions().getInitialEngagementFactors().getCloudProvider() );
        assertEquals(
                " Application Service Provider (ASP) - Service providing hosted software solution (e.g. ASP, SaaS (Software as a Service)",
                s.getScopingQuestions().getInitialEngagementFactors().getServiceType().get( 0 ) );
    }

    @Test
    public void testLegalRequirements () {
        Supplier s = new Supplier();
        LegalRequirements lr = new LegalRequirements();

        lr.setLegalScope( "HIPAA" );
        lr.setPciImpact( "Write" );
        lr.setRecoveryPoint( "More than 72 hrs" );
        lr.setRecoveryTime( "No recovery plan" );

        s.getScopingQuestions().setLegalRequirements( lr );

        assertEquals( "HIPAA", s.getScopingQuestions().getLegalRequirements().getLegalScope() );
        assertEquals( "Write", s.getScopingQuestions().getLegalRequirements().getPciImpact() );
        assertEquals( "More than 72 hrs", s.getScopingQuestions().getLegalRequirements().getRecoveryPoint() );
        assertEquals( "No recovery plan", s.getScopingQuestions().getLegalRequirements().getRecoveryTime() );
    }

    @Test
    public void testSeverityRiskQuestions () {
        Supplier s = new Supplier();
        SeverityRiskQuestions srq = new SeverityRiskQuestions();

        srq.setCustomerOperational( "4" );
        srq.setFinancial( "3" );
        srq.setLegalRegulatoryContractual( "2" );
        srq.setReputational( "1" );

        s.getScopingQuestions().setSeverityRiskQuestions( srq );

        assertEquals( "4", s.getScopingQuestions().getSeverityRiskQuestions().getCustomerOperational() );
        assertEquals( "3", s.getScopingQuestions().getSeverityRiskQuestions().getFinancial() );
        assertEquals( "2", s.getScopingQuestions().getSeverityRiskQuestions().getLegalRegulatoryContractual() );
        assertEquals( "1", s.getScopingQuestions().getSeverityRiskQuestions().getReputational() );
    }

}
