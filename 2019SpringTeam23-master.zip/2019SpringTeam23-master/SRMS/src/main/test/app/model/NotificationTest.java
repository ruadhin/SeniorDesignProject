package app.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class NotificationTest {

    @Test
    public void testEmptyNotification () {
        Notification n = new Notification();
        assertNotNull( n );
    }

    @Test
    public void testNotification () {
        Notification n = new Notification();
        n.setSender( "Gabriel" );
        n.setReceiver( "Prem" );
        n.setSubject( "How are you?" );
        n.setMessage( "This is the message of the notification." );
        n.setRead( false );
        assertEquals( "Gabriel", n.getSender() );
        assertEquals( "Prem", n.getReceiver() );
        assertEquals( "How are you?", n.getSubject() );
        assertEquals( "This is the message of the notification.", n.getMessage() );
        assertFalse( n.isRead() );

        n.setMessage( "I am fine" );
        n.setSender( "Matt" );
        n.setReceiver( "Amiya" );
        assertEquals( "I am fine", n.getMessage() );
        assertEquals( "Matt", n.getSender() );
        assertEquals( "Amiya", n.getReceiver() );
        n.setRead( true );
        assertTrue( n.isRead() );

        n.setReceiver( "Prem" );
        assertEquals( "Prem", n.getReceiver() );

        // testing creation time, check console
        System.out.println( n.getNotificationTimeUnix() );
        System.out.println( n.getNotificationTimeReadable() );

    }

}
