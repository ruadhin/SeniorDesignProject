package app.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;

/**
 * Tests Privilege POJO class.
 *
 * @author Prem Subedi
 *
 */
public class PrivilegeTest {

    @Test
    public void testDefault () {
        Privilege pv = new Privilege();
        assertNotNull( pv );
    }

    @Test
    public void testNullPrivilege () {
        Privilege priv = new Privilege( "Able to trigger risk assessment" );
        assertNull( priv.getId() );
        assertNotNull( priv.getName() );
        assertEquals( "Able to trigger risk assessment", priv.getName() );
        assertNull( priv.getRoles() );
    }

    @Test
    public void testPrivilege () {
        Privilege priv = new Privilege( "fill up contracts" );
        priv.setId( "high" );
        priv.setName( "new privilege" );
        Collection<Role> rlist = new ArrayList<Role>();
        priv.setRoles( rlist );

        assertEquals( "high", priv.getId() );
        assertEquals( "new privilege", priv.getName() );
        assertEquals( rlist, priv.getRoles() );
    }

}
