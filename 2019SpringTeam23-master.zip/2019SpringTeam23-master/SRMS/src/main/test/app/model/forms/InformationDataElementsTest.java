package app.model.forms;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

/**
 * Tests InformationDataElements class.
 * @author Prem Subedi
 *
 */
public class InformationDataElementsTest {
	
	List<String> confidentialInfo = new ArrayList<String>();
	private String       confidentialInfoOther = "ws";
	private String       confidentialInfoOtherText = "otherText";
	List<String> merckInfo = new ArrayList<String>();
	List<String> generalInfo = new ArrayList<String>();
    List<String> governmentInfo = new ArrayList<String>();
    List<String> financialInfo = new ArrayList<String>();
    List<String> sensitiveInfo = new ArrayList<String>();
    List<String> technicalIdentifiers = new ArrayList<String>();
    List<String> biometricIdentifiers = new ArrayList<String>();
    List<String> whoseInformation = new ArrayList<String>();
    List<String> countriesOfResidence = new ArrayList<String>();
    private String       countriesOfResidenceOthers = "otherResidence";
    private String       countriesOfResidenceOthersText = "otherResidenceText";
    private String       numberOfRecords = "5";
    
    private String       merckNetwork = "Yes";
    private String       networkInfo = "networkInfo";
    private String       networkInfoOtherText = "networkInfoOTest";
    
    private String       whoseInformationOther = "whoseInfoOther";
    private String       whoseInformationOtherText = "whoseInfoTest";
    
    
	
	@Test
	public void testInformationDataElements() {
		InformationDataElements ide = new InformationDataElements();
		assertNotNull(ide);
		
		assertFalse(ide.isComplete());
		ide.setBiometricIdentifiers(biometricIdentifiers);
		assertFalse(ide.isComplete());
		
		ide.setConfidentialInfo(confidentialInfo);
		assertFalse(ide.isComplete());
		
		ide.setConfidentialInfoOther(confidentialInfoOther);
		assertFalse(ide.isComplete());
		
		ide.setConfidentialInfoOtherText(confidentialInfoOtherText);
		assertFalse(ide.isComplete());
		
		ide.setCountriesOfResidence(countriesOfResidence);
		assertFalse(ide.isComplete());
		
		ide.setCountriesOfResidenceOthers(countriesOfResidenceOthers);
		assertFalse(ide.isComplete());
		
		ide.setCountriesOfResidenceOthersText(countriesOfResidenceOthersText);
		assertFalse(ide.isComplete());
		
		ide.setNumberOfRecords(numberOfRecords);
		assertFalse(ide.isComplete());
		
		ide.setMerckInfo(merckInfo);
		assertFalse(ide.isComplete());
		
		ide.setGeneralInfo(generalInfo);
		assertFalse(ide.isComplete());
		
		ide.setGovernmentInfo(governmentInfo);
		assertFalse(ide.isComplete());
		
		ide.setFinancialInfo(financialInfo);
		assertFalse(ide.isComplete());
		
		ide.setSensitiveInfo(sensitiveInfo);
		assertFalse(ide.isComplete());
		
		ide.setTechnicalIdentifiers(technicalIdentifiers);
		assertFalse(ide.isComplete());
		
		ide.setMerckNetwork(merckNetwork);
		assertFalse(ide.isComplete());
		
		ide.setNetworkInfo(networkInfo);
		assertFalse(ide.isComplete());
		
		ide.setNetworkInfoOtherText(networkInfoOtherText);
		assertFalse(ide.isComplete());
		
		ide.setWhoseInformation(whoseInformation);
		assertFalse(ide.isComplete());
		
		ide.setWhoseInformationOther(whoseInformationOther);
		assertFalse(ide.isComplete());
		
		ide.setWhoseInformationOtherText(whoseInformationOtherText);
		assertFalse(ide.isComplete());
		
		confidentialInfo.add("password");
		assertFalse(ide.isComplete());
		merckInfo.add("Headquartered in new jersey"); 
		assertFalse(ide.isComplete());
		generalInfo.add("Great info");
		assertFalse(ide.isComplete());
	    governmentInfo.add("US government");
	    assertFalse(ide.isComplete());
	    financialInfo.add("Bank of America");
	    assertFalse(ide.isComplete());
	    sensitiveInfo.add("sensitive information");
	    assertFalse(ide.isComplete());
	    technicalIdentifiers.add("software"); 
	    assertFalse(ide.isComplete());
	    biometricIdentifiers.add("biometrics");
	    assertTrue(ide.isComplete());
	    whoseInformation.add("someone's");
	    assertTrue(ide.isComplete());
	    countriesOfResidence.add("USA"); 
	    assertTrue(ide.isComplete());
		
		assertEquals(biometricIdentifiers, ide.getBiometricIdentifiers());
		assertEquals(confidentialInfo, ide.getConfidentialInfo());
		assertEquals(confidentialInfoOther, ide.getConfidentialInfoOther());
		assertEquals(confidentialInfoOtherText, ide.getConfidentialInfoOtherText());
		assertEquals(merckInfo, ide.getMerckInfo());
		assertEquals(countriesOfResidence, ide.getCountriesOfResidence());
		assertEquals(countriesOfResidenceOthers, ide.getCountriesOfResidenceOthers());
		assertEquals(countriesOfResidenceOthersText, ide.getCountriesOfResidenceOthersText());
		assertEquals(numberOfRecords, ide.getNumberOfRecords());
		assertEquals(generalInfo, ide.getGeneralInfo());
		assertEquals(governmentInfo, ide.getGovernmentInfo());
		assertEquals(financialInfo, ide.getFinancialInfo());
		assertEquals(sensitiveInfo, ide.getSensitiveInfo());
		assertEquals(technicalIdentifiers, ide.getTechnicalIdentifiers());
		assertEquals(merckNetwork, ide.getMerckNetwork());
		assertEquals(networkInfo, ide.getNetworkInfo());
		assertEquals(networkInfoOtherText, ide.getNetworkInfoOtherText());
		assertEquals(whoseInformation, ide.getWhoseInformation());
		assertEquals(whoseInformationOther, ide.getWhoseInformationOther());
		assertEquals(whoseInformationOtherText, ide.getWhoseInformationOtherText());
		
		
		
		
		//Testing boolean method
		ide.setMerckNetwork("No");
		assertTrue(ide.isComplete());
		
		ide.setConfidentialInfoOther(null);
		ide.setConfidentialInfo(null);
		assertFalse(ide.isComplete());
		
		
		
		confidentialInfo.remove(confidentialInfo.get(0));
		ide.setConfidentialInfo(confidentialInfo);
		assertFalse(ide.isComplete());
		
		confidentialInfo.add("apple");
		ide.setConfidentialInfoOther("Okay");
		ide.setConfidentialInfo(confidentialInfo);
		
		assertTrue(ide.isComplete());
		
		ide.setWhoseInformation(null);
		ide.setWhoseInformationOther(null);
		assertFalse(ide.isComplete());
		
		ide.setWhoseInformationOther(whoseInformationOther);
		
		
		ide.setWhoseInformationOtherText("");
		assertFalse(ide.isComplete());
			
	}

}
