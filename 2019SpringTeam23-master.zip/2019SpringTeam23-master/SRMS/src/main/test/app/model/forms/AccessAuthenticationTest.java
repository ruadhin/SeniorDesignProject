package app.model.forms;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Tests AccessAuthentication POJO class.
 * @author Prem Subedi
 *
 */
public class AccessAuthenticationTest {
	
	@Test
	public void testGettersAndSetters() {
		AccessAuthentication au = new AccessAuthentication();
		assertNotNull(au);
		
		assertFalse(au.isComplete());
		au.setAccessMethod("DirectAccess");
		assertFalse(au.isComplete());
		au.setAuthenticationMethod("Put password");
		assertFalse(au.isComplete());
		au.setAccessMethodOtherText("other");
		assertFalse(au.isComplete());
		au.setBrandImage("brand image");
		assertFalse(au.isComplete());
		au.setCustomerPublicAccess("public access");
		assertFalse(au.isComplete());
		au.setDataIntegrity("data integrity");
		assertFalse(au.isComplete());
		au.setWebAddress("");
		assertFalse(au.isComplete());
		au.setWebAddress("www.merck.com");
		assertTrue(au.isComplete());
		
		
		assertEquals("DirectAccess", au.getAccessMethod());
		assertEquals("Put password", au.getAuthenticationMethod());
		assertEquals("brand image", au.getBrandImage());
		assertEquals("public access", au.getCustomerPublicAccess());
		assertEquals("data integrity", au.getDataIntegrity());
		assertEquals("www.merck.com", au.getWebAddress());
		assertEquals("other", au.getAccessMethodOtherText());
		
		au.setAccessMethod("Other");
		au.setAccessMethodOtherText("");
		assertFalse(au.isComplete());
		
		au.setAccessMethodOtherText(null);
		assertFalse(au.isComplete());
		
		au.setAccessMethod("accessmethod");
		
		assertTrue(au.isComplete());
		
	}

}
