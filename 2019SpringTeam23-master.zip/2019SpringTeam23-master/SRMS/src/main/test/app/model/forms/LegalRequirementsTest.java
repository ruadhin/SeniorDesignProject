package app.model.forms;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Tests LegalRequirements class.
 * @author Prem Subedi
 *
 */
public class LegalRequirementsTest {
	
	String recoveryTime = "2 hours";
    String recoveryPoint = "10 am";
    String legalScope = "wide";
    String legalScopeOtherText = "";
    String pciImpact= "impact";
    
    @Test
    public void testLegalRequirements() {
    	LegalRequirements lr = new LegalRequirements();
    	assertNotNull(lr);
    }
    
    @Test
    public void testGettersAndSetters() {
    	LegalRequirements lr = new LegalRequirements();
    	lr.setLegalScope(legalScope);
    	lr.setLegalScopeOtherText(legalScopeOtherText);
    	lr.setPciImpact(pciImpact);
    	lr.setRecoveryPoint(recoveryPoint);
    	lr.setRecoveryTime(recoveryTime);
    	
    	
    	assertEquals(legalScope, lr.getLegalScope());
    	assertEquals (legalScopeOtherText, lr.getLegalScopeOtherText());
    	assertEquals(pciImpact, lr.getPciImpact());
    	assertEquals(recoveryPoint, lr.getRecoveryPoint());
    	assertEquals(recoveryTime, lr.getRecoveryTime());
    	
    }
    
    @Test
    public void testIsComplete() {
    	LegalRequirements lr = new LegalRequirements();
    	assertFalse(lr.isComplete());
    	lr.setLegalScope(legalScope);
    	assertFalse(lr.isComplete());
    	lr.setLegalScopeOtherText(legalScopeOtherText);
    	assertFalse(lr.isComplete());
    	lr.setPciImpact(pciImpact);
    	assertFalse(lr.isComplete());
    	lr.setRecoveryPoint(recoveryPoint);
    	assertFalse(lr.isComplete());
    	lr.setRecoveryTime(recoveryTime);
    	assertTrue(lr.isComplete());
    	
    	lr.setRecoveryPoint(null);
    	assertFalse(lr.isComplete());
    	
    	lr.setRecoveryPoint(recoveryPoint);
    	lr.setLegalScope(null);
    	assertFalse(lr.isComplete());
    	
    	lr.setLegalScope(legalScope);
    	lr.setPciImpact(null);
    	assertFalse(lr.isComplete());
    	lr.setPciImpact(pciImpact);
    	assertTrue(lr.isComplete());
    	
    	
    	lr.setLegalScope("Other");
    	assertFalse(lr.isComplete());
    	
    	
    	
    	
    	
    }

}
