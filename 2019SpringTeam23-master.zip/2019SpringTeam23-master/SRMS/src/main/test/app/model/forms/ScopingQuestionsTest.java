package app.model.forms;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

/**
 * Tests ScopingQuestions forms class.
 * @author Prem Subedi
 *
 */
public class ScopingQuestionsTest {
	
	/**
     * Scoping question forms
     */
    SeverityRiskQuestions    severityRiskQuestions = new SeverityRiskQuestions();
    InitialEngagementFactors initialEngagementFactors = new InitialEngagementFactors();
    InformationDataElements  informationDataElements = new InformationDataElements();
    LegalRequirements        legalRequirements = new LegalRequirements();
    AccessAuthentication     accessAuthentication = new AccessAuthentication();

    boolean                  complete;

    List<String>             interestedUsers = new ArrayList<String>();
    
    @Test
    public void testScopingQuestions() {
    	ScopingQuestions sq = new ScopingQuestions();
    	assertNotNull(sq);
    	sq.setAccessAuthentication(accessAuthentication);
    	sq.setComplete(complete);
    	sq.setInformationDataElements(informationDataElements);
    	sq.setInitialEngagementFactors(initialEngagementFactors);
    	sq.setLegalRequirements(legalRequirements);
    	sq.setSeverityRiskQuestions(severityRiskQuestions);
    	
    	assertEquals(accessAuthentication, sq.getAccessAuthentication());
    	assertEquals(complete, sq.isComplete());
    	assertEquals(informationDataElements, sq.getInformationDataElements());
    	assertEquals(legalRequirements, sq.getLegalRequirements());
    	assertEquals(initialEngagementFactors, sq.getInitialEngagementFactors());
    	assertEquals(severityRiskQuestions, sq.getSeverityRiskQuestions());
    	assertEquals(interestedUsers, sq.getInterestedUsers());
    	
    	assertEquals(0, sq.getCompletion());
    	
    }

}
