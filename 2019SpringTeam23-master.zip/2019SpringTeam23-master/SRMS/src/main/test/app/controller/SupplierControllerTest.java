package app.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.web.context.WebApplicationContext;

import app.model.database.SupplierRepository;

@RunWith ( SpringRunner.class )
@SpringBootTest ( webEnvironment = WebEnvironment.RANDOM_PORT )
@AutoConfigureMockMvc
public class SupplierControllerTest {

    @Autowired
    private MockMvc               mvc;

    @Autowired
    private TestRestTemplate      template;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    private SupplierRepository    suppliers;

    @WithMockUser ( "busowner" )
    @Test
    public void testUnsetCompletion () throws Exception {

        // if you check in database, this actually unsets it so it works
        mvc.perform( MockMvcRequestBuilders.get( "/supplier/unsetScopingFormCompletion/s0" ) )
                .andExpect( MockMvcResultMatchers.status().isOk() );
    }
    
    @Test
    public void testGetProjectsAssignedToCurrentUser() throws Exception {
    	mvc.perform( MockMvcRequestBuilders.get( "/supplier/getCurrentSupplierProjects" ) )
        .andExpect( MockMvcResultMatchers.status().isFound() );
    	
    }
}
