package app.controller;

public @interface SpringBootTest {

}
