package app.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import app.model.database.NotificationRepository;


/**
 * Tests NotificationController endpoints
 * @author premsubedi
 *
 */

@RunWith ( SpringRunner.class )
@SpringBootTest ( webEnvironment = WebEnvironment.RANDOM_PORT )
@AutoConfigureMockMvc
public class NotificationControllerTest {
	
    private MockMvc               mvc;

    @Autowired
    private WebApplicationContext context;

    @Autowired
    private NotificationRepository notificationRepo;
    
    /**
     * Sets up test
     */
    @Before
    public void setup () {
        mvc = MockMvcBuilders.webAppContextSetup( context ).build();
    }
    
    @Test
    public void testSearchNotificationByReceiver() throws Exception {
    	mvc.perform( get( "notification/getNotifications" ) ).andExpect( status().isNotFound() );
    }
    
    /**
     * Tests getting a non existent Notification in the database and 
     * returns correct status
     *
     * @throws Exception
     */
    @Test
    public void testGetNonExistnetNotifications () throws Exception {
        mvc.perform( get( "notification/getNotifications/-1" ) ).andExpect( status().isNotFound() );
    }
    
    
    
    

}
