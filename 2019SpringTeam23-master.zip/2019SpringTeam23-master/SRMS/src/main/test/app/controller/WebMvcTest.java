package app.controller;

public @interface WebMvcTest {

	Class<SupplierController> value();


}
