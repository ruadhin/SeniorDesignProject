package app.services;

public @interface MockBean {

}
