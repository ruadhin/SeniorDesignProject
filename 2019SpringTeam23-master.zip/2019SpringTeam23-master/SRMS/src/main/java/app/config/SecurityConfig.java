package app.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;

import app.security.SRMSAuthSuccessHandler;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    MongoUserDetailsService userDetailsService;

    // from https://www.baeldung.com/spring_redirect_after_login
    @Bean ( "authmanager" )
    @Override
    public AuthenticationManager authenticationManagerBean () throws Exception {
        return super.authenticationManagerBean();
    }

    @Bean
    public AuthenticationSuccessHandler myAuthSuccessHandler () {
        return new SRMSAuthSuccessHandler();
    }
    
    @Bean
    public LogoutSuccessHandler logoutSuccessHandler() {
        return new SRMSLogoutSuccessHandler();
    }

    @Override
    public void configure ( final HttpSecurity http ) throws Exception {

        // Logout and CSRF from https://github.com/spring-guides/tut-spring-boot-oauth2/tree/master/logout
        // and https://www.logicbig.com/tutorials/spring-framework/spring-security/default-logout.html
        http
        .authorizeRequests()
            .antMatchers( "/admin/**" ).hasAuthority( "ADMIN" )
            .antMatchers( "/proc/**" ).hasAuthority( "PROCUREMENT_ANALYST" )
            .antMatchers( "/busowner/**" ).hasAuthority( "BUSINESS_OWNER" )
            .antMatchers( "/itrma/**" ).hasAuthority( "RISK_ANALYST" )
            .antMatchers( "/accman/**" ).hasAuthority( "ACCOUNT_MANAGER" )
            .antMatchers( "/infsup/**" ).hasAuthority( "INFORMATION_SUPPLIER" )
            .antMatchers( "/login_support" ).permitAll()         
            .antMatchers( "/supplier/**").authenticated()  //temp?
            .antMatchers( "/actuator/**" ).hasAuthority( "ADMIN" )  // working?
            .antMatchers( "/confirm_logout" ).authenticated()
            .antMatchers( "/shared_views/**" ).authenticated()
            .anyRequest().authenticated()
            .and()
        .formLogin()
            .loginPage( "/login" )
            .defaultSuccessUrl( "/login_support", true )
            .successHandler( myAuthSuccessHandler() )
            .permitAll()
            .and()
        .logout()
            .invalidateHttpSession( true )
            .deleteCookies( "JSESSIONID" )
            .logoutSuccessHandler( logoutSuccessHandler() )
            .logoutSuccessUrl( "/login?logout" )
            .permitAll()
            .and()
        .csrf()
            .csrfTokenRepository( this.csrfRepo() );
        
        // System.out.println( "ABOVE SECURITY CONFIGURATION WAS RUN" );
        // might need CSRF and Session Management later
        // http.csrf().disable().authorizeRequests().antMatchers( "/admin/**"
        // ).hasRole( "ADMIN" )
        // .antMatchers( "/anonymous*" ).anonymous().antMatchers( "/login*"
        // ).permitAll().anyRequest()
        // .authenticated().and().formLogin().loginPage( "/login.html"
        // ).loginProcessingUrl( "/perform_login" )
        // .defaultSuccessUrl( "/landingpage_template.html", true )
        // // .failureUrl("/login.html?error=true")
        // // .failureHandler(authenticationFailureHandler())
        // .and().logout().logoutUrl( "/perform_logout" ).deleteCookies(
        // "JSESSIONID" );
        // .logoutSuccessHandler(logoutSuccessHandler());
    }

     @Bean
     public PasswordEncoder passwordEncoder () {
         return new BCryptPasswordEncoder(11);
     }

    @Override
    public void configure ( final AuthenticationManagerBuilder builder ) throws Exception {
        builder.userDetailsService( userDetailsService );
        builder.authenticationProvider( authenticationProvider() );
    }

    // from https://stackoverflow.com/a/39786911 to get static content working
    @Override
    public void configure ( final WebSecurity web ) throws Exception {
        web.ignoring().antMatchers( "/static/**" );
    }
    
    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService( userDetailsService );
        authProvider.setPasswordEncoder( passwordEncoder() );
        return authProvider;
    }
    
    // https://stackoverflow.com/a/53965781
    private CookieCsrfTokenRepository csrfRepo() {
        CookieCsrfTokenRepository repo = new CookieCsrfTokenRepository();
        repo.setCookieHttpOnly( false );
        return repo;
    }

}
