/*
 * Copyright 2002-2016 the original author or authors. Licensed under the Apache
 * License, Version 2.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package app.config;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.thymeleaf.dialect.IDialect;
import org.thymeleaf.extras.springsecurity5.dialect.SpringSecurityDialect;
import org.thymeleaf.spring5.SpringTemplateEngine;
import org.thymeleaf.spring5.templateresolver.SpringResourceTemplateResolver;
import org.thymeleaf.spring5.view.ThymeleafViewResolver;
import org.thymeleaf.templatemode.TemplateMode;

import nz.net.ultraq.thymeleaf.LayoutDialect;

/**
 * Maintains a variety of global configurations needed by the Spring web
 * application. Partially from Spring docs:
 * https://www.baeldung.com/spring-xml-vs-java-config
 *
 * @author Spring Security team
 * @author Gabriel Gloss
 *
 */
@Configuration
@EnableWebMvc
@ComponentScan ( { "app.controller",
        "app.config" } ) /*
                          * Controller packages. Update as necessary
                          */

public class WebMvcConfiguration implements WebMvcConfigurer {

    /**
     * ApplicationContext used to maintain security
     */
    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    ServletContext             servletContext;

    /**
     * Not used at the moment, commenting out in case needed
     *
     * @Autowired private FormattingConversionService mvcConversionService;
     */

    /**
     * ViewResolver used for Thymeleaf's parsing
     *
     * @return ViewResolver generated
     */
    @Bean
    public ViewResolver viewResolver () {
        final ThymeleafViewResolver resolver = new ThymeleafViewResolver();
        resolver.setTemplateEngine( templateEngine() );
        resolver.setCharacterEncoding( "UTF-8" );
        return resolver;
    }

    /**
     * Templating engine for Spring and Thymeleaf
     *
     * @return TemplateEngine generated
     */
    @Bean
    public SpringTemplateEngine templateEngine () {
        final SpringTemplateEngine engine = new SpringTemplateEngine();
        engine.setEnableSpringELCompiler( true );
        engine.setTemplateResolver( templateResolver() );
        engine.addDialect( securityDialect() );
        engine.addDialect( new LayoutDialect() );
        return engine;
    }

    private IDialect securityDialect () {
        final SpringSecurityDialect dialect = new SpringSecurityDialect();
        return dialect;
    }

    /**
     * Creates a TemplateResolver
     *
     * @return SpringResourceTemplateResolver generated
     */
    public SpringResourceTemplateResolver templateResolver () {

        final SpringResourceTemplateResolver resolver = new SpringResourceTemplateResolver();
        resolver.setPrefix( "classpath:/views/" );
        resolver.setSuffix( ".html" );
        resolver.setTemplateMode( TemplateMode.HTML );
        resolver.setApplicationContext( applicationContext );
        // System.out.println( "WE REACHED THIS CODE PATH." );
        return resolver;
    }

    // /* (non-Javadoc)
    // * @see
    // org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport#addResourceHandlers(org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry)
    // */
    // @Override
    // protected void addResourceHandlers ( ResourceHandlerRegistry registry ) {
    // // TODO Auto-generated method stub
    // super.addResourceHandlers( registry );
    //
    // }

    @Override
    public void addResourceHandlers ( final ResourceHandlerRegistry registry ) {
        registry.addResourceHandler( "/static/**" ).addResourceLocations( "classpath:/resources/" );
    }

    @Override
    public void addViewControllers ( final ViewControllerRegistry registry ) {
        // System.out.println( "WE REACHED THIS CODE PATH." );
        registry.addViewController( "/login" ).setViewName( "login" );
        registry.setOrder( Ordered.HIGHEST_PRECEDENCE );
    }
}
