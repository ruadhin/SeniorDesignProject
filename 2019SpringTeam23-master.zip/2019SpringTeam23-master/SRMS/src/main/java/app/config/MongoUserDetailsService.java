package app.config;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import app.model.MongoUserDetails;
import app.model.Privilege;
import app.model.Role;
import app.model.User;
import app.model.database.UserRepository;

@Service ( "SRMSUserDetailsService" )
@Component
public class MongoUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepository userRepo;

    /**
     * Default constructor, just call super method
     */
    public MongoUserDetailsService () {
        super();
    }

    @Override
    public UserDetails loadUserByUsername ( final String username ) throws UsernameNotFoundException {

        try {
            User user = userRepo.findByUsername( username );

            if ( user == null ) {
                throw new UsernameNotFoundException( "No user with username: " + username );
            }

            // System.out.println( user.getRoles().size() );
            // for ( Role role : user.getRoles() ) {
            // System.out.println( "DEBUG ROLE NAME: " + role.getName() );
            // }
            // System.out.println( user.getUsername() );
            // System.out.println( user.getPassword() );
            // System.out.println( user.isEnabled() );
            // System.out.println( user.isAccountNonExpired() );
            // System.out.println( user.isCredentialsNonExpired() );
            // System.out.println( user.isAccountNonLocked() );
            // System.out.println( getAuthorities( user.getRoles() ).size() );
            // return new MongoUserDetails( user );
            return new MongoUserDetails( user.getUsername(), user.getPassword(), user.isEnabled(),
                    user.isAccountNonExpired(), user.isCredentialsNonExpired(), user.isAccountNonLocked(),
                    getAuthorities( user.getRoles() ) );
        }
        catch ( UsernameNotFoundException unfe ) {
            System.out.println( unfe.getMessage() );
            return new MongoUserDetails( "", "", false, false, false, false, null );
        }
        catch ( Exception exc ) {
            throw new RuntimeException( exc );
        }
    }

    // Methods used for loadUser

    private final Collection< ? extends GrantedAuthority> getAuthorities ( final Collection<Role> roles ) {
        return getGrantedAuthorities( getPrivileges( roles ) );
    }

    private final List<String> getPrivileges ( final Collection<Role> roles ) {
        final List<String> privs = new ArrayList<String>();
        final List<Privilege> collection = new ArrayList<Privilege>();
        for ( final Role role : roles ) {
            collection.addAll( role.getPrivileges() );
        }
        for ( final Privilege item : collection ) {
            privs.add( item.getName() );
        }

        return privs;
    }

    private final List<GrantedAuthority> getGrantedAuthorities ( final List<String> privileges ) {
        final List<GrantedAuthority> auths = new ArrayList<GrantedAuthority>();
        for ( final String privilege : privileges ) {
            auths.add( new SimpleGrantedAuthority( privilege ) );
        }
        return auths;
    }

}
