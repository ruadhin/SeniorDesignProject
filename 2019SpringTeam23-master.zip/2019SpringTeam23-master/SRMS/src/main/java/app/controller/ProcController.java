package app.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import app.model.Notification;
import app.model.Privilege;
import app.model.Supplier;
import app.model.User;
import app.model.database.IDCountersRepository;
import app.model.database.NotificationRepository;
import app.model.database.SupplierRepository;
import app.model.database.UserRepository;
import app.util.IDCounter;

@RestController
@SessionAttributes ( { "oldNotif", "oldAddSupp" } )
public class ProcController {

    @Autowired
    private UserRepository         userRepo;

    @Autowired
    private SupplierRepository     supplierRepo;

    @Autowired
    private IDCountersRepository   idCounters;

    @Autowired
    private NotificationRepository notificationRepo;

    @PostMapping ( "/proc/submitAssignForm/{supplierId}" )
    public ResponseEntity<Void> submitAssignForm ( @PathVariable String supplierId, @ModelAttribute Supplier supp,
            RedirectAttributes redirectAttributes ) {

        // which Proc assigned
        String procUsername = "Unknown User";
        try {
            UserDetails u = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            procUsername = u.getUsername();
        }
        catch ( Exception e ) {
            // do nothing
        }

        // validation if they submit an improper username to 'business owner
        // assignee'
        User boAssignee = userRepo.findByUsername( supp.getBoAssignedUsername() );
        boolean isValidBo = false;
        if ( boAssignee != null ) {
            if ( boAssignee.getRoles().iterator().next().getPrivileges().iterator().next().getName()
                    .equals( Privilege.BUSINESS_OWNER ) ) {
                // valid business owner user in SRMS, add supplier ID to them
                // and save to DB
                boAssignee.addSupplier( supplierId );
                userRepo.save( boAssignee );
                isValidBo = true;
            }
        }

        if ( !isValidBo ) {
            redirectAttributes.addFlashAttribute( "message",
                    "Not an SRMS Business Owner: " + supp.getBoAssignedUsername() );
            redirectAttributes.addFlashAttribute( "alertClass", "alert-danger" );
            return ResponseEntity.status( HttpStatus.MOVED_PERMANENTLY )
                    .header( HttpHeaders.LOCATION, "/proc/assign_bo/" + supplierId ).build();
        }

        // get existing supp object from DB
        Supplier existingSupplier = supplierRepo.getSupplierById( supplierId );

        existingSupplier.setBoAssignedUsername( supp.getBoAssignedUsername() );
        existingSupplier.setProcAssignedUsername( procUsername );
        // make sure to change assigned flag
        existingSupplier.setAssignedToBO( true );

        // set time that this assigning occurred
        long objCreationTime = System.currentTimeMillis();
        SimpleDateFormat notificationFormat = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss Z" );
        Date objCreationDate = new Date( objCreationTime );
        existingSupplier.setProcAssignedTime( notificationFormat.format( objCreationDate ) );
        supplierRepo.save( existingSupplier );

        Notification successNotification = new Notification();
        successNotification.setId( getNotificationId() );
        successNotification.setSubject( "Assigned Business Owner For \"" + existingSupplier.getName() + "\"" );
        successNotification.setMessage( "The supplier \"" + existingSupplier.getName()
                + "\" has been assigned to the following Business Owner: \"" + existingSupplier.getBoAssignedUsername()
                + ".\" This occurred at: " + existingSupplier.getProcAssignedTime() );
        successNotification.setSender( "SRMS System" );

        // Send to Merck Business Owner that was assigned this supplier
        successNotification.setReceiver( existingSupplier.getBoAssignedUsername() );
        notificationRepo.save( successNotification );

        redirectAttributes.addFlashAttribute( "message", "Successfully Assigned Supplier." );
        redirectAttributes.addFlashAttribute( "alertClass", "alert-success" );
        return ResponseEntity.status( HttpStatus.MOVED_PERMANENTLY ).header( HttpHeaders.LOCATION, "/proc/proc_index" )
                .build();
    }

    @PostMapping ( "/proc/create_supplier" )
    public ResponseEntity<Void> createSupplier ( @ModelAttribute final Supplier supplier,
            @RequestParam ( "assignees" ) final String[] assignees, final RedirectAttributes redirectAttributes,
            @ModelAttribute ( "oldAddSupp" ) Supplier oldAddSupp ) {

        // System.out.println( "Should be true: " + ( supplier.getId() == null )
        // );
        // oldAddSupp = new Supplier();
        oldAddSupp.setName( supplier.getName() );
        oldAddSupp.setParentCompany( supplier.getParentCompany() );
        oldAddSupp.setType( supplier.getType() );
        oldAddSupp.setDescription( supplier.getDescription() );
        oldAddSupp.setDUNS( supplier.getDUNS() );
        // System.out.println( "POST: " + oldAddSupp.getName() + " " +
        // oldAddSupp.getParentCompany() + " "
        // + oldAddSupp.getType() + " " + oldAddSupp.getDescription() );
        // check if supplier name already exists, if it does error out
        if ( !checkValidSN( supplier.getName() ) ) {
            oldAddSupp.setName( "" );
            redirectAttributes.addFlashAttribute( "message",
                    "Invalid Supplier Name (Already Exists): " + supplier.getName() + ". New supplier not created." );
            redirectAttributes.addFlashAttribute( "alertClass", "alert-danger" );
            return ResponseEntity.status( HttpStatus.MOVED_PERMANENTLY )
                    .header( HttpHeaders.LOCATION, "/proc/add_supplier" ).build();
        }
        if ( supplier.getType().equals( Supplier.TYPE_PC ) && checkValidPC( supplier.getParentCompany() ) ) {
            // need to get parent supplier object and add this new supplier to
            // their nodes, does the ID update get saved?
            supplier.setID( getSupplierId() );
            final Supplier parentSupp = supplierRepo.getSuppliersByName( supplier.getParentCompany() );
            final List<Supplier> parentSuppNodesList = parentSupp.getNodes();
            parentSuppNodesList.add( supplier );
            parentSupp.setNodes( parentSuppNodesList );
            // need to save parent supplier object
            supplierRepo.save( parentSupp );
        }
        else if ( supplier.getType().equals( Supplier.TYPE_PC ) && !checkValidPC( supplier.getParentCompany() ) ) {
            // error out if not a valid parent company
            oldAddSupp.setParentCompany( "" );
            redirectAttributes.addFlashAttribute( "message",
                    "Invalid Parent Company: " + supplier.getParentCompany() + ". New supplier not created." );
            redirectAttributes.addFlashAttribute( "alertClass", "alert-danger" );
            return ResponseEntity.status( HttpStatus.MOVED_PERMANENTLY )
                    .header( HttpHeaders.LOCATION, "/proc/add_supplier" ).build();
        }
        else {
            supplier.setParentCompany( "None" );
        }
        // DUNS must be 9 digits if not 0
        if ( supplier.getDUNS() != 0 && String.valueOf( supplier.getDUNS() ).length() != 9 ) {
            oldAddSupp.setDUNS( 0 );
            redirectAttributes.addFlashAttribute( "message",
                    "Invalid DUNS Number: " + supplier.getDUNS() + ". New supplier not created." );
            redirectAttributes.addFlashAttribute( "alertClass", "alert-danger" );
            return ResponseEntity.status( HttpStatus.MOVED_PERMANENTLY )
                    .header( HttpHeaders.LOCATION, "/proc/add_supplier" ).build();
        }
        if ( supplier.getId() == null ) {
            supplier.setID( getSupplierId() );
        }
        // save supplier to MongoDB
        supplierRepo.save( supplier );

        // notify users in system about the new supplier being added
        String successUsername = "Unknown User";
        try {
            UserDetails u = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            successUsername = u.getUsername();
        }
        catch ( Exception e ) {
            // do nothing
        }

        Notification successNotification = new Notification();
        successNotification.setId( getNotificationId() );
        successNotification.setSubject( "New Supplier \"" + supplier.getName() + "\"" );
        successNotification.setMessage(
                "A new supplier \"" + supplier.getName() + "\" was added to the SRMS System by: " + successUsername );
        successNotification.setSender( "SRMS System" );

        // For now, send to all Merck side users that aren't procs, needs to be
        // fixed in the future
        successNotification.setReceiver( "busowner" );
        notificationRepo.save( successNotification );

        successNotification.setId( getNotificationId() );
        successNotification.setReceiver( "itrma" );
        notificationRepo.save( successNotification );

        successNotification.setId( getNotificationId() );
        successNotification.setReceiver( "johndoe" );
        notificationRepo.save( successNotification );

        oldAddSupp.setName( "" );
        oldAddSupp.setParentCompany( "" );
        oldAddSupp.setType( "" );
        oldAddSupp.setDescription( "" );
        oldAddSupp.setDUNS( 0 );

        // System.out.println( "POST 2: " + oldAddSupp.getName() + " " +
        // oldAddSupp.getParentCompany() + " "
        // + oldAddSupp.getType() + " " + oldAddSupp.getDescription() );

        final List<User> validAssignees = new ArrayList<User>();
        final List<String> invalidAssignees = new ArrayList<String>();
        // build list of assignees (if multiple), check validity
        for ( final String username : assignees ) {
            final User user = userRepo.findByUsername( username );
            if ( user != null ) {
                if ( user.getRoles().iterator().next().getPrivileges().iterator().next().getName()
                        .equals( Privilege.BUSINESS_OWNER ) ) {
                    validAssignees.add( user );
                }
                else {
                    invalidAssignees.add( username );
                }
            }
            else if ( username != null && !username.isEmpty() ) {
                invalidAssignees.add( username );
            }
        }
        for ( final User u : validAssignees ) {
            u.getSupplierIds().add( supplier.getId() );
            userRepo.save( u );
            supplier.setAssignedToBO( true );
            supplierRepo.save( supplier );
        }
        String message = "Successfully created supplier " + supplier.getName();
        if ( invalidAssignees.size() > 0 ) {
            message += "  |  Error assigning supplier to Business Owner: ";
            for ( final String s : invalidAssignees ) {
                message += ( s );
            }
        }
        redirectAttributes.addFlashAttribute( "message", message );
        redirectAttributes.addFlashAttribute( "alertClass", "alert-success" );
        return ResponseEntity.status( HttpStatus.MOVED_PERMANENTLY ).header( HttpHeaders.LOCATION, "/proc/proc_index" )
                .build();
    }

    /** =============== HELPER METHODS =============== */

    // helper method for getting a new notification ID
    private String getNotificationId () {
        String s = "n";
        IDCounter idc = idCounters.findAll().get( 0 );
        s += idc.getNotificationIdCounter();
        idc.setNotificationIdCounter( idc.getNotificationIdCounter() + 1 );
        idCounters.save( idc );
        return s;
    }

    // helper method for getting a new supplier ID
    private String getSupplierId () {
        String s = "s";
        final IDCounter idc = idCounters.findAll().get( 0 );
        s += idc.getSupplierIdCounter();
        idc.setSupplierIdCounter( idc.getSupplierIdCounter() + 1 );
        idCounters.save( idc );
        return s;
    }

    /**
     * Helper method to check for a valid parent company
     */
    private boolean checkValidPC ( final String parentCompanyName ) {
        // System.out.println( "checkValidPC: " + parentCompanyName );
        final Supplier parentSupp = supplierRepo.getSuppliersByName( parentCompanyName );
        if ( parentSupp != null ) {
            // System.out.println( "checkValidPC parent ID: " +
            // parentSupp.getId() );
            if ( parentSupp.getType().equals( Supplier.TYPE_GPC ) ) {
                return true;
            }
            return false;
        }
        return false;
    }

    /**
     * Helper method to check for a valid supplier name
     */
    private boolean checkValidSN ( final String supplierName ) {
        // System.out.println( "checkValidSN: " + supplierName );
        final List<Supplier> validSuppliers = supplierRepo.getSuppliersByNameIgnoreCase( supplierName );
        if ( validSuppliers != null ) {
            // System.out.println( "checkValidSN: " + validSuppliers.size() );
            if ( validSuppliers.size() == 0 ) {
                return true;
            }
            // name already exists in system
            return false;
        }
        return true;
    }

}
