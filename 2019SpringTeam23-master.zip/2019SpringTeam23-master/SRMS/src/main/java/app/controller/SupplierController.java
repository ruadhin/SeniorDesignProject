package app.controller;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import app.model.Notification;
import app.model.Privilege;
import app.model.Supplier;
import app.model.User;
import app.model.database.IDCountersRepository;
import app.model.database.NotificationRepository;
import app.model.database.SupplierRepository;
import app.model.database.UserRepository;
import app.model.forms.AccessAuthentication;
import app.model.forms.InformationDataElements;
import app.model.forms.InitialEngagementFactors;
import app.model.forms.LegalRequirements;
import app.model.forms.SeverityRiskQuestions;
import app.util.IDCounter;

@RestController
public class SupplierController {

    @Autowired
    private SupplierRepository     suppliers;

    @Autowired
    private UserRepository         users;

    @Autowired
    private NotificationRepository notifRepo;

    @Autowired
    private IDCountersRepository   idCounters;

    @PostMapping ( "/supplier/getSuppliers" )
    public List<Supplier> getSuppliers () {
        List<Supplier> all = suppliers.getSuppliersByType( "parentCompany" );
        all.addAll( suppliers.getSuppliersByType( "grandparentCompany" ) );
        all.sort( new Comparator<Supplier>() {
            @Override
            public int compare ( Supplier arg0, Supplier arg1 ) {
                int s0 = Integer.parseInt( arg0.getId().substring( 1 ) );
                int s1 = Integer.parseInt( arg1.getId().substring( 1 ) );
                if ( s0 > s1 ) {
                    return 1;
                }
                else {
                    return -1;
                }
            }
        } );
        return all;
    }

    @PostMapping ( "/supplier/getSuppliers/{username}" )
    public List<Supplier> getSuppliersAssignedToUser ( String username ) {
        ArrayList<Supplier> list = new ArrayList<Supplier>();
        User u = users.findByUsername( username );
        for ( int i = 0; i < suppliers.findAll().size(); i++ ) {
            Supplier s = suppliers.findAll().get( i );
            if ( u != null && u.getSupplierIds().contains( s.getId() ) ) {
                list.add( s );
            }
        }
        return list;
    }

    @GetMapping ( "/supplier/getSuppliersFromUser" )
    public List<Supplier> getSuppliersAssignedToCurrentUser () {
        String username = "";
        ArrayList<Supplier> list = new ArrayList<Supplier>();
        try {
            UserDetails u = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            username = u.getUsername();
            if ( u.getAuthorities().iterator().next().getAuthority().equals( Privilege.PROCUREMENT_ANALYST )
                    || u.getAuthorities().iterator().next().getAuthority().equals( Privilege.RISK_ANALYST ) ) {
                return getSuppliers();
            }
        }
        catch ( Exception e ) {
            return list;
        }
        User u = users.findByUsername( username );
        for ( Supplier s : suppliers.findAll() ) {
            if ( u != null && u.getSupplierIds().contains( s.getId() ) ) {
                list.add( s );
            }
        }
        return list;
    }

    /**
     * Used in supplier table to determine currently logged in user's role
     */
    @RequestMapping ( value = "/supplierTable/getLoggedInRole", method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity<String> getLoggedInRole () {
        UserDetails u = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        // System.out.println(
        // u.getAuthorities().iterator().next().getAuthority() );
        return new ResponseEntity<String>( "{\"role\":\"" + u.getAuthorities().iterator().next().getAuthority() + "\"}",
                HttpStatus.OK );
    }

    /**
     * Gets only grandparent companies assigned to current user (companies with
     * no parent company)
     *
     * @return List of suppliers that are grandparents
     */
    @GetMapping ( "/supplier/getGrandparentsFromUser" )
    public List<Supplier> getGrandparentsAssignedToCurrentUser () {
        String username = "";
        ArrayList<Supplier> list = new ArrayList<Supplier>();
        try {
            UserDetails userDet = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            username = userDet.getUsername();
        }
        catch ( Exception e ) {
            return list;
        }
        User userFromDB = users.findByUsername( username );
        if ( userFromDB == null ) {
            return list;
        }
        // doesn't look pretty, but works
        for ( Supplier s : suppliers.findAll() ) {
            if ( !userFromDB.getRoles().iterator().next().getPrivileges().iterator().next().getName()
                    .equals( Privilege.BUSINESS_OWNER ) ) {
                if ( s.getType().equals( "grandparentCompany" ) ) {
                    list.add( s );
                }
            }
            else if ( userFromDB.getSupplierIds().contains( s.getId() ) ) {
                if ( s.getType().equals( "grandparentCompany" ) ) {
                    list.add( s );
                }
            }

        }

        return list;

    }

    /**
     * Gets projects assigned to current user
     *
     * @return List of projects ("makeshift supplier objects")
     */
    @GetMapping ( "/supplier/getCurrentSupplierProjects" )
    public List<Supplier> getProjectsAssignedToCurrentUser () {
        String username = "";
        ArrayList<Supplier> list = new ArrayList<Supplier>();
        try {
            UserDetails u = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            username = u.getUsername();
        }
        catch ( Exception e ) {
            return list;
        }
        User u = users.findByUsername( username );
        for ( Supplier s : suppliers.findAll() ) {
            if ( u != null && u.getSupplierIds().contains( s.getId() ) ) {
                for ( Supplier p : s.getNodes() ) {
                    if ( p.getType().equals( "project" ) ) {
                        list.add( p );
                    }
                }
                if ( s.getType().equals( "project" ) ) {
                    list.add( s );
                }
            }
        }
        return list;
    }

    @GetMapping ( "/supplier/getSupplierCountFromRating" )
    public List<String> getSupplierCountFromRating () {
        ArrayList<String> counts = new ArrayList<String>();
        int all = 0;
        int inprogress = 0;
        int low = 0;
        int medium = 0;
        int high = 0;
        int critical = 0;
        for ( Supplier s : getSuppliersAssignedToCurrentUser() ) {
            // System.out.println( s.getName() );
            all++;
            switch ( s.getRiskRating() ) {
                case Supplier.RR_CRIT:
                    critical++;
                    break;
                case Supplier.RR_HIGH:
                    high++;
                    break;
                case Supplier.RR_MED:
                    medium++;
                    break;
                case Supplier.RR_LOW:
                    low++;
                    break;
                case Supplier.RR_IP:
                    inprogress++;
                    break;
                default:
                    break;
            }
        }
        // System.out.println( "Crit: " + critical );
        // System.out.println( "High: " + high );
        // System.out.println( "Med: " + medium );
        // System.out.println( "Low: " + low );
        // System.out.println( "IP: " + inprogress );
        // System.out.println( "All: " + all );
        counts.add( String.valueOf( critical ) ); // 0
        counts.add( String.valueOf( high ) ); // 1
        counts.add( String.valueOf( medium ) ); // 2
        counts.add( String.valueOf( low ) ); // 3
        counts.add( String.valueOf( inprogress ) ); // 4
        counts.add( String.valueOf( all ) ); // 5
        return counts;
    }

    @PostMapping ( "/supplier/assignSupplier/{username}/{supplierId}" )
    public void assignSupplier ( @PathVariable String username, @PathVariable String supplierId ) {
        User u = users.findByUsername( username );
        u.getSupplierIds().add( supplierId );
        users.save( u );
    }

    @PostMapping ( "/supplier/unassignSupplier/{username}/{supplierId}" )
    public void unassignSupplier ( @PathVariable String username, @PathVariable String supplierId ) {
        User u = users.findByUsername( username );
        if ( u.getSupplierIds().contains( supplierId ) ) {
            u.getSupplierIds().remove( supplierId );
        }
        users.save( u );
    }

    @PostMapping ( "/supplier/submitScoping/severityRiskQuestions/{supplierId}" )
    public ResponseEntity<Void> submitSeverityRiskQuestions ( @RequestParam ( value = "page" ) String page,
            @PathVariable String supplierId, @ModelAttribute SeverityRiskQuestions srq,
            RedirectAttributes redirectAttributes ) {
        Supplier supplier = suppliers.getSupplierById( supplierId );
        supplier.getScopingQuestions().setSeverityRiskQuestions( srq );
        supplier.setRiskAssessmentStatus( supplier.getScopingQuestions().getCompletion() );
        suppliers.save( supplier );

        redirectAttributes.addFlashAttribute( "message", "Successfully Updated Severity Risk Page in Database." );
        redirectAttributes.addFlashAttribute( "alertClass", "alert-success" );

        if ( page.equals( "all" ) ) {
            return submitAll( supplierId, redirectAttributes );
        }
        else {
            return ResponseEntity.status( HttpStatus.MOVED_PERMANENTLY )
                    .header( HttpHeaders.LOCATION, "/shared_views/" + page + "/" + supplierId ).build();
        }
    }

    @PostMapping ( "/supplier/submitScoping/initialEngagementFactors/{supplierId}" )
    public ResponseEntity<Void> submitInitialEngagementQuestions ( @PathVariable String supplierId,
            @RequestParam ( value = "page" ) String page, @ModelAttribute InitialEngagementFactors ief,
            RedirectAttributes redirectAttributes ) {
        Supplier supplier = suppliers.getSupplierById( supplierId );
        // clear fields appropriately based on responses
        if ( ief.getServiceTypeOther() == null ) {
            ief.setServiceTypeOtherText( null );
        }
        if ( ief.getCloudHosted() == null || ief.getCloudHosted().equals( "No" ) ) {
            ief.setCloudProvider( null );
            ief.setCloudProviderOtherText( null );
            ief.setApproval( null );
            ief.setApprovalDate( null );
        }
        supplier.getScopingQuestions().setInitialEngagementFactors( ief );
        supplier.setRiskAssessmentStatus( supplier.getScopingQuestions().getCompletion() );
        suppliers.save( supplier );

        if ( page.equals( "all" ) ) {
            return submitAll( supplierId, redirectAttributes );
        }
        else {
            redirectAttributes.addFlashAttribute( "message",
                    "Successfully Updated Initial Engagement Factors Page in Database." );
            redirectAttributes.addFlashAttribute( "alertClass", "alert-success" );
            return ResponseEntity.status( HttpStatus.MOVED_PERMANENTLY )
                    .header( HttpHeaders.LOCATION, "/shared_views/" + page + "/" + supplierId ).build();
        }
    }

    @PostMapping ( "/supplier/submitScoping/informationDataElements/{supplierId}" )
    public ResponseEntity<Void> submitInformationDataElementsQuestions ( @PathVariable String supplierId,
            @RequestParam ( value = "page" ) String page, @ModelAttribute InformationDataElements ide,
            RedirectAttributes redirectAttributes ) {
        Supplier supplier = suppliers.getSupplierById( supplierId );
        if ( ide.getMerckNetwork() == null || ide.getMerckNetwork().equals( "No" ) ) {
            ide.setNetworkInfo( null );
            ide.setNetworkInfoOtherText( null );
        }
        supplier.getScopingQuestions().setInformationDataElements( ide );
        supplier.setRiskAssessmentStatus( supplier.getScopingQuestions().getCompletion() );
        suppliers.save( supplier );
        if ( page.equals( "all" ) ) {
            return submitAll( supplierId, redirectAttributes );
        }
        else {
            redirectAttributes.addFlashAttribute( "message",
                    "Successfully Updated Information Data Elements Page in Database." );
            redirectAttributes.addFlashAttribute( "alertClass", "alert-success" );
            return ResponseEntity.status( HttpStatus.MOVED_PERMANENTLY )
                    .header( HttpHeaders.LOCATION, "/shared_views/" + page + "/" + supplierId ).build();
        }
    }

    @PostMapping ( "/supplier/submitScoping/legalContractRequirements/{supplierId}" )
    public ResponseEntity<Void> submitLegalContractRequirementsQuestions ( @PathVariable String supplierId,
            @RequestParam ( value = "page" ) String page, @ModelAttribute LegalRequirements lr,
            RedirectAttributes redirectAttributes ) {
        Supplier supplier = suppliers.getSupplierById( supplierId );
        supplier.getScopingQuestions().setLegalRequirements( lr );
        supplier.setRiskAssessmentStatus( supplier.getScopingQuestions().getCompletion() );
        suppliers.save( supplier );

        if ( page.equals( "all" ) ) {
            return submitAll( supplierId, redirectAttributes );
        }
        else {
            redirectAttributes.addFlashAttribute( "message",
                    "Successfully Updated Legal Contract Requirements Page in Database." );
            redirectAttributes.addFlashAttribute( "alertClass", "alert-success" );
            return ResponseEntity.status( HttpStatus.MOVED_PERMANENTLY )
                    .header( HttpHeaders.LOCATION, "/shared_views/" + page + "/" + supplierId ).build();
        }
    }

    @PostMapping ( "/supplier/submitScoping/accessAuthentication/{supplierId}" )
    public ResponseEntity<Void> submitAccessAuthenticationQuestions ( @PathVariable String supplierId,
            @RequestParam ( value = "page" ) String page, @ModelAttribute AccessAuthentication aa,
            RedirectAttributes redirectAttributes ) {
        Supplier supplier = suppliers.getSupplierById( supplierId );
        supplier.getScopingQuestions().setAccessAuthentication( aa );
        supplier.setRiskAssessmentStatus( supplier.getScopingQuestions().getCompletion() );
        suppliers.save( supplier );

        if ( page.equals( "all" ) ) {
            return submitAll( supplierId, redirectAttributes );
        }
        else {
            redirectAttributes.addFlashAttribute( "message",
                    "Successfully Updated Access Authentication Page in Database." );
            redirectAttributes.addFlashAttribute( "alertClass", "alert-success" );
            return ResponseEntity.status( HttpStatus.MOVED_PERMANENTLY )
                    .header( HttpHeaders.LOCATION, "/shared_views/" + page + "/" + supplierId ).build();
        }
    }

    @PostMapping ( "/supplier/submitScoping/all/{supplierId}" )
    public ResponseEntity<Void> submitAll ( @PathVariable String supplierId, RedirectAttributes redirectAttributes ) {
        Supplier supplier = suppliers.getSupplierById( supplierId );
        String success = "All pages have been submitted.";
        String append = "";
        String redirect = "/busowner/busowner_index";
        String alertType = "alert-success";
        if ( !supplier.getScopingQuestions().getAccessAuthentication().isComplete() ) {
            success = "Error submitting pages. You still need to complete: ";
            append += "Access Authentication Page, ";
            redirect = "/shared_views/accessAuthentication/" + supplierId;
            alertType = "alert-danger";
        }
        if ( !supplier.getScopingQuestions().getInformationDataElements().isComplete() ) {
            success = "Error submitting pages. You still need to complete: ";
            append += "Information Data Elements Page, ";
            redirect = "/shared_views/informationDataElements/" + supplierId;
            alertType = "alert-danger";
        }
        if ( !supplier.getScopingQuestions().getInitialEngagementFactors().isComplete() ) {
            success = "Error submitting pages. You still need to complete: ";
            append += "Initial Engagement Factors Page, ";
            redirect = "/shared_views/initialEngagementFactors/" + supplierId;
            alertType = "alert-danger";
        }
        if ( !supplier.getScopingQuestions().getLegalRequirements().isComplete() ) {
            success = "Error submitting pages. You still need to complete: ";
            append += "Legal Requirements Page, ";
            redirect = "/shared_views/legalContractRequirements/" + supplierId;
            alertType = "alert-danger";
        }
        if ( !supplier.getScopingQuestions().getSeverityRiskQuestions().isComplete() ) {
            success = "Error submitting pages. You still need to complete: ";
            append += "Severity Risk Questions Page, ";
            redirect = "/shared_views/severity_risk/" + supplierId;
            alertType = "alert-danger";
        }
        if ( append.length() > 2 ) {
            append = append.substring( 0, append.length() - 2 );
        }
        // this means all forms are complete b/c passed all conditionals
        if ( success.equals( "All pages have been submitted." ) ) {
            supplier.getScopingQuestions().setComplete( true );
            supplier.setRiskAssessmentStatus( supplier.getScopingQuestions().getCompletion() );
            suppliers.save( supplier );

            String username = "Unknown User";

            try {
                UserDetails u = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
                username = u.getUsername();
            }
            catch ( Exception e ) {
                success = "Authorization error.";
                alertType = "alert-danger";
                redirectAttributes.addFlashAttribute( "message", success );
                redirectAttributes.addFlashAttribute( "alertClass", alertType );
                return ResponseEntity.status( HttpStatus.MOVED_PERMANENTLY ).header( HttpHeaders.LOCATION, redirect )
                        .build();
            }

            Notification successNotification = new Notification();
            successNotification.setId( getNotificationId() );
            successNotification.setSubject( "\"" + supplier.getName() + "\" Scoping Questions Completed" );
            successNotification.setMessage( "The Scoping Questions for supplier \"" + supplier.getName()
                    + "\" have been fully filled out by: " + username );
            successNotification.setSender( "SRMS System" );

            // For now, send to all Merck side users that aren't business
            // owners, needs to be fixed in the future
            successNotification.setReceiver( "proc" );
            notifRepo.save( successNotification );

            successNotification.setId( getNotificationId() );
            successNotification.setReceiver( "itrma" );
            notifRepo.save( successNotification );

        }
        success += append;
        redirectAttributes.addFlashAttribute( "message", success );
        redirectAttributes.addFlashAttribute( "alertClass", alertType );
        return ResponseEntity.status( HttpStatus.MOVED_PERMANENTLY ).header( HttpHeaders.LOCATION, redirect ).build();
    }

    // helper method for getting a notification ID
    private String getNotificationId () {
        String s = "n";
        IDCounter idc = idCounters.findAll().get( 0 );
        s += idc.getNotificationIdCounter();
        idc.setNotificationIdCounter( idc.getNotificationIdCounter() + 1 );
        idCounters.save( idc );
        return s;
    }

    @GetMapping ( "/supplier/unsetScopingFormCompletion/{supplierId}" )
    public String unsetCompletion ( @PathVariable String supplierId ) {
        Supplier s = suppliers.getSupplierById( supplierId );
        s.getScopingQuestions().setComplete( false );
        suppliers.save( s );
        return "Successfully unset form completion for " + supplierId;
    }

}
