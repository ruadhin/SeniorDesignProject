package app.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

// https://www.baeldung.com/spring-boot-custom-error-page
// https://www.baeldung.com/spring-mvc-model-model-map-model-view
@Controller
public class SRMSErrorController implements ErrorController {

    @RequestMapping ( value = "error", method = RequestMethod.GET )
    public ModelAndView errorPage ( HttpServletRequest httpReq ) {

        ModelAndView errorPg = new ModelAndView( "error" );
        String errorMsg = "Resource Error.";
        int httpErrorCode = getErrorCode( httpReq );

        switch ( httpErrorCode ) {
            case 400: {
                // errorMsg = "HTTP Error Code: 400. Bad Request.";
                System.out.println( "HTTP Error Code: 400. Bad Request." );
                break;
            }
            case 401: {
                // errorMsg = "HTTP Error Code: 401. Unauthorized Request.";
                System.out.println( "HTTP Error Code: 401. Unauthorized Request." );
                break;
            }
            case 403: {
                // errorMsg = "HTTP Error Code: 403. Forbidden.";
                System.out.println( "HTTP Error Code: 403. Forbidden." );
                break;
            }
            case 404: {
                // errorMsg = "HTTP Error Code: 404. Resource Not Found.";
                System.out.println( "HTTP Error Code: 404. Resource Not Found." );
                break;
            }
            case 500: {
                // errorMsg = "HTTP Error Code: 500. Internal Server Error.";
                System.out.println( "HTTP Error Code: 500. Internal Server Error." );
                break;
            }
            default: {
                // errorMsg = "An unknown error occurred.";
                System.out.println( "Unknown HTTP error occurred." );
                break;
            }
        }

        errorPg.addObject( "errorMsg", errorMsg );
        return errorPg;
    }

    // helper method
    private int getErrorCode ( HttpServletRequest httpReq ) {
        return (Integer) httpReq.getAttribute( "javax.servlet.error.status_code" );
    }

    @Override
    public String getErrorPath () {
        return "/error";
    }

}
