package app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import app.model.Notification;
import app.model.User;
import app.model.database.IDCountersRepository;
import app.model.database.NotificationRepository;

import app.model.database.UserRepository;
import app.util.IDCounter;

/**
 * Controller class for sending and receiving notifications.
 *
 * @author Matt Walters
 *
 */
@RestController
@SessionAttributes ( "oldNotif" )
public class NotificationController {


    @Autowired
    private UserRepository         userRepo;

    @Autowired
    private IDCountersRepository   idCounters;


    @Autowired
    private NotificationRepository notificationRepo;

    private String getNotificationId () {
        String s = "n";
        IDCounter idc = idCounters.findAll().get( 0 );
        s += idc.getNotificationIdCounter();
        idc.setNotificationIdCounter( idc.getNotificationIdCounter() + 1 );
        idCounters.save( idc );
        return s;
    }

    // Retrieving all the notifications in the database
    @GetMapping ( "/notifications/getNotifications" )
    public List<Notification> getNotifications () {
        return notificationRepo.findAll();
    }

    @GetMapping ( "/notifications/getNotificationsForCurrentUser" )
    public List<Notification> getNotificationsForCurrentUser () {
        UserDetails u = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = u.getUsername();
        // System.out.println( notificationRepo.getByReceiver( username ) );
        return notificationRepo.getByReceiver( username );
    }

    @GetMapping ( "/notifications/getUnreadCountForCurrentUser" )
    public String getUnreadCountForCurrentUser () {
        List<Notification> currentUserNotifs = getNotificationsForCurrentUser();
        int unreadCount = 0;
        for ( Notification n : currentUserNotifs ) {
            if ( !n.isRead() ) {
                unreadCount++;
            }
        }
        return String.valueOf( unreadCount );
    }

    @ModelAttribute ( "oldNotif" )
    public Notification getOldNotifObj () {
        return new Notification();
    }

    @PostMapping ( "/notifications/sendNotification" )
    public ResponseEntity<Void> sendNotification ( @ModelAttribute ( "oldNotif" ) Notification oldNotif,
            @ModelAttribute Notification notification, RedirectAttributes redirectAttributes ) {

        // verify that receiver is a valid user
        String receivingUserStr = notification.getReceiver();
        User receivingUser = userRepo.findByUsername( receivingUserStr );
        // not a valid user
        if ( receivingUser == null ) {
            oldNotif = new Notification();
            oldNotif.setSubject( notification.getSubject() );
            oldNotif.setMessage( notification.getMessage() );
            redirectAttributes.addFlashAttribute( "message",
                    "No user \"" + receivingUserStr + "\" found in system. Message not sent." );
            redirectAttributes.addFlashAttribute( "alertClass", "alert-danger" );
            return ResponseEntity.status( HttpStatus.MOVED_PERMANENTLY )
                    .header( HttpHeaders.LOCATION, "/shared_views/notificationsSend" ).build();
        }

        // currently logged in user is the sender
        UserDetails u = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String sendingUsername = u.getUsername();
        notification.setSender( sendingUsername );
        notification.setId( getNotificationId() );
        notificationRepo.save( notification );

        oldNotif.setSubject( "" );
        oldNotif.setMessage( "" );

        redirectAttributes.addFlashAttribute( "message",
                "Successfully Sent Message to \"" + notification.getReceiver() + "\"" );
        redirectAttributes.addFlashAttribute( "alertClass", "alert-success" );
        return ResponseEntity.status( HttpStatus.MOVED_PERMANENTLY )
                .header( HttpHeaders.LOCATION, "/shared_views/notificationsSend" ).build();
    }


}
