package app.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import app.model.Notification;
import app.model.Privilege;
import app.model.Role;
import app.model.Supplier;
import app.model.User;
import app.model.database.IDCountersRepository;
import app.model.database.NotificationRepository;
import app.model.database.PrivilegeRepository;
import app.model.database.RoleRepository;
import app.model.database.SupplierRepository;
import app.model.database.UserRepository;
import app.model.forms.AccessAuthentication;
import app.model.forms.InformationDataElements;
import app.model.forms.InitialEngagementFactors;
import app.model.forms.LegalRequirements;
import app.model.forms.SeverityRiskQuestions;
import app.util.IDCounter;

/**
 * Endpoints for database population (e.g. users, suppliers)
 *
 * @author Matt
 * @author Gabriel Gloss
 * @author Prem Subedi
 */
@RestController
@SessionAttributes ( { "oldNotif", "oldAddSupp" } )
public class DatabaseController {

    // private boolean alreadySetup = false;

    @Autowired
    private UserRepository         userRepo;

    @Autowired
    private SupplierRepository     supplierRepo;

    @Autowired
    private RoleRepository         roleRepo;

    @Autowired
    private PrivilegeRepository    privRepo;

    @Autowired
    private PasswordEncoder        passwordEncoder;

    @Autowired
    private IDCountersRepository   idCounters;

    @Autowired
    private NotificationRepository notificationRepo;

    /** ========================== HELPER METHODS ========================= */

    // IDs

    private String getUserId () {
        String s = "u";
        final IDCounter idc = idCounters.findAll().get( 0 );
        s += idc.getUserIdCounter();
        idc.setUserIdCounter( idc.getUserIdCounter() + 1 );
        idCounters.save( idc );
        return s;
    }

    private String getSupplierId () {
        String s = "s";
        final IDCounter idc = idCounters.findAll().get( 0 );
        s += idc.getSupplierIdCounter();
        idc.setSupplierIdCounter( idc.getSupplierIdCounter() + 1 );
        idCounters.save( idc );
        return s;
    }

    private String getProjectId () {
        String s = "p";
        final IDCounter idc = idCounters.findAll().get( 0 );
        s += idc.getProjectIdCounter();
        idc.setProjectIdCounter( idc.getProjectIdCounter() + 1 );
        idCounters.save( idc );
        return s;
    }

    private String getNotificationId () {
        String s = "n";
        final IDCounter idc = idCounters.findAll().get( 0 );
        s += idc.getNotificationIdCounter();
        idc.setNotificationIdCounter( idc.getNotificationIdCounter() + 1 );
        idCounters.save( idc );
        return s;
    }

    // Roles, privileges, miscellaneous helper methods
    // helper method to create a privilege
    private Privilege createPrivilegeIfNotFound ( final String name ) {
        Privilege priv = privRepo.findByName( name );
        if ( priv == null ) {
            priv = new Privilege( name );
            privRepo.save( priv );
        }
        return priv;
    }

    // helper method to create a role
    private Role createRoleIfNotFound ( final String name, final Collection<Privilege> privs ) {
        Role r = roleRepo.findByName( name );
        if ( r == null ) {
            r = new Role( name );
            r.setPrivileges( privs );
            roleRepo.save( r );
        }
        return r;
    }

    /** ========================== ENDPOINTS ======================= */

    /**
     * The resetDB method runs all sample DB endpoints in this controller
     *
     * @param redirectAttributes
     *            To add a success message to the homepage after executing
     * @return ResponseEntity To redirect to homepage after executing
     */
    @RequestMapping ( "/admin/resetDB" )
    public ResponseEntity<Void> resetDB ( final RedirectAttributes redirectAttributes ) {
        populateUsers( redirectAttributes );
        populateSuppliers( redirectAttributes );
        populateNotifications( redirectAttributes );

        redirectAttributes.addFlashAttribute( "message", "Successfully reset MongoDB." );
        redirectAttributes.addFlashAttribute( "alertClass", "alert-success" );
        return ResponseEntity.status( HttpStatus.MOVED_PERMANENTLY )
                .header( HttpHeaders.LOCATION, "/admin/admin_index" ).build();
    }

    @RequestMapping ( "/admin/populateusers" )
    public ResponseEntity<Void> populateUsers ( final RedirectAttributes redirectAttributes ) {
        userRepo.deleteAll();
        roleRepo.deleteAll();
        privRepo.deleteAll();

        try {
            final IDCounter ids = idCounters.findAll().get( 0 );
            ids.setUserIdCounter( 0 );
            idCounters.save( ids );
        }
        catch ( final Exception e ) {
            idCounters.deleteAll();
            idCounters.save( new IDCounter() );
        }

        // A privilege is what Spring considers a 'role', a bit confusing
        // For our nomenclature, we will use privileges as 'roles'
        // e.g. the privilege of a procurement analyst is equivalent to having
        // procurement analyst role
        final Privilege adminPriv = createPrivilegeIfNotFound( "ADMIN" );
        final Privilege procPriv = createPrivilegeIfNotFound( "PROCUREMENT_ANALYST" );
        final Privilege busownerPriv = createPrivilegeIfNotFound( "BUSINESS_OWNER" );
        final Privilege itrmaPriv = createPrivilegeIfNotFound( "RISK_ANALYST" );
        final Privilege accmanPriv = createPrivilegeIfNotFound( "ACCOUNT_MANAGER" );
        final Privilege infsupPriv = createPrivilegeIfNotFound( "INFORMATION_SUPPLIER" );

        // The privileges (roles) have a one-to-one mapping to roles for our
        // current system (e.g. procPriv is the ONLY object in procPrivs), but
        // this method gives us the flexibility to add
        // multiple privileges to a role (see adminPrivs as an example)
        final List<Privilege> adminPrivs = Arrays.asList( adminPriv, procPriv, accmanPriv, busownerPriv, infsupPriv,
                itrmaPriv );
        final List<Privilege> procPrivs = Arrays.asList( procPriv );
        final List<Privilege> busownerPrivs = Arrays.asList( busownerPriv );
        final List<Privilege> itrmaPrivs = Arrays.asList( itrmaPriv );
        final List<Privilege> accmanPrivs = Arrays.asList( accmanPriv );
        final List<Privilege> infsupPrivs = Arrays.asList( infsupPriv );

        createRoleIfNotFound( "ROLE_ADMIN", adminPrivs );
        createRoleIfNotFound( "ROLE_PROCUREMENT_ANALYST", procPrivs );
        createRoleIfNotFound( "ROLE_BUSINESS_OWNER", busownerPrivs );
        createRoleIfNotFound( "ROLE_RISK_ANALYST", itrmaPrivs );
        createRoleIfNotFound( "ROLE_ACCOUNT_MANAGER", accmanPrivs );
        createRoleIfNotFound( "ROLE_INFORMATION_SUPPLIER", infsupPrivs );

        final Role adminRole = roleRepo.findByName( "ROLE_ADMIN" );
        final Role procRole = roleRepo.findByName( "ROLE_PROCUREMENT_ANALYST" );
        final Role busownerRole = roleRepo.findByName( "ROLE_BUSINESS_OWNER" );
        final Role itrmaRole = roleRepo.findByName( "ROLE_RISK_ANALYST" );
        final Role accmanRole = roleRepo.findByName( "ROLE_ACCOUNT_MANAGER" );
        final Role infsupRole = roleRepo.findByName( "ROLE_INFORMATION_SUPPLIER" );

        // map back as well
        adminPriv.setRoles( Arrays.asList( adminRole ) );
        procPriv.setRoles( Arrays.asList( procRole ) );
        busownerPriv.setRoles( Arrays.asList( busownerRole ) );
        itrmaPriv.setRoles( Arrays.asList( itrmaRole ) );
        accmanPriv.setRoles( Arrays.asList( accmanRole ) );
        infsupPriv.setRoles( Arrays.asList( infsupRole ) );

        final User u0 = new User();
        u0.setUsername( "proc" );
        u0.setFirstName( "Procurement" );
        u0.setLastName( "Analyst" );
        u0.setPassword( passwordEncoder.encode( "proc1" ) );
        u0.setEmail( "proc@merck.com" );
        u0.setRoles( Arrays.asList( procRole ) );
        u0.setID( getUserId() );
        userRepo.save( u0 );

        final User u1 = new User();
        u1.setUsername( "busowner" );
        u1.setFirstName( "Business" );
        u1.setLastName( "Owner" );
        u1.setPassword( passwordEncoder.encode( "busowner2" ) );
        u1.setEmail( "busowner@merck.com" );
        u1.setRoles( Arrays.asList( busownerRole ) );
        u1.setID( getUserId() );
        for ( int i = 0; i <= 16; i++ ) {
            if ( i == 13 ) {
                // do nothing, don't assign supplier ID 13 to anyone
            }
            else {
                u1.addSupplier( "s" + i );
            }
        }
        userRepo.save( u1 );

        final User u2 = new User();
        u2.setUsername( "itrma" );
        u2.setFirstName( "IT Risk" );
        u2.setLastName( "Management Analyst" );
        u2.setPassword( passwordEncoder.encode( "apples" ) );
        u2.setEmail( "itrma@merck.com" );
        u2.setRoles( Arrays.asList( itrmaRole ) );
        u2.setID( getUserId() );
        userRepo.save( u2 );

        final User u3 = new User();
        u3.setUsername( "accman" );
        u3.setFirstName( "Account" );
        u3.setLastName( "Manager" );
        u3.setPassword( passwordEncoder.encode( "oranges" ) );
        u3.setEmail( "accman@merck.com" );
        u3.setRoles( Arrays.asList( accmanRole ) );
        u3.setID( getUserId() );
        u3.addSupplier( "s6" );
        userRepo.save( u3 );

        final User u4 = new User();
        u4.setUsername( "infsup" );
        u4.setFirstName( "Information" );
        u4.setLastName( "Supplier" );
        u4.setPassword( passwordEncoder.encode( "infsup" ) );
        u4.setEmail( "infsup@merck.com" );
        u4.setRoles( Arrays.asList( infsupRole ) );
        u4.setID( getUserId() );
        u4.addSupplier( "s6" );
        userRepo.save( u4 );

        final User u5 = new User();
        u5.setUsername( "admin" );
        u5.setFirstName( "adminFN" );
        u5.setLastName( "adminLN" );
        u5.setPassword( passwordEncoder.encode( "srmsadmin" ) );
        u5.setEmail( "admin@merck.com" );
        u5.setRoles( Arrays.asList( adminRole ) );
        u5.setID( getUserId() );
        userRepo.save( u5 );

        final User u6 = new User();
        u6.setUsername( "johndoe" );
        u6.setFirstName( "John" );
        u6.setLastName( "Doe" );
        u6.setPassword( passwordEncoder.encode( "password" ) );
        u6.setEmail( "johndoe@merck.com" );
        u6.setRoles( Arrays.asList( busownerRole ) );
        u6.setID( getUserId() );
        u6.addSupplier( "s5" );
        u6.addSupplier( "s6" );
        u6.addSupplier( "s7" );
        u6.addSupplier( "s8" );
        u6.addSupplier( "s9" );
        u6.addSupplier( "s14" );
        userRepo.save( u6 );

        redirectAttributes.addFlashAttribute( "message", "Successfully populated MongoDB Users." );
        redirectAttributes.addFlashAttribute( "alertClass", "alert-success" );
        return ResponseEntity.status( HttpStatus.MOVED_PERMANENTLY )
                .header( HttpHeaders.LOCATION, "/admin/admin_index" ).build();
    }

    @RequestMapping ( "/admin/populatesuppliers" )
    public ResponseEntity<Void> populateSuppliers ( final RedirectAttributes redirectAttributes ) {
        supplierRepo.deleteAll();

        try {
            final IDCounter ids = idCounters.findAll().get( 0 );
            ids.setSupplierIdCounter( 0 );
            idCounters.save( ids );
        }
        catch ( final Exception e ) {
            idCounters.deleteAll();
            idCounters.save( new IDCounter() );
        }

        /** =============== PRE-FILLED OUT FORMS ============ */

        // Access Authentication
        final AccessAuthentication aa = new AccessAuthentication();
        aa.setAccessMethod( "Public Internet Supplier Host" );
        aa.setAuthenticationMethod( "Merck Integration" );
        aa.setBrandImage( "Yes" );
        aa.setCustomerPublicAccess( "Free Access" );
        aa.setDataIntegrity( "No" );
        aa.setWebAddress( "https://www.google.com" );

        // Information Data Elements
        final InformationDataElements ide = new InformationDataElements();
        final List<String> biometrics = Stream.of( " Fingerprint", " Retinal or Iris Scan", " Voiceprint" )
                .collect( Collectors.toList() );
        ide.setBiometricIdentifiers( biometrics );
        final List<String> confidential = Stream.of( " Payroll Information", " Clinical Study Information" )
                .collect( Collectors.toList() );
        ide.setConfidentialInfo( confidential );
        final List<String> countries = Stream.of( " United States", " Japan", " Wales" ).collect( Collectors.toList() );
        ide.setCountriesOfResidence( countries );
        final List<String> financial = Stream.of( " Credit Card Number", " Tax Information", " Debit Card Number" )
                .collect( Collectors.toList() );
        ide.setFinancialInfo( financial );
        final List<String> general = Stream.of( " Name", " Email Address", " Phone Number" )
                .collect( Collectors.toList() );
        ide.setGeneralInfo( general );
        final List<String> govmt = Stream.of( " Passport Number", " Social Security Number" )
                .collect( Collectors.toList() );
        ide.setGovernmentInfo( govmt );
        final List<String> merck = Stream.of(
                " Internal Use Only - Information typically required to perform normal day-to-day work and may be accessed by all Merck Personnel." )
                .collect( Collectors.toList() );
        ide.setMerckInfo( merck );
        ide.setMerckNetwork( "Yes" );
        ide.setNetworkInfo( "Other" );
        ide.setNetworkInfoOtherText( "Other text test 123" );
        ide.setNumberOfRecords( "1-99" );
        final List<String> sensitive = Stream.of( " Civil or Criminal Information", " Medical History" )
                .collect( Collectors.toList() );
        ide.setSensitiveInfo( sensitive );
        final List<String> technical = Stream.of( " IP Address", " Geolocation" ).collect( Collectors.toList() );
        ide.setTechnicalIdentifiers( technical );
        final List<String> whoseInfo = Stream.of( " Employees", " Contract Employees" ).collect( Collectors.toList() );
        ide.setWhoseInformation( whoseInfo );

        // Initial Engagement Factors
        final InitialEngagementFactors ief = new InitialEngagementFactors();
        ief.setApproval( "Yes" );
        ief.setApprovalDate( "2019-03-18" );
        ief.setCloudHosted( "Yes" );
        ief.setCloudProvider( "IBM" );
        final List<String> serviceType = new ArrayList<String>();
        serviceType.add(
                " Software Purchase Only - Software development or purchase (including commercial off-the-shelf (COTS)), to be hosted in a Merck controlled environment." );
        ief.setServiceType( serviceType );

        // Legal Requirements
        final LegalRequirements lr = new LegalRequirements();
        lr.setLegalScope( "PCI" );
        lr.setPciImpact( "Store" );
        lr.setRecoveryPoint( "24 hrs or less, >4 hrs" );
        lr.setRecoveryTime( "4 hrs or less" );

        // Severity Risk
        final SeverityRiskQuestions srq = new SeverityRiskQuestions();
        srq.setCustomerOperational( "1" );
        srq.setFinancial( "2" );
        srq.setLegalRegulatoryContractual( "3" );
        srq.setReputational( "4" );

        /** =============== GRANDPARENT & PARENT SUPPLIERS ============ */

        final Supplier s0 = new Supplier();
        s0.setName( "Google" );
        s0.setDescription(
                "An American multinational technology company that specializes in Internet-related services and products, which include online advertising technologies, search engine, cloud computing, software, and hardware." );
        s0.setParentCompany( "None" );
        s0.setType( "grandparentCompany" );
        s0.setID( getSupplierId() );
        s0.setDUNS( 123456789 );
        s0.setAssignedToBO( true );
        s0.getScopingQuestions().setAccessAuthentication( aa );
        s0.getScopingQuestions().setInformationDataElements( ide );
        s0.getScopingQuestions().setInitialEngagementFactors( ief );
        s0.getScopingQuestions().setLegalRequirements( lr );
        s0.getScopingQuestions().setSeverityRiskQuestions( srq );
        s0.getScopingQuestions().setComplete( true );
        s0.setRiskAssessmentStatus( s0.getScopingQuestions().getCompletion() ); // 100

        final Supplier s1 = new Supplier();
        s1.setName( "Google Europe" );
        s1.setParentCompany( "Google" );
        s1.setDescription(
                "Google Europe provides services to Google from the European Union. In direct contract negotiations with Merck." );
        s1.setType( "parentCompany" );
        s1.setID( getSupplierId() );
        s1.setDUNS( 0 );
        s1.setAssignedToBO( true );
        s1.getScopingQuestions().setAccessAuthentication( aa );
        s1.getScopingQuestions().setLegalRequirements( lr );
        s1.getScopingQuestions().setSeverityRiskQuestions( srq );
        s1.setRiskAssessmentStatus( s1.getScopingQuestions().getCompletion() ); // 60

        final Supplier s2 = new Supplier();
        s2.setName( "Google South America" );
        s2.setParentCompany( "Google" );
        s2.setDescription(
                "Google South America provides services to Google from the South America region. In direct contract negotiations with Merck." );
        s2.setType( "parentCompany" );
        s2.setID( getSupplierId() );
        s2.setDUNS( 0 );
        s2.setAssignedToBO( true );
        s2.getScopingQuestions().setAccessAuthentication( aa );
        s2.getScopingQuestions().setInformationDataElements( ide );
        s2.getScopingQuestions().setInitialEngagementFactors( ief );
        s2.getScopingQuestions().setLegalRequirements( lr );
        s2.getScopingQuestions().setSeverityRiskQuestions( srq );
        s2.setRiskAssessmentStatus( s2.getScopingQuestions().getCompletion() ); // 100

        final Supplier s3 = new Supplier();
        s3.setName( "Amazon" );
        s3.setParentCompany( "None" );
        s3.setDescription(
                "An American multinational technology company based in Seattle, Washington that focuses in e-commerce, cloud computing, and artificial intelligence." );
        s3.setType( "grandparentCompany" );
        s3.setID( getSupplierId() );
        s3.setDUNS( 194801943 );
        s3.setAssignedToBO( true );

        final Supplier s4 = new Supplier();
        s4.setName( "Amazon Africa" );
        s4.setParentCompany( "Amazon" );
        s4.setDescription(
                "Amazon Africa provides services to Amazon from the African region. In direct contract negotiations with Merck." );
        s4.setType( "parentCompany" );
        s4.setID( getSupplierId() );
        s4.setDUNS( 0 );
        s4.setAssignedToBO( true );
        s4.getScopingQuestions().setLegalRequirements( lr );
        s4.getScopingQuestions().setSeverityRiskQuestions( srq );
        s4.setRiskAssessmentStatus( s4.getScopingQuestions().getCompletion() ); // 40

        final Supplier s5 = new Supplier();
        s5.setName( "Oracle" );
        s5.setParentCompany( "None" );
        s5.setDescription(
                "Oracle Corporation is an American multinational computer technology corporation headquartered in Redwood Shores, California." );
        s5.setType( "grandparentCompany" );
        s5.setID( getSupplierId() );
        s5.setDUNS( 299168513 );
        s5.setAssignedToBO( true );
        s5.getScopingQuestions().setAccessAuthentication( aa );
        s5.getScopingQuestions().setInformationDataElements( ide );
        s5.getScopingQuestions().setInitialEngagementFactors( ief );
        s5.getScopingQuestions().setLegalRequirements( lr );
        s5.getScopingQuestions().setSeverityRiskQuestions( srq );
        s5.getScopingQuestions().setComplete( true );
        s5.setRiskAssessmentStatus( s5.getScopingQuestions().getCompletion() ); // 100

        final Supplier s6 = new Supplier();
        s6.setName( "Oracle China" );
        s6.setParentCompany( "Oracle" );
        s6.setDescription(
                "Oracle China provides services to Oracle Corporation from the China region. In direct contract negotiations with Merck." );
        s6.setType( "parentCompany" );
        s6.setID( getSupplierId() );
        s6.setDUNS( 0 );
        s6.setAssignedToBO( true );
        s6.getScopingQuestions().setInformationDataElements( ide );
        s6.setRiskAssessmentStatus( s6.getScopingQuestions().getCompletion() ); // 20

        final Supplier s7 = new Supplier();
        s7.setName( "Oracle Latin America" );
        s7.setParentCompany( "Oracle" );
        s7.setDescription(
                "Oracle Latin America provides services to Oracle Corporation from the Latin America region. In direct contract negotiations with Merck." );
        s7.setType( "parentCompany" );
        s7.setID( getSupplierId() );
        s7.setDUNS( 359890308 );
        s7.setAssignedToBO( true );
        s7.getScopingQuestions().setAccessAuthentication( aa );
        s7.getScopingQuestions().setInformationDataElements( ide );
        s7.getScopingQuestions().setInitialEngagementFactors( ief );
        s7.getScopingQuestions().setLegalRequirements( lr );
        s7.getScopingQuestions().setSeverityRiskQuestions( srq );
        s7.getScopingQuestions().setComplete( true );
        s7.setRiskAssessmentStatus( s7.getScopingQuestions().getCompletion() ); // 100

        final Supplier s8 = new Supplier();
        s8.setName( "Oracle Germany" );
        s8.setParentCompany( "Oracle" );
        s8.setDescription(
                "Oracle Germany provides services to Oracle Corporation from the Germany region. In direct contract negotiations with Merck." );
        s8.setType( "parentCompany" );
        s8.setID( getSupplierId() );
        s8.setDUNS( 0 );
        s8.setAssignedToBO( true );
        s8.getScopingQuestions().setAccessAuthentication( aa );
        s8.getScopingQuestions().setInformationDataElements( ide );
        s8.getScopingQuestions().setInitialEngagementFactors( ief );
        s8.getScopingQuestions().setLegalRequirements( lr );
        s8.setRiskAssessmentStatus( s8.getScopingQuestions().getCompletion() ); // 80

        final Supplier s9 = new Supplier();
        s9.setName( "Oracle Canada" );
        s9.setParentCompany( "Oracle" );
        s9.setDescription(
                "Oracle Canada provides services to Oracle Corporation from Canada. In direct contract negotiations with Merck." );
        s9.setType( "parentCompany" );
        s9.setID( getSupplierId() );
        s9.setDUNS( 0 );
        s9.setAssignedToBO( true );
        s9.getScopingQuestions().setAccessAuthentication( aa );
        s9.getScopingQuestions().setInformationDataElements( ide );
        s9.getScopingQuestions().setInitialEngagementFactors( ief );
        s9.getScopingQuestions().setLegalRequirements( lr );
        s9.getScopingQuestions().setSeverityRiskQuestions( srq );
        s9.setRiskAssessmentStatus( s9.getScopingQuestions().getCompletion() ); // 100

        final Supplier s10 = new Supplier();
        s10.setName( "Small Supplier 1" );
        s10.setParentCompany( "None" );
        s10.setDescription(
                "Smaller company that provides Merck with ingredients for pharmaceuticals. In direct contract negotiations with Merck." );
        s10.setType( "grandparentCompany" );
        s10.setID( getSupplierId() );
        s10.setDUNS( 559592415 );
        s10.setAssignedToBO( true );

        final Supplier s11 = new Supplier();
        s11.setName( "Small Supplier 2" );
        s11.setParentCompany( "None" );
        s11.setDescription(
                "Another small company (2) that provides Merck with ingredients for pharmaceuticals. In direct contract negotiations with Merck." );
        s11.setType( "grandparentCompany" );
        s11.setID( getSupplierId() );
        s11.setDUNS( 584235161 );
        s11.setAssignedToBO( true );

        final Supplier s12 = new Supplier();
        s12.setName( "Small Supplier 3" );
        s12.setParentCompany( "None" );
        s12.setDescription(
                "Another small company (3) that provides Merck with ingredients for pharmaceuticals. In direct contract negotiations with Merck." );
        s12.setType( "grandparentCompany" );
        s12.setID( getSupplierId() );
        s12.setDUNS( 661839329 );
        s12.setAssignedToBO( true );

        // note, this supplier is not assigned to a business owner on purpose!
        final Supplier s13 = new Supplier();
        s13.setName( "Small Supplier 4" );
        s13.setParentCompany( "None" );
        s13.setDescription(
                "Another small company (4) that provides Merck with ingredients for pharmaceuticals. In direct contract negotiations with Merck." );
        s13.setType( "grandparentCompany" );
        s13.setID( getSupplierId() );
        s13.setDUNS( 812464659 );

        final Supplier s14 = new Supplier();
        s14.setName( "Small Supplier 5" );
        s14.setParentCompany( "None" );
        s14.setDescription(
                "Another small company (5) that provides Merck with ingredients for pharmaceuticals. In direct contract negotiations with Merck." );
        s14.setType( "grandparentCompany" );
        s14.setID( getSupplierId() );
        s14.setDUNS( 837654557 );
        s14.setAssignedToBO( true );
        s14.getScopingQuestions().setAccessAuthentication( aa );
        s14.getScopingQuestions().setInformationDataElements( ide );
        s14.getScopingQuestions().setInitialEngagementFactors( ief );
        s14.getScopingQuestions().setLegalRequirements( lr );
        s14.getScopingQuestions().setSeverityRiskQuestions( srq );
        s14.getScopingQuestions().setComplete( true );
        s14.setRiskAssessmentStatus( s14.getScopingQuestions().getCompletion() ); // 100

        final Supplier s15 = new Supplier();
        s15.setName( "Nvidia" );
        s15.setParentCompany( "None" );
        s15.setDescription(
                "An American technology company incorporated in Delaware and based in Santa Clara, California. It designs graphics processing units (GPUs) for the gaming and professional markets, as well as system on a chip units (SoCs) for the mobile computing and automotive market." );
        s15.setType( "grandparentCompany" );
        s15.setID( getSupplierId() );
        s15.setDUNS( 901770516 );
        s15.setAssignedToBO( true );
        s15.getScopingQuestions().setAccessAuthentication( aa );
        s15.getScopingQuestions().setInformationDataElements( ide );
        s15.getScopingQuestions().setInitialEngagementFactors( ief );
        s15.getScopingQuestions().setLegalRequirements( lr );
        s15.getScopingQuestions().setSeverityRiskQuestions( srq );
        s15.getScopingQuestions().setComplete( true );
        s15.setRiskAssessmentStatus( s15.getScopingQuestions().getCompletion() ); // 100

        final Supplier s16 = new Supplier();
        s16.setName( "Nvidia Latin America" );
        s16.setParentCompany( "Nvidia" );
        s16.setDescription(
                "Nvidia Latin America provides services to Nvidia Corporation from the Latin America region. In direct contract negotiations with Merck." );
        s16.setType( "parentCompany" );
        s16.setID( getSupplierId() );
        s16.setDUNS( 0 );
        s16.setAssignedToBO( true );
        s16.getScopingQuestions().setAccessAuthentication( aa );
        s16.getScopingQuestions().setInformationDataElements( ide );
        s16.getScopingQuestions().setInitialEngagementFactors( ief );
        s16.getScopingQuestions().setLegalRequirements( lr );
        s16.getScopingQuestions().setSeverityRiskQuestions( srq );
        s16.getScopingQuestions().setComplete( true );
        s16.setRiskAssessmentStatus( s16.getScopingQuestions().getCompletion() ); // 100

        /** =============== PROJECTS ============ */

        try {
            final IDCounter ids = idCounters.findAll().get( 0 );
            ids.setProjectIdCounter( 0 );
            idCounters.save( ids );
        }
        catch ( final Exception e ) {
            idCounters.deleteAll();
            idCounters.save( new IDCounter() );
        }

        final Supplier p0 = new Supplier();
        p0.setName( "Oracle CN Project 1" );
        p0.setDescription( "The first project that Oracle China is working on with Merck." );
        p0.setType( "project" );
        p0.setParentCompany( "Oracle China" );
        p0.setID( getProjectId() );

        final Supplier p1 = new Supplier();
        p1.setName( "Oracle CN Project 2" );
        p1.setDescription( "The second project that Oracle China is working on with Merck." );
        p1.setType( "project" );
        p1.setParentCompany( "Oracle China" );
        p1.setID( getProjectId() );

        final Supplier p2 = new Supplier();
        p2.setName( "Small Supplier's Project" );
        p2.setDescription( "This is an example of a small supplier working on a project directly with Merck." );
        p2.setType( "project" );
        p2.setParentCompany( "Small Supplier 1" );
        p2.setID( getProjectId() );

        final Supplier p3 = new Supplier();
        p3.setName( "Small Supplier's Project 2" );
        p3.setDescription( "This is another example of a small supplier working on a project directly with Merck." );
        p3.setType( "project" );
        p3.setParentCompany( "Small Supplier 5" );
        p3.setID( getProjectId() );

        final Supplier p4 = new Supplier();
        p4.setName( "Amazon Africa's First Project" );
        p4.setDescription(
                "Amazon Africa is working on a project with Merck that deals with the logistics of shipping pharmaceuticals to the continent of Africa." );
        p4.setType( "project" );
        p4.setParentCompany( "Amazon Africa" );
        p4.setID( getProjectId() );

        /** =============== HIERARCHICAL RELATIONSHIPS ============ */
        List<Supplier> tempList = new ArrayList<Supplier>();

        // -- Suppliers first --

        // s0, Google
        tempList = Stream.of( s1, s2 ).collect( Collectors.toList() );
        s0.setNodes( tempList );

        // s3, Amazon
        tempList = Stream.of( s4 ).collect( Collectors.toList() );
        s3.setNodes( tempList );

        // s5, Oracle
        tempList = Stream.of( s6, s7, s8, s9 ).collect( Collectors.toList() );
        s5.setNodes( tempList );

        // s15, Nvidia
        tempList = Stream.of( s16 ).collect( Collectors.toList() );
        s15.setNodes( tempList );

        // -- Projects last --

        // s6, Oracle China
        tempList = Stream.of( p0, p1 ).collect( Collectors.toList() );
        s6.setNodes( tempList );

        // s10, Small Supplier 1
        tempList = Stream.of( p2 ).collect( Collectors.toList() );
        s10.setNodes( tempList );

        // s14, Small Supplier 5
        tempList = Stream.of( p3 ).collect( Collectors.toList() );
        s14.setNodes( tempList );

        // s4, Amazon Africa
        tempList = Stream.of( p4 ).collect( Collectors.toList() );
        s4.setNodes( tempList );

        /** =============== SAVE ALL SUPPLIERS AND PROJECTS ============ */
        tempList = Stream
                .of( s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12, s13, s14, s15, s16, p0, p1, p2, p3, p4 )
                .collect( Collectors.toList() );
        supplierRepo.saveAll( tempList );

        redirectAttributes.addFlashAttribute( "message", "Successfully populated MongoDB Suppliers." );
        redirectAttributes.addFlashAttribute( "alertClass", "alert-success" );
        return ResponseEntity.status( HttpStatus.MOVED_PERMANENTLY )
                .header( HttpHeaders.LOCATION, "/admin/admin_index" ).build();
    }

    @RequestMapping ( "/admin/populateNotifications" )
    public ResponseEntity<Void> populateNotifications ( final RedirectAttributes redirectAttributes ) {
        notificationRepo.deleteAll();

        try {
            final IDCounter iDcntr = idCounters.findAll().get( 0 );
            iDcntr.setNotificationIdCounter( 0 );
        }
        catch ( final Exception e ) {
            idCounters.deleteAll();
            idCounters.save( new IDCounter() );
        }

        /** =============== RECEIVER: ITRMA ============ */

        final Notification n0 = new Notification();
        n0.setId( getNotificationId() );
        n0.setSubject( "Supplier Relationship" );
        n0.setMessage(
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam et nisl a tellus feugiat convallis. Phasellus sed mattis risus. Mauris mollis augue non justo aliquam iaculis. Cras id felis quis risus congue molestie. Morbi aliquet, lectus in ultrices placerat, ex justo ornare ipsum, ut hendrerit dui magna in libero. Curabitur iaculis faucibus enim, aliquet luctus arcu fermentum eget. Mauris suscipit placerat lorem, sit amet interdum odio placerat non. Ut tincidunt massa dapibus sapien finibus, vel commodo odio pharetra. Quisque congue scelerisque condimentum. Proin hendrerit, arcu quis faucibus porta, mauris sapien suscipit quam, eu mattis dolor eros sit amet libero. In tristique a mauris sed tristique. Nunc rhoncus nisi quis magna egestas faucibus. Nulla rhoncus dignissim leo quis varius. Nulla eget rutrum mi, tempor eleifend magna. Donec orci nulla, ultrices eu tempus vitae, euismod at ligula. " );
        n0.setSender( "busowner" );
        n0.setReceiver( "itrma" );
        n0.setNotificationTimeUnix( "1556184600000" );
        n0.setNotificationTimeReadable( "2019-04-25 05:30:00 -0400" );
        notificationRepo.save( n0 );

        final Notification n1 = new Notification();
        n1.setId( getNotificationId() );
        n1.setSubject( "Meeting with John Doe" );
        n1.setMessage(
                "Duis tempus risus eget posuere feugiat. Nulla vitae fermentum diam. Ut sit amet lacus magna. Ut fringilla, lacus quis suscipit tincidunt, justo eros sollicitudin neque, sed gravida turpis lacus sed nibh. Fusce convallis tincidunt massa in tempor. Curabitur lacus dui, pulvinar nec sagittis id, dignissim auctor dui. Morbi efficitur nec erat at hendrerit. Nunc accumsan orci vel nisi laoreet fringilla. Pellentesque condimentum ligula in turpis malesuada, vel tristique ante rutrum. Vestibulum sollicitudin mi at tempor vestibulum. Duis tempus odio mauris, vitae mattis turpis porta eu. Maecenas sit amet tellus eu sem lacinia efficitur sit amet nec enim. " );
        n1.setSender( "proc" );
        n1.setReceiver( "itrma" );
        n1.setNotificationTimeUnix( "1556195400000" );
        n1.setNotificationTimeReadable( "2019-04-25 08:30:00 -0400" );
        notificationRepo.save( n1 );

        /** =============== RECEIVER: BUSOWNER ============ */

        final Notification n2 = new Notification();
        n2.setId( getNotificationId() );
        n2.setSubject( "Potential New Supplier" );
        n2.setMessage(
                "Morbi imperdiet, ligula tristique vestibulum ultrices, nisl augue ultrices augue, eu congue arcu justo non neque. Vestibulum quis eros mi. Vivamus ac ligula tempor, condimentum risus a, porttitor leo. Maecenas vehicula velit a tellus aliquet pharetra. Aenean vehicula semper risus viverra cursus. Aliquam rutrum pharetra orci, id venenatis turpis accumsan quis. Donec maximus nibh felis, ut facilisis urna mollis ac. Vestibulum gravida, odio eget porta iaculis, ex ipsum semper nisi, eu efficitur tortor metus hendrerit elit. Aliquam non mauris vitae leo porta tempus ut luctus felis. Proin ut facilisis dui. Pellentesque vehicula feugiat varius. Proin est elit, gravida vehicula erat a, pulvinar mattis risus. Proin a dui non lorem tempor aliquam a molestie purus. Quisque malesuada consequat orci vel tempus. Aenean et quam elit. " );
        n2.setSender( "proc" );
        n2.setReceiver( "busowner" );
        n2.setNotificationTimeUnix( "1556188200000" );
        n2.setNotificationTimeReadable( "2019-04-25 06:30:00 -0400" );
        notificationRepo.save( n2 );

        /** =============== RECEIVER: PROC ============ */

        final Notification n3 = new Notification();
        n3.setId( getNotificationId() );
        n3.setSubject( "Overriding a Risk Score" );
        n3.setMessage(
                "Vestibulum eget accumsan magna. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque sed elementum elit. Quisque nunc purus, finibus euismod interdum in, feugiat eget nisi. Quisque non tortor ac turpis fringilla feugiat. Sed vel nibh velit. Etiam ornare condimentum feugiat. Morbi volutpat cursus suscipit. Vestibulum lacus enim, placerat dictum faucibus ut, commodo in est. Ut porttitor vestibulum ligula, ac blandit eros dapibus eleifend. Cras sed vehicula ipsum, rutrum lacinia ipsum. Vivamus augue tortor, accumsan vel dolor eu, pellentesque dapibus enim. " );
        n3.setSender( "itrma" );
        n3.setReceiver( "proc" );
        n3.setNotificationTimeUnix( "1556191800000" );
        n3.setNotificationTimeReadable( "2019-04-25 07:30:00 -0400" );
        notificationRepo.save( n3 );

        final Notification n4 = new Notification();
        n4.setId( getNotificationId() );
        n4.setSubject( "Can't Find Supplier" );
        n4.setMessage(
                "Aenean in sem ut metus tempus commodo sit amet sed sem. Phasellus rutrum a lorem eu dignissim. Praesent consectetur malesuada sapien, vitae interdum ex varius vitae. Vivamus ante orci, ultrices a rutrum vel, porta id justo. Ut placerat neque at elit ultricies, sit amet imperdiet nisl tristique. Maecenas vel turpis et tellus mattis sollicitudin. Vestibulum maximus urna et metus condimentum facilisis. Aliquam quis hendrerit lectus, non sodales arcu. Sed rhoncus sollicitudin quam in condimentum. Fusce fermentum blandit risus, in lacinia massa finibus sed. Curabitur tincidunt id velit quis maximus. Aenean varius erat mauris. Nulla facilisi. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. " );
        n4.setSender( "busowner" );
        n4.setReceiver( "proc" );
        n4.setNotificationTimeUnix( "1556199000000" );
        n4.setNotificationTimeReadable( "2019-04-25 09:30:00 -0400" );
        notificationRepo.save( n4 );

        final Notification n5 = new Notification();
        n5.setId( getNotificationId() );
        n5.setSubject( "Assign Me Oracle Ireland" );
        n5.setMessage(
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc placerat elit non tempor pellentesque. Etiam auctor felis vitae sem ornare, quis consequat risus molestie. Donec finibus tristique dignissim. Aenean sit amet eros euismod, viverra risus in, sollicitudin dolor. Sed gravida leo vel vulputate mollis. Vivamus dapibus metus eget ex ullamcorper egestas. Duis ullamcorper tincidunt blandit. Nulla sodales porta nunc, in facilisis risus consequat vitae. Nulla facilisi. Duis molestie, purus vitae varius hendrerit, velit arcu tincidunt urna, id dignissim arcu leo a quam. Nam faucibus viverra ante et placerat. Nunc a ultrices nulla, vel dictum ipsum. Phasellus urna lacus, congue nec ipsum quis, scelerisque vestibulum enim." );
        n5.setSender( "johndoe" );
        n5.setReceiver( "proc" );
        n5.setNotificationTimeUnix( "1556202600000" );
        n5.setNotificationTimeReadable( "2019-04-25 10:30:00 -0400" );
        notificationRepo.save( n5 );

        /** =============== RECEIVER: ACCMAN ============ */

        final Notification n6 = new Notification();
        n6.setId( getNotificationId() );
        n6.setSubject( "I Updated Your Supplier Risk Score" );
        n6.setMessage(
                "Morbi commodo nibh non tellus aliquet venenatis. Phasellus suscipit, massa vitae tempor rhoncus, velit enim pharetra orci, id dictum erat massa vel lectus. Quisque ut tellus tempus, blandit ex at, placerat mauris. Sed tincidunt vitae felis ac feugiat. Nulla mollis nibh vitae orci volutpat, et tempus eros rutrum. Donec elementum mattis erat, ac suscipit nunc fringilla sed. Donec hendrerit orci eget ex lobortis, sed congue orci tempus. Sed rhoncus dictum nibh ut finibus. Quisque nec commodo neque, eget pellentesque ipsum. Fusce auctor interdum lectus. Aenean eget consectetur diam." );
        n6.setSender( "itrma" );
        n6.setReceiver( "accman" );
        n6.setNotificationTimeUnix( "1556206200000" );
        n6.setNotificationTimeReadable( "2019-04-25 11:30:00 -0400" );
        notificationRepo.save( n6 );

        /** =============== RECEIVER: INFSUP ============ */

        final Notification n7 = new Notification();
        n7.setId( getNotificationId() );
        n7.setSubject( "ITRMA Guy Updated Our Risk Score" );
        n7.setMessage(
                "Nulla facilisi. Nam consectetur porttitor dolor, congue viverra tortor ultricies et. Aliquam erat volutpat. Proin et mauris nisl. Integer et interdum elit. Nulla nec tempus quam. Praesent molestie vehicula nibh eu rutrum. Donec vestibulum nisl nec velit efficitur faucibus. Integer vehicula mi turpis, sit amet dapibus erat porttitor ut. Nunc in metus aliquet, tempor odio nec, condimentum urna. Praesent laoreet elit risus, ut tristique diam sollicitudin et. Pellentesque sem arcu, consequat molestie enim ac, semper semper justo. Nulla eget semper orci." );
        n7.setSender( "accman" );
        n7.setReceiver( "infsup" );
        n7.setNotificationTimeUnix( "1556209800000" );
        n7.setNotificationTimeReadable( "2019-04-25 12:30:00 -0400" );
        notificationRepo.save( n7 );

        redirectAttributes.addFlashAttribute( "message", "Successfully populated MongoDB notifications" );
        redirectAttributes.addFlashAttribute( "alertClass", "alert-success" );
        return ResponseEntity.status( HttpStatus.MOVED_PERMANENTLY )
                .header( HttpHeaders.LOCATION, "/admin/admin_index" ).build();
    }

}
