package app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Default controller that handles redirecting the logged-in user to one of the
 * appropriate landing screens based on their user roles.
 *
 * @author Prem Subedi
 */
@Controller
public class DefaultController {

    /**
     * This controller is used to redirect the logged in user to appropriate
     * landing screen based on their role in the system.
     *
     * @param model
     *            data from the front end.
     * @return the page to be displayed to the user.
     */
    @GetMapping ( value = "/" )
    public String index ( final Model model ) {
        // final Authentication auth =
        // SecurityContextHolder.getContext().getAuthentication();
        // final List< ? extends GrantedAuthority> auths = (List< ? extends
        // GrantedAuthority>) auth.getAuthorities();
        // final GrantedAuthority ga = auths.get( 0 );
        // return new RedirectView( app.model.enums.Role.valueOf( ga.toString()
        // ).getLanding() );
        return "login";
    }

}
