package app.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import app.model.Notification;
import app.model.Supplier;
import app.model.database.IDCountersRepository;
import app.model.database.NotificationRepository;
import app.model.database.SupplierRepository;
import app.util.IDCounter;

@RestController
public class ITRMAController {

    @Autowired
    private SupplierRepository     suppliers;

    @Autowired
    private NotificationRepository notifRepo;

    @Autowired
    private IDCountersRepository   idCounters;

    @PostMapping ( "/itrma/submitOverrideForm/{supplierId}" )
    public ResponseEntity<Void> submitOverrideForm ( @PathVariable String supplierId, @ModelAttribute Supplier supp,
            RedirectAttributes redirectAttributes ) {

        // which ITRMA overrode
        String username = "Unknown User";
        try {
            UserDetails u = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            username = u.getUsername();
        }
        catch ( Exception e ) {
            // do nothing
        }
        // get existing supp object from DB
        Supplier existingSupplier = suppliers.getSupplierById( supplierId );
        // System.out.println( "Existing Supplier Risk Rating: " +
        // existingSupplier.getRiskRating() );
        // set value for old risk rating
        existingSupplier.setOldRiskRating( existingSupplier.getRiskRating() );
        // set new value for risk rating & justification
        existingSupplier.setRiskRating( supp.getRiskRating() );
        existingSupplier.setOverrideJustification( supp.getOverrideJustification() );
        existingSupplier.setItrmaOverrideUsername( username );
        // make sure to change overrideable flag
        existingSupplier.setOverrideable( false );
        // change itrmaOverrode flag
        existingSupplier.setItrmaOverrode( true );
        // set time that this override occurred
        long objCreationTime = System.currentTimeMillis();
        SimpleDateFormat notificationFormat = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss Z" );
        Date objCreationDate = new Date( objCreationTime );
        existingSupplier.setOverrideTime( notificationFormat.format( objCreationDate ) );
        suppliers.save( existingSupplier );

        Notification successNotification = new Notification();
        successNotification.setId( getNotificationId() );
        successNotification.setSubject( "Overrode Risk Score For \"" + existingSupplier.getName() + "\"" );
        successNotification.setMessage( "The Risk Assessment Score for supplier \"" + existingSupplier.getName()
                + "\" has been overriden by: " + username + ". Changed from \"" + existingSupplier.getOldRiskRating()
                + "\" to \"" + existingSupplier.getRiskRating() + ".\"" );
        successNotification.setSender( "SRMS System" );

        // For now, send to all Merck side users that aren't ITRMAs, needs to be
        // fixed in the future
        successNotification.setReceiver( "proc" );
        notifRepo.save( successNotification );

        successNotification.setId( getNotificationId() );
        successNotification.setReceiver( "busowner" );
        notifRepo.save( successNotification );

        successNotification.setId( getNotificationId() );
        successNotification.setReceiver( "johndoe" );
        notifRepo.save( successNotification );

        // System.out.println( "Submit Override Form Controller: " + supplierId
        // );
        // System.out.println( "Submit Override Form Controller: " +
        // supp.getRiskRating() );
        // System.out.println( "Submit Override Form Controller: " +
        // supp.getOverrideJustification() );
        redirectAttributes.addFlashAttribute( "message", "Successfully Overrode Risk Assessment Score." );
        redirectAttributes.addFlashAttribute( "alertClass", "alert-success" );
        return ResponseEntity.status( HttpStatus.MOVED_PERMANENTLY )
                .header( HttpHeaders.LOCATION, "/itrma/itrma_index" ).build();
    }

    // helper method for getting a notification ID
    private String getNotificationId () {
        String s = "n";
        IDCounter idc = idCounters.findAll().get( 0 );
        s += idc.getNotificationIdCounter();
        idc.setNotificationIdCounter( idc.getNotificationIdCounter() + 1 );
        idCounters.save( idc );
        return s;
    }

}
