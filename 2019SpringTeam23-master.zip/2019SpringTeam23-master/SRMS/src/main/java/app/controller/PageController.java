package app.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import app.model.Notification;
import app.model.Privilege;
import app.model.Supplier;
import app.model.User;
import app.model.database.NotificationRepository;
import app.model.database.SupplierRepository;
import app.model.database.UserRepository;
import app.model.forms.AccessAuthentication;
import app.model.forms.InformationDataElements;
import app.model.forms.InitialEngagementFactors;
import app.model.forms.LegalRequirements;
import app.model.forms.SeverityRiskQuestions;

// contains REST endpoints for all user views / page views in SRMS
@Controller
@SessionAttributes ( { "oldNotif", "oldAddSupp" } )
public class PageController {

    @Autowired
    private SupplierRepository     suppliers;

    @Autowired
    private UserRepository         users;

    @Autowired
    private NotificationRepository notifRepo;

    /** ============== HELPER METHODS ============== */
    /**
     * Does the current user have authorization to access this supplier
     *
     * @param supplierId
     *            ID of supplier to check
     * @return True if user does have authorization, false if they do not have
     *         authorization
     */
    private boolean currentUserHasSupplierAuthorization ( String supplierId ) {
        UserDetails userDets = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        // procurement analysts and ITRMAs have access to all suppliers in the
        // SRMS system
        if ( userDets.getAuthorities().iterator().next().getAuthority().equals( Privilege.PROCUREMENT_ANALYST ) ) {
            return true;
        }
        if ( userDets.getAuthorities().iterator().next().getAuthority().equals( Privilege.RISK_ANALYST ) ) {
            return true;
        }
        User currentUser = users.findByUsername( userDets.getUsername() );
        if ( currentUser.getSupplierIds().contains( supplierId ) ) {
            return true;
        }
        // default deny
        return false;
    }

    /** Miscellaneous or temporary */

    @GetMapping ( value = "/projects" )
    public String projectsPage () {
        return "/shared_views/projects";
    }

    @GetMapping ( value = "/supplierTable" )
    public String supplierTable () {
        return "/shared_views/supplierTable";
    }

    @GetMapping ( value = "/layout" )
    public String layout () {
        return "/templates/fragments/layout";
    }

    @GetMapping ( value = "/login_support" )
    public String loginSupportPage () {
        return "login_support";
    }

    @GetMapping ( value = "/confirm_logout" )
    public String logoutConfirmation () {
        return "confirm_logout";
    }

    /** Shared Views */

    /**
     * Checks if the risk assessment score was overriden by an ITRMA, and if it
     * was return a readonly description page of the override, otherwise pass to
     * severityRiskForm
     *
     * @param model
     *            To inject into the frontend pages
     * @param supplierId
     *            The supplier ID to check
     * @return String value of page to return
     */
    @GetMapping ( value = "/shared_views/check_override/{supplierId}" )
    public String checkIfOverriden ( @PathVariable String supplierId, Model model ) {

        // if the current user doesn't have access to the supplierId, present
        // them with error page
        if ( !currentUserHasSupplierAuthorization( supplierId ) ) {
            model.addAttribute( "errorMsg", "Resource Error." );
            return "/error";
        }

        Supplier supplier = suppliers.getSupplierById( supplierId );
        if ( supplier == null ) {
            model.addAttribute( "errorMsg", "No such supplier exists." );
            return "/error";
        }
        // if it was overridden by an ITRMA
        if ( supplier.isItrmaOverrode() ) {
            model.addAttribute( "supplier", supplier );
            model.addAttribute( "supplierId", supplierId );
            return "/shared_views/forms/override_readonly";
        }
        return severityRiskForm( supplierId, model );
    }

    @GetMapping ( value = "shared_views/severity_risk/{supplierId}" )
    public String severityRiskForm ( @PathVariable String supplierId, Model model ) {

        // if the current user doesn't have access to the supplierId, present
        // them with error page
        if ( !currentUserHasSupplierAuthorization( supplierId ) ) {
            model.addAttribute( "errorMsg", "Resource Error." );
            return "/error";
        }

        Supplier supplier = suppliers.getSupplierById( supplierId );
        SeverityRiskQuestions srq = supplier.getScopingQuestions().getSeverityRiskQuestions();
        model.addAttribute( "supplierName", supplier.getName() );
        model.addAttribute( "srq", srq );
        model.addAttribute( "supplierId", supplierId );
        if ( supplier.getScopingQuestions().isComplete() ) {
            return "shared_views/forms/severity_risk_readonly";
        }
        UserDetails u = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if ( !u.getAuthorities().iterator().next().getAuthority().equals( Privilege.BUSINESS_OWNER ) ) {
            return "shared_views/forms/severity_risk_readonly";
        }
        return "shared_views/forms/severity_risk";
    }

    @GetMapping ( "shared_views/initialEngagementFactors/{supplierId}" )
    public String initialEngagementFactorsForm ( @PathVariable String supplierId, Model model ) {

        // if the current user doesn't have access to the supplierId, present
        // them with error page
        if ( !currentUserHasSupplierAuthorization( supplierId ) ) {
            model.addAttribute( "errorMsg", "Resource Error." );
            return "/error";
        }

        Supplier supplier = suppliers.getSupplierById( supplierId );
        InitialEngagementFactors ief = supplier.getScopingQuestions().getInitialEngagementFactors();

        // Checkboxes for serviceType
        List<String> serviceTypeCheckboxes = new ArrayList<String>();
        serviceTypeCheckboxes.add(
                " Software Purchase Only - Software development or purchase (including commercial off-the-shelf (COTS)), to be hosted in a Merck controlled environment." );
        serviceTypeCheckboxes.add(
                " Application Service Provider (ASP) - Service providing hosted software solution (e.g. ASP, SaaS (Software as a Service)" );
        serviceTypeCheckboxes.add(
                " Platform/Infrastructure as a Service - Service providing hosted infrastructure solutions (e.g. PaaS, IaaS, etc.)" );
        serviceTypeCheckboxes.add(
                " In-House Contracted/Consultant Services - Consultants and/or Contract personnel using Merck issued hardware (e.g. laptop, mobile devices)" );
        serviceTypeCheckboxes.add(
                " Offsite Contracted/Consultant Services - Consultants and/or Contract personnel NOT using Merck issued hardware (e.g. remote, offsite, Citrix)" );
        serviceTypeCheckboxes.add(
                " Business Service Provider - Supplier providing a service, including business function being outsourced or managed by a Third Party" );
        serviceTypeCheckboxes.add( " Legal Support Services - Suppliers providing Legal support services." );
        serviceTypeCheckboxes
                .add( " Manufacturing Service - Supplier providing manufacturing support services on behalf of Merck" );
        serviceTypeCheckboxes
                .add( " Third Party Administration - Supplier that processes employee benefits for Merck" );

        model.addAttribute( "serviceTypeCheckboxes", serviceTypeCheckboxes );

        model.addAttribute( "supplierName", supplier.getName() );
        model.addAttribute( "ief", ief );
        model.addAttribute( "supplierId", supplierId );
        if ( supplier.getScopingQuestions().isComplete() ) {
            return "shared_views/forms/initialEngagementFactors_readonly";
        }
        UserDetails u = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if ( !u.getAuthorities().iterator().next().getAuthority().equals( Privilege.BUSINESS_OWNER ) ) {
            return "shared_views/forms/initialEngagementFactors_readonly";
        }
        return "shared_views/forms/initialEngagementFactors";
    }

    @GetMapping ( value = "shared_views/informationDataElements/{supplierId}" )
    public String informationDataElementsForm ( @PathVariable String supplierId, Model model ) {

        // if the current user doesn't have access to the supplierId, present
        // them with error page
        if ( !currentUserHasSupplierAuthorization( supplierId ) ) {
            model.addAttribute( "errorMsg", "Resource Error." );
            return "/error";
        }

        Supplier supplier = suppliers.getSupplierById( supplierId );
        InformationDataElements ide = supplier.getScopingQuestions().getInformationDataElements();

        // Checkboxes for serviceType
        List<String> confidentialInfoCheckboxes = new ArrayList<String>();
        confidentialInfoCheckboxes.add( " Merck Intellectual Property (IP)" );
        confidentialInfoCheckboxes.add( " Financial Information" );
        confidentialInfoCheckboxes.add( " Payroll Information" );
        confidentialInfoCheckboxes.add( " Clinical Study Information" );
        confidentialInfoCheckboxes.add( " None" );

        model.addAttribute( "confidentialInfoCheckboxes", confidentialInfoCheckboxes );
        model.addAttribute( "supplierId", supplierId );

        List<String> merckInfoCheckboxes = Stream.of(
                " Internal Use Only - Information typically required to perform normal day-to-day work and may be accessed by all Merck Personnel.",
                " Confidential - Information whose unauthorized disclosure or compromise would directly or indirectly have an adverse impact on Merck, its customers, shareholders or employees.",
                " Restricted - Information that is intended for a very limited group of individuals who should be specified by name.",
                " Non-Public Merck information is not involved with this engagement." ).collect( Collectors.toList() );

        model.addAttribute( "merckInfoCheckboxes", merckInfoCheckboxes );

        List<String> generalIdentificationCheckboxes = Stream
                .of( " Name", " Mailing Address", " Email Address", " Date of Birth", " Phone Number", " WIN Number",
                        " Gender", " Mother's Maiden Name", " None of the above" )
                .collect( Collectors.toList() );

        model.addAttribute( "generalIdentificationCheckboxes", generalIdentificationCheckboxes );

        List<String> govmtInfoCheckboxes = Stream.of( " Drivers License Number", " Military ID Number",
                " National Identification Number", " Passport Number", " Social Security Number",
                " State Identification Number", " Tax Identification Number", " None of the above" )
                .collect( Collectors.toList() );

        model.addAttribute( "govmtInfoCheckboxes", govmtInfoCheckboxes );

        List<String> financialInfoCheckboxes = Stream.of( " Credit Card Number", " Debit Card Number",
                " Pre-Paid Card Number", " Financial Account Number", " Tax Information", " None of the above" )
                .collect( Collectors.toList() );

        model.addAttribute( "financialInfoCheckboxes", financialInfoCheckboxes );

        List<String> sensitiveInfoCheckboxes = Stream
                .of( " Civil or Criminal Information", " Education Records", " Employment Records",
                        " Digital Signature", " Racial or Ethnic Origin", " Sexual Orientation",
                        " Prescription Drug Information", " Medical History", " None of the above" )
                .collect( Collectors.toList() );

        model.addAttribute( "sensitiveInfoCheckboxes", sensitiveInfoCheckboxes );

        List<String> technicalIdentifiersCheckboxes = Stream
                .of( " IP Address", " UserID or Username and Password", " Security code, PIN or access code, etc.",
                        " Geolocation", " Device ID (e.g., MAC Address)", " None of the above" )
                .collect( Collectors.toList() );

        model.addAttribute( "technicalIdentifiersCheckboxes", technicalIdentifiersCheckboxes );

        List<String> biometricIdentifiersCheckboxes = Stream
                .of( " Fingerprint", " Genetic Information", " Retinal or Iris Scan", " Voiceprint",
                        " Photographic Facial Images or Facial Geometry", " None of the above" )
                .collect( Collectors.toList() );

        model.addAttribute( "biometricIdentifiersCheckboxes", biometricIdentifiersCheckboxes );

        List<String> whoseInformationCheckboxes = Stream.of( " Employees", " Contract Employees", " Customers",
                " Potential Customers", " Health Care Practitioner", " None" ).collect( Collectors.toList() );

        model.addAttribute( "whoseInformationCheckboxes", whoseInformationCheckboxes );

        List<String> countriesOfResidenceCheckboxes = Stream
                .of( " United States", " Japan", " China", " Singapore", " Hong Kong", " South Korea", " Chile",
                        " Argentina", " Colombia", " Ireland", " Wales", " England", " Scotland", " Canada", " Mexico" )
                .collect( Collectors.toList() );

        model.addAttribute( "countriesOfResidenceCheckboxes", countriesOfResidenceCheckboxes );

        model.addAttribute( "supplierName", supplier.getName() );
        model.addAttribute( "ide", ide );
        if ( supplier.getScopingQuestions().isComplete() ) {
            return "shared_views/forms/informationDataElements_readonly";
        }
        UserDetails u = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if ( !u.getAuthorities().iterator().next().getAuthority().equals( Privilege.BUSINESS_OWNER ) ) {
            return "shared_views/forms/informationDataElements_readonly";
        }
        return "shared_views/forms/informationDataElements";
    }

    @GetMapping ( value = "shared_views/legalContractRequirements/{supplierId}" )
    public String legalContractRequirementsForm ( @PathVariable String supplierId, Model model ) {

        // if the current user doesn't have access to the supplierId, present
        // them with error page
        if ( !currentUserHasSupplierAuthorization( supplierId ) ) {
            model.addAttribute( "errorMsg", "Resource Error." );
            return "/error";
        }

        Supplier supplier = suppliers.getSupplierById( supplierId );
        LegalRequirements lr = supplier.getScopingQuestions().getLegalRequirements();

        model.addAttribute( "supplierName", supplier.getName() );
        model.addAttribute( "lr", lr );
        model.addAttribute( "supplierId", supplierId );
        if ( supplier.getScopingQuestions().isComplete() ) {
            return "shared_views/forms/legalContractRequirements_readonly";
        }
        UserDetails u = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        // System.out.println(
        // u.getAuthorities().iterator().next().getAuthority() );
        if ( !u.getAuthorities().iterator().next().getAuthority().equals( Privilege.BUSINESS_OWNER ) ) {
            return "shared_views/forms/legalContractRequirements_readonly";
        }
        return "shared_views/forms/legalContractRequirements";
    }

    @GetMapping ( value = "shared_views/accessAuthentication/{supplierId}" )
    public String accessAuthenticationForm ( @PathVariable String supplierId, Model model ) {

        // if the current user doesn't have access to the supplierId, present
        // them with error page
        if ( !currentUserHasSupplierAuthorization( supplierId ) ) {
            model.addAttribute( "errorMsg", "Resource Error." );
            return "/error";
        }

        Supplier supplier = suppliers.getSupplierById( supplierId );
        AccessAuthentication aa = supplier.getScopingQuestions().getAccessAuthentication();

        model.addAttribute( "supplierName", supplier.getName() );
        model.addAttribute( "aa", aa );
        model.addAttribute( "supplierId", supplierId );
        if ( supplier.getScopingQuestions().isComplete() ) {
            return "shared_views/forms/accessAuthentication_readonly";
        }
        UserDetails u = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if ( !u.getAuthorities().iterator().next().getAuthority().equals( Privilege.BUSINESS_OWNER ) ) {
            return "shared_views/forms/accessAuthentication_readonly";
        }
        return "shared_views/forms/accessAuthentication";
    }

    @ModelAttribute ( "oldNotif" )
    public Notification getOldNotifObj () {
        return new Notification();
    }

    @GetMapping ( value = "/shared_views/notificationsSend" )
    public String notificationsSendView ( @ModelAttribute ( "oldNotif" ) Notification oldNotif,
            @RequestParam ( value = "to", required = false ) String to, Model model ) {

        Notification composedNewNotif = new Notification();
        composedNewNotif.setReceiver( to );

        if ( oldNotif != null ) {
            // System.out.println( "OLD NOTIF SUBJECT: " + oldNotif.getSubject()
            // );
            // System.out.println( "OLD NOTIF MSG: " + oldNotif.getMessage() );
            composedNewNotif.setSubject( oldNotif.getSubject() );
            composedNewNotif.setMessage( oldNotif.getMessage() );
            oldNotif.setSubject( "" );
            oldNotif.setMessage( "" );
        }

        model.addAttribute( "notification", composedNewNotif );

        return "/shared_views/notificationsSend";
    }

    @GetMapping ( value = "/shared_views/notificationsReceive/{notificationId}" )
    public String notificationsReceiveView ( @PathVariable String notificationId, Model model ) {

        Notification passedInNotification = notifRepo.findById( notificationId ).get();

        if ( passedInNotification == null ) {
            model.addAttribute( "errorMsg", "No such notification ID." );
            return "/error";
        }

        UserDetails u = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String currentlyLoggedInUsername = u.getUsername();

        if ( !passedInNotification.getReceiver().equals( currentlyLoggedInUsername ) ) {
            model.addAttribute( "errorMsg", "Forbidden." );
            return "/error";
        }

        // mark this notification as read if it is unread
        if ( !passedInNotification.isRead() ) {
            passedInNotification.setRead( true );
            notifRepo.save( passedInNotification );
        }

        model.addAttribute( "notification", passedInNotification );
        return "/shared_views/notificationsReceive";
    }

    /** Account Manager */

    @GetMapping ( value = "/accman/accman_index" )
    public String accmanIndexPage () {
        return "/accman/accman_index";
    }

    @GetMapping ( value = "/accman/contracts" )
    public String accmanContracts () {
        return "/accman/contracts";
    }

    @GetMapping ( value = "/accman/scoping" )
    public String goToScopingFormsAccMan ( Model model ) {
        UserDetails u = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        User user = users.findByUsername( u.getUsername() );
        return checkIfOverriden( user.getSupplierIds().get( 0 ), model );
    }

    /** Admin User */

    @GetMapping ( value = "/admin/admin_index" )
    public String adminIndexPage () {
        return "/admin/admin_index";
    }

    /** Business Owner */

    @GetMapping ( value = "/busowner/busowner_index" )
    public String busownerIndexPage () {
        return "/busowner/busowner_index";
    }

    @GetMapping ( value = "/busowner/find_suppliers" )
    public String busownerFindSupp () {
        return "/busowner/find_suppliers";
    }

    @GetMapping ( value = "/busowner/edit_info" )
    public String busownerEditInfo () {
        return "/busowner/edit_info";
    }

    /** Information Supplier */

    @GetMapping ( value = "/infsup/infsup_index" )
    public String infsupIndexPage () {
        return "/infsup/infsup_index";
    }

    @GetMapping ( value = "/infsup/scoping" )
    public String goToScopingFormsInfSup ( Model model ) {
        UserDetails u = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        User user = users.findByUsername( u.getUsername() );
        return checkIfOverriden( user.getSupplierIds().get( 0 ), model );
    }

    /** IT Risk Management Analyst */

    @GetMapping ( value = "/itrma/itrma_index" )
    public String itrmaIndexPage () {
        // return "/itrma/itrma_index";
        return "/shared_views/supplierTable";
    }

    @GetMapping ( value = "/itrma/override_score/{supplierId}" )
    public String overrideScoreForm ( @PathVariable String supplierId, Model model ) {
        Supplier passedInSupp = suppliers.getSupplierById( supplierId );
        if ( passedInSupp == null ) {
            model.addAttribute( "errorMsg", "No such supplier exists." );
            return "/error";
        }
        // check if supplier with this ID is overrideable, if NOT overrideable,
        // return an error page
        if ( !passedInSupp.isOverrideable() ) {
            model.addAttribute( "errorMsg", supplierId + " is not overrideable." );
            return "/error";
        }
        model.addAttribute( "supplier", passedInSupp );
        return "/itrma/override_score";
    }

    /** Procurement Analyst */

    @GetMapping ( value = "/proc/proc_index" )
    public String procIndexPage () {
        // return "/proc/proc_index";
        return "/shared_views/supplierTable";
    }

    @ModelAttribute ( "oldAddSupp" )
    public Supplier getOldAddSuppObj () {
        // System.out.println( "This was executed" );
        Supplier oldAddSupp = new Supplier();
        oldAddSupp.setName( "" );
        oldAddSupp.setParentCompany( "" );
        oldAddSupp.setType( "" );
        oldAddSupp.setDescription( "" );
        oldAddSupp.setDUNS( 0 );
        return oldAddSupp;
    }

    @GetMapping ( value = "/proc/add_supplier" )
    public String procAddSuppPage ( Model model, @ModelAttribute ( "oldAddSupp" ) Supplier oldAddSupp ) {

        Supplier newSupp = new Supplier();

        if ( oldAddSupp != null ) {
            // System.out.println( "OLD SUPP NAME: " + oldAddSupp.getName() );
            // System.out.println( "OLD SUPP PARENT COMPANY: " +
            // oldAddSupp.getParentCompany() );
            newSupp.setName( oldAddSupp.getName() );
            newSupp.setParentCompany( oldAddSupp.getParentCompany() );
            newSupp.setType( oldAddSupp.getType() );
            newSupp.setDescription( oldAddSupp.getDescription() );
            newSupp.setDUNS( oldAddSupp.getDUNS() );

            oldAddSupp.setName( "" );
            oldAddSupp.setParentCompany( "" );
            oldAddSupp.setType( "" );
            oldAddSupp.setDescription( "" );
            oldAddSupp.setDUNS( 0 );
            // System.out.println( "OLD SUPP NAME 2: " + oldAddSupp.getName() );
            // System.out.println( "OLD SUPP PARENT COMPANY 2: " +
            // oldAddSupp.getParentCompany() );
        }
        model.addAttribute( "supplier", newSupp );
        return "/proc/add_supplier";
    }

    @GetMapping ( value = "/proc/assign_bo/{supplierId}" )
    public String assignBusinessOwner ( @PathVariable String supplierId, Model model ) {
        Supplier passedInSupp = suppliers.getSupplierById( supplierId );
        if ( passedInSupp == null ) {
            model.addAttribute( "errorMsg", "No such supplier exists." );
            return "/error";
        }
        // check if supplier with this ID is assignable, if NOT assignable,
        // return an error page
        if ( passedInSupp.isAssignedToBO() ) {
            model.addAttribute( "errorMsg", supplierId + " is not assignable." );
            return "/error";
        }
        model.addAttribute( "supplier", passedInSupp );
        return "/proc/assign_bo";
    }

}
