package app.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import app.model.database.UserRepository;

@RestController
public class UserController {

    @Autowired
    private UserRepository users;

    // Note: Might not actually be used, just putting here for starters
    @PostMapping ( "/tbdUserRep1" )
    public long getUsersCount () {
        return users.count();
    }

    @RequestMapping ( value = "/resource" )
    public Map<String, Object> home () {
        Map<String, Object> model = new HashMap<String, Object>();
        model.put( "id", UUID.randomUUID().toString() );
        model.put( "content", "Hello World" );
        System.out.println( "THIS CODE BLOCK WAS RUN." );
        System.out.println( model.get( "content" ) );
        System.out.println( model.get( "id" ) );
        return model;
    }

}
