package app.model.forms;

public class LegalRequirements {

    private String recoveryTime;
    private String recoveryPoint;
    private String legalScope;
    private String legalScopeOtherText;
    private String pciImpact;

    public LegalRequirements () {

    }

    public String getRecoveryTime () {
        return recoveryTime;
    }

    public void setRecoveryTime ( String recoveryTime ) {
        this.recoveryTime = recoveryTime;
    }

    public String getRecoveryPoint () {
        return recoveryPoint;
    }

    public void setRecoveryPoint ( String recoveryPoint ) {
        this.recoveryPoint = recoveryPoint;
    }

    public String getLegalScope () {
        return legalScope;
    }

    public void setLegalScope ( String legalScope ) {
        this.legalScope = legalScope;
    }

    public String getLegalScopeOtherText () {
        return legalScopeOtherText;
    }

    public void setLegalScopeOtherText ( String legalScopeOtherText ) {
        this.legalScopeOtherText = legalScopeOtherText;
    }

    public String getPciImpact () {
        return pciImpact;
    }

    public void setPciImpact ( String pciImpact ) {
        this.pciImpact = pciImpact;
    }

    public boolean isComplete () {
        if ( recoveryTime == null || recoveryPoint == null || legalScope == null || pciImpact == null ) {
            return false;
        }
        if (legalScope.equals("Other") && (legalScopeOtherText == null || legalScopeOtherText.isEmpty())) {
        	return false;
        }
        return true;
    }

}
