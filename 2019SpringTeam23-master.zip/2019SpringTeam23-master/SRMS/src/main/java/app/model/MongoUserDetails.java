package app.model;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * Representation model for users used for authorization/authentication in the
 * system. Representation in UserDetails form for MongoDB.
 *
 * Based off
 * https://github.com/gkatzioura/egkatzioura.wordpress.com/blob/master/SpringSecurityWalkthrough/src/main/java/com/gkatzioura/spring/security/model/MongoUserDetails.java
 *
 * @author Matt
 * @author Gabriel Gloss
 *
 */

public class MongoUserDetails implements UserDetails {

    /**
     * Default UID required by serializable class
     */
    private static final long                             serialVersionUID = 1L;
    /**
     * ID of user, for database
     */
    private String                                        id;
    /**
     * Name of the user
     */
    private String                                        username;
    /**
     * Password of the user
     */
    private String                                        password;
    /**
     * Authorities of user, goes along with Role
     */
    private final Collection< ? extends GrantedAuthority> grantedAuthorities;
    /**
     * Determines whether account is enabled.
     */
    private boolean                                       enabled;
    /**
     * Determines whether account is expired.
     */
    private boolean                                       accountNonExpired;
    /**
     * Determines whether account is locked.
     */
    private boolean                                       accountNonLocked;
    /**
     * Determines whether credentials are expired.
     */
    private boolean                                       credentialsNonExpired;

    /**
     * Generic constructor to create user given all fields
     *
     * @param username
     *            of user
     * @param password
     *            of user
     * @param role
     *            of user
     */
    public MongoUserDetails ( String username, String password, boolean enabled, boolean accountNonExpired,
            boolean credentialsNonExpired, boolean accountNonLocked,
            Collection< ? extends GrantedAuthority> authorities ) {
        this.username = username;
        this.password = password;
        this.grantedAuthorities = authorities;
        this.enabled = enabled;
        this.accountNonExpired = accountNonExpired;
        this.credentialsNonExpired = credentialsNonExpired;
        this.accountNonLocked = accountNonLocked;
    }

    /**
     * Gets the ID of the user
     *
     * @return id of user
     */
    public String getID () {
        return id;
    }

    /**
     * Sets the ID of user
     *
     * @param id
     *            of user
     */
    public void setID ( final String id ) {
        this.id = id;
    }

    /**
     * Gets the username of the user
     *
     * @return username of user
     */
    @Override
    public String getUsername () {
        return username;
    }

    /**
     * Sets the username of the user
     *
     * @param username
     *            of user
     */
    public void setUsername ( final String username ) {
        this.username = username;
    }

    /**
     * Gets the password of the user
     *
     * @return password of user
     */
    @Override
    public String getPassword () {
        return password;
    }

    /**
     * Sets the password of the user
     *
     * @param password
     *            of user
     */
    public void setPassword ( final String password ) {
        this.password = password;
    }

    @Override
    public Collection< ? extends GrantedAuthority> getAuthorities () {
        // System.out.println( "DEBUG: THIS GET AUTHORITIES METHOD WAS CALLED"
        // );
        // for ( final GrantedAuthority grantedAuthority : grantedAuthorities )
        // {
        // System.out.println( "DEBUG ROLE AUTHORITY 1: " +
        // grantedAuthority.getAuthority() );
        // }
        return grantedAuthorities;
    }

    public String getRoleName () {
        // ugly, will just assign the last authority as the name (will work for
        // now in our one-to-one mapping system)
        String roleName = "null";
        for ( final GrantedAuthority grantedAuthority : grantedAuthorities ) {
            if ( grantedAuthority.getAuthority().equals( "PROCUREMENT_ANALYST" ) ) {
                roleName = "Procurement Analyst";
            }
            else if ( grantedAuthority.getAuthority().equals( "BUSINESS_OWNER" ) ) {
                roleName = "Business Owner";
            }
            else if ( grantedAuthority.getAuthority().equals( "RISK_ANALYST" ) ) {
                roleName = "IT Risk Management Analyst";
            }
            else if ( grantedAuthority.getAuthority().equals( "ACCOUNT_MANAGER" ) ) {
                roleName = "Account Manager";
            }
            else if ( grantedAuthority.getAuthority().equals( "INFORMATION_SUPPLIER" ) ) {
                roleName = "Information Supplier";
            }
            else if ( grantedAuthority.getAuthority().equals( "ADMIN" ) ) {
                roleName = "Admin";
                // break b/c this role trumps all others
                break;
            }
        }
        return roleName;
    }

    @Override
    public boolean isAccountNonExpired () {
        return this.accountNonExpired;
    }

    @Override
    public boolean isAccountNonLocked () {
        return this.accountNonLocked;
    }

    @Override
    public boolean isCredentialsNonExpired () {
        return this.credentialsNonExpired;
    }

    @Override
    public boolean isEnabled () {
        return this.enabled;
    }

}
