package app.model.database;

import org.springframework.data.mongodb.repository.MongoRepository;

import app.model.Privilege;

public interface PrivilegeRepository extends MongoRepository<Privilege, String> {

    public Privilege findByName ( String name );

    @Override
    void delete ( Privilege privilege );

}
