package app.model.database;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import app.model.Supplier;

public interface SupplierRepository extends MongoRepository<Supplier, String> {

    Supplier getSuppliersByName ( String s );

    Supplier getSupplierById ( String id );

    List<Supplier> getSuppliersByType ( String type );

    List<Supplier> getSuppliersByNameIgnoreCase ( String s );

}
