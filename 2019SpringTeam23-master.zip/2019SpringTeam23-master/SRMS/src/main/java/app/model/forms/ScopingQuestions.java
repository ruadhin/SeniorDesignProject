package app.model.forms;

import java.util.ArrayList;
import java.util.List;

public class ScopingQuestions {

    /**
     * Scoping question forms
     */
    private SeverityRiskQuestions    severityRiskQuestions;
    private InitialEngagementFactors initialEngagementFactors;
    private InformationDataElements  informationDataElements;
    private LegalRequirements        legalRequirements;
    private AccessAuthentication     accessAuthentication;

    private boolean                  complete;

    private List<String>             interestedUsers;

    public ScopingQuestions () {
        severityRiskQuestions = new SeverityRiskQuestions();
        initialEngagementFactors = new InitialEngagementFactors();
        informationDataElements = new InformationDataElements();
        legalRequirements = new LegalRequirements();
        accessAuthentication = new AccessAuthentication();
        interestedUsers = new ArrayList<String>();
    }

    /**
     * Gets the severity risk form
     *
     * @return severity risk form
     */
    public SeverityRiskQuestions getSeverityRiskQuestions () {
        return severityRiskQuestions;
    }

    /**
     * Sets the severity risk form
     *
     * @param severityRiskQuestions
     *            form to set
     */
    public void setSeverityRiskQuestions ( SeverityRiskQuestions severityRiskQuestions ) {
        this.severityRiskQuestions = severityRiskQuestions;
    }

    /**
     * Gets the initial engagement form
     *
     * @return form
     */
    public InitialEngagementFactors getInitialEngagementFactors () {
        return initialEngagementFactors;
    }

    /**
     * Sets the initial engagement form
     *
     * @param initialEngagementFactors
     *            form
     */
    public void setInitialEngagementFactors ( InitialEngagementFactors initialEngagementFactors ) {
        this.initialEngagementFactors = initialEngagementFactors;
    }

    /**
     * Gets the information data element form
     *
     * @return form
     */
    public InformationDataElements getInformationDataElements () {
        return informationDataElements;
    }

    /**
     * Sets the information data elements
     *
     * @param informationDataElements
     *            form
     */
    public void setInformationDataElements ( InformationDataElements informationDataElements ) {
        this.informationDataElements = informationDataElements;
    }

    /**
     * Gets the legal requirement form
     *
     * @return form
     */
    public LegalRequirements getLegalRequirements () {
        return legalRequirements;
    }

    /**
     * Sets the legal requirements form
     *
     * @param legalRequirements
     *            form
     */
    public void setLegalRequirements ( LegalRequirements legalRequirements ) {
        this.legalRequirements = legalRequirements;
    }

    /**
     * Gets the access and authentication form
     *
     * @return form
     */
    public AccessAuthentication getAccessAuthentication () {
        return accessAuthentication;
    }

    /**
     * Sets the access and authentication form
     *
     * @param accessAuthentication
     *            form
     */
    public void setAccessAuthentication ( AccessAuthentication accessAuthentication ) {
        this.accessAuthentication = accessAuthentication;
    }

    public boolean isComplete () {
        return complete;
    }

    public void setComplete ( boolean complete ) {
        this.complete = complete;
    }

    public List<String> getInterestedUsers () {
        return interestedUsers;
    }

    public int getCompletion () {
        int completion = 0;
        if ( severityRiskQuestions.isComplete() ) {
            completion += 20;
        }
        if ( initialEngagementFactors.isComplete() ) {
            completion += 20;
        }
        if ( informationDataElements.isComplete() ) {
            completion += 20;
        }
        if ( legalRequirements.isComplete() ) {
            completion += 20;
        }
        if ( accessAuthentication.isComplete() ) {
            completion += 20;
        }
        return completion;
    }

}
