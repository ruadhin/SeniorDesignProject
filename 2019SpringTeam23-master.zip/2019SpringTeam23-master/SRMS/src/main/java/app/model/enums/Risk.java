package app.model.enums;

public enum Risk {
	
	INFORMATIONAL(1),
	LOW(2),
	MEDIUM(3),
	HIGH(4),
	CRITICAL(5);
	
	public final int value;
	
	private Risk(int value) {
		this.value = value;
	}

}
