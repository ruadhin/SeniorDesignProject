package app.model;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Notification {

    private String  sender;
    private String  receiver;
    private String  subject;
    private String  message;
    private String  id;
    private String  notificationTimeUnix;
    private String  notificationTimeReadable;
    private boolean isRead;

    public Notification () {
        // probably not the best to have this here, but need something working
        // for now
        long objCreationTime = System.currentTimeMillis();
        SimpleDateFormat notificationFormat = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss Z" );
        Date objCreationDate = new Date( objCreationTime );
        this.setNotificationTimeReadable( notificationFormat.format( objCreationDate ) );

        // keep it in UNIX time format
        this.setNotificationTimeUnix( String.valueOf( System.currentTimeMillis() ) );
    }

    public String getSender () {
        return sender;
    }

    public void setSender ( final String sender ) {
        this.sender = sender;
    }

    public String getReceiver () {
        return receiver;
    }

    public void setReceiver ( final String receiver ) {
        this.receiver = receiver;
    }

    public String getSubject () {
        return subject;
    }

    public void setSubject ( final String subject ) {
        this.subject = subject;
    }

    public String getMessage () {
        return message;
    }

    public void setMessage ( final String message ) {

        this.message = message;
    }

    public boolean isRead () {
        return isRead;
    }

    public void setRead ( final boolean isRead ) {
        this.isRead = isRead;

    }

    public String getNotificationTimeUnix () {
        return notificationTimeUnix;
    }

    public void setNotificationTimeUnix ( String string ) {
        this.notificationTimeUnix = string;
    }

    public String getNotificationTimeReadable () {
        return notificationTimeReadable;
    }

    public void setNotificationTimeReadable ( String notificationTimeReadable ) {
        this.notificationTimeReadable = notificationTimeReadable;
    }

    /**
     * @return the id
     */
    public String getId () {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId ( final String id ) {
        this.id = id;
    }
}
