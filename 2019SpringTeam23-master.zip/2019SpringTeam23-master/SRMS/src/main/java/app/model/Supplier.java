package app.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

import app.model.forms.ScopingQuestions;

@Document ( collection = "Suppliers" )
public class Supplier {

    /**
     * Constants for risk rating
     */
    public static final String RR_CRIT       = "Critical";
    public static final String RR_HIGH       = "High";
    public static final String RR_MED        = "Medium";
    public static final String RR_LOW        = "Low";
    public static final String RR_IP         = "In Progress";
    public static final String RR_ALL        = "All";

    /**
     * Constants for Supplier type
     */
    public static final String TYPE_GPC      = "grandparentCompany";
    public static final String TYPE_PC       = "parentCompany";
    public static final String TYPE_PROJ     = "project";

    /**
     * Used for creating auto-generated data like ID
     */
    @Transient
    public static final String SEQUENCE_NAME = "suppliers_sequence";

    /**
     * ID of supplier
     */
    @Id
    private String             id;
    /**
     * Name of supplier
     */
    private String             name;
    /**
     * 'text' field is same as name field, needed for some frontend capabilities
     */
    private String             text;
    /**
     * Name of parent company
     */
    private String             parentCompany;
    /**
     * Description of what this supplier provides to Merck
     */
    private String             description;
    /**
     * Used in hierarchical structure to determine where to place this supplier
     * or project Can be of type: 'grandparent, parent, project'
     */
    private String             type;
    /**
     * Used in hierarchical structure to determine where to place this supplier
     */
    private String             icon;
    /**
     * Used in hierarchical structure to determine which suppliers are nodes of
     * this supplier
     */
    private List<Supplier>     nodes;
    /**
     * Scoping question forms
     */
    private ScopingQuestions   scopingQuestions;
    /**
     * Choices for riskRating are: Critical, High, Medium, Low, In Progress
     */
    private String             riskRating;
    /**
     * The button color that corresponds to riskRating
     */
    private String             riskRatingColor;
    /**
     * Percentage completion of risk assessment, on 0-100 scale. Usually goes up
     * by increments of 20 because there are (currently) five risk assessment
     * forms (20x5=100)
     */
    private int                riskAssessmentStatus;
    /**
     * The color that corresponds to riskAssessmentStatus In Progress: >0% but
     * <50%; red; danger In Progress: >50% but <100%; orange; warning Complete:
     * 100%; green; success
     */
    private String             riskAssessmentStatusColor;

    private long               DUNS;
    /**
     * Whether or not this Supplier's risk rating is overrideable by an ITRMA
     */
    private boolean            overrideable;
    /**
     * Whether or not an ITRMA overrode this Supplier's risk rating, defaults to
     * FALSE
     */
    private boolean            itrmaOverrode;
    /**
     * Username of ITRMA that overrode the risk score
     */
    private String             itrmaOverrideUsername;
    /**
     * The justification text that ITRMA uses if they override the risk score
     */
    private String             overrideJustification;
    /**
     * The timestamp when the ITRMA overrode this supplier. Format: "yyyy-MM-dd
     * HH:mm:ss Z"
     */
    private String             overrideTime;
    /**
     * The risk rating prior to ITRMA's override
     */
    private String             oldRiskRating;
    /**
     * Whether or not this supplier has been assigned to a business owner True
     * if it has, false if it has not
     */
    private boolean            assignedToBO;
    /**
     * Username of procurement analyst that assigned this supplier to a BO
     */
    private String             procAssignedUsername;
    /**
     * Username of business owner that was assigned to by procurement analyst
     */
    private String             boAssignedUsername;
    /**
     * The timestamp when the procurement assigned this supplier. Format:
     * "yyyy-MM-dd HH:mm:ss Z"
     */
    private String             procAssignedTime;

    /**
     * Empty constructor, creates empty scoping forms by default
     */
    public Supplier () {
        scopingQuestions = new ScopingQuestions();
        nodes = null;
        this.setRiskAssessmentStatus( 0 );
        this.setRiskRating( RR_IP );
        this.setItrmaOverrode( false );
        this.setAssignedToBO( false );
    }

    /**
     * Gets the ID of supplier
     *
     * @return id of supplier
     */
    public String getId () {
        return id;
    }

    /**
     * Sets the ID of supplier
     *
     * @param id
     *            to set
     */
    public void setID ( final String id ) {
        this.id = id;
    }

    /**
     * Gets the name of supplier
     *
     * @return name of supplier
     */
    public String getName () {
        return name;
    }

    /**
     * Sets name of supplier
     *
     * @param name
     *            to set
     */
    public void setName ( String name ) {
        // maximum name length should be 20 characters
        // if ( name.length() > 20 ) {
        // name = name.substring( 0, 20 );
        // }
        this.name = name;
        this.setText( name );
    }

    public String getText () {
        return text;
    }

    public void setText ( String text ) {
        this.text = text;
    }

    /**
     * Gets the name of the parent company if it exists
     *
     * @return parent company name
     */
    public String getParentCompany () {
        return parentCompany;
    }

    /**
     * Sets the name of the parent company
     *
     * @param parentCompany
     *            name to set
     */
    public void setParentCompany ( String parentCompany ) {
        this.parentCompany = parentCompany;
        if ( parentCompany.equals( "None" ) ) {
            // they are grandparent company
            this.setType( TYPE_GPC );
        }
    }

    public String getDescription () {
        return description;
    }

    public void setDescription ( String description ) {
        this.description = description;
    }

    public String getType () {
        return type;
    }

    public void setType ( String type ) {
        this.type = type;
        if ( type.equals( TYPE_PROJ ) ) {
            this.setIcon( "glyphicon glyphicon-file" );
        }
        else {
            this.setIcon( "" );
        }
    }

    public String getIcon () {
        return icon;
    }

    public void setIcon ( String icon ) {
        this.icon = icon;
    }

    public List<Supplier> getNodes () {
        return nodes;
    }

    public void setNodes ( List<Supplier> nodes ) {
        this.nodes = nodes;
    }

    public String getRiskRating () {
        return riskRating;
    }

    public void setRiskRating ( String riskRating ) {
        this.riskRating = riskRating;
        this.overrideable = true;
        if ( riskRating.equals( RR_CRIT ) ) {
            this.setRiskRatingColor( "red" );
        }
        else if ( riskRating.equals( RR_HIGH ) ) {
            this.setRiskRatingColor( "orange" );
        }
        else if ( riskRating.equals( RR_MED ) ) {
            this.setRiskRatingColor( "yellow" );
        }
        else if ( riskRating.equals( RR_LOW ) ) {
            this.setRiskRatingColor( "GreenYellow" );
        }
        else {
            // usually risk rating "In Progress"
            this.overrideable = false;
            this.setRiskRatingColor( "white" );
        }
    }

    public String getRiskRatingColor () {
        return riskRatingColor;
    }

    public void setRiskRatingColor ( String riskRatingColor ) {
        this.riskRatingColor = riskRatingColor;
    }

    public int getRiskAssessmentStatus () {
        return riskAssessmentStatus;
    }

    public void setRiskAssessmentStatus ( int riskAssessmentStatus ) {
        this.riskAssessmentStatus = riskAssessmentStatus;
        if ( ( riskAssessmentStatus == 100 ) && this.getScopingQuestions().isComplete() ) {
            // otherwise randomly select a risk rating, this is temporary
            // solution for Merck's automated risk assessment
            String[] choices = new String[] { RR_CRIT, RR_HIGH, RR_MED, RR_LOW };
            String randomChoice = choices[(int) ( Math.random() * choices.length )];
            this.setRiskRating( randomChoice );
        }
        // The color that corresponds to riskAssessmentStatus
        // In Progress: >0% but <50%; red; danger
        // In Progress: >50% but <100%; orange; warning
        // Complete: 100%; green; success
        if ( riskAssessmentStatus < 50 ) {
            this.setRiskAssessmentStatusColor( "danger" );
        }
        else if ( riskAssessmentStatus < 100 ) {
            this.setRiskAssessmentStatusColor( "warning" );
        }
        else {
            this.setRiskAssessmentStatusColor( "success" );
        }
    }

    public long getDUNS () {
        return this.DUNS;
    }

    public void setDUNS ( long DUNS ) {
        this.DUNS = DUNS;
    }

    public boolean isOverrideable () {
        return overrideable;
    }

    public void setOverrideable ( boolean overrideable ) {
        this.overrideable = overrideable;
    }

    public boolean isItrmaOverrode () {
        return itrmaOverrode;
    }

    public void setItrmaOverrode ( boolean itrmaOverrode ) {
        this.itrmaOverrode = itrmaOverrode;
    }

    public String getOverrideJustification () {
        return overrideJustification;
    }

    public void setOverrideJustification ( String overrideJustification ) {
        this.overrideJustification = overrideJustification;
    }

    public String getItrmaOverrideUsername () {
        return itrmaOverrideUsername;
    }

    public void setItrmaOverrideUsername ( String itrmaOverrideUsername ) {
        this.itrmaOverrideUsername = itrmaOverrideUsername;
    }

    public String getOverrideTime () {
        return overrideTime;
    }

    public void setOverrideTime ( String overrideTime ) {
        this.overrideTime = overrideTime;
    }

    public String getOldRiskRating () {
        return oldRiskRating;
    }

    public void setOldRiskRating ( String oldRiskRating ) {
        this.oldRiskRating = oldRiskRating;
    }

    public boolean isAssignedToBO () {
        return assignedToBO;
    }

    public void setAssignedToBO ( boolean assignedToBO ) {
        this.assignedToBO = assignedToBO;
    }

    public String getProcAssignedUsername () {
        return procAssignedUsername;
    }

    public void setProcAssignedUsername ( String procAssignedUsername ) {
        this.procAssignedUsername = procAssignedUsername;
    }

    public String getBoAssignedUsername () {
        return boAssignedUsername;
    }

    public void setBoAssignedUsername ( String boAssignedUsername ) {
        this.boAssignedUsername = boAssignedUsername;
    }

    public String getProcAssignedTime () {
        return procAssignedTime;
    }

    public void setProcAssignedTime ( String procAssignedTime ) {
        this.procAssignedTime = procAssignedTime;
    }

    public ScopingQuestions getScopingQuestions () {
        return scopingQuestions;
    }

    public String getRiskAssessmentStatusColor () {
        return riskAssessmentStatusColor;
    }

    public void setRiskAssessmentStatusColor ( String riskAssessmentStatusColor ) {
        this.riskAssessmentStatusColor = riskAssessmentStatusColor;
    }

}
