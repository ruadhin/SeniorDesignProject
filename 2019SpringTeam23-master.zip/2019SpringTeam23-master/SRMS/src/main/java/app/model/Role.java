package app.model;

import java.util.Collection;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document ( collection = "Roles" )
public class Role {

    /**
     * ID of role, potentially used for comparing roles in future
     */
    @Id
    private String                id;
    /**
     * Name of role
     */
    private String                name;
    /**
     * Boolean for if the role is a Merck employee, potentially used for similar
     * views between roles
     */
    private boolean               merckEmployee;
    /**
     * Users associated with a role
     */
    private Collection<User>      users;
    /**
     * Privileges associated with a role
     */
    private Collection<Privilege> privileges;

    /**
     * Constructor for role
     *
     * @param name
     *            of role
     * @param merckEmployee
     *            if role is Merck employee
     */
    public Role ( final String id, final String name, final boolean merckEmployee ) {
        this.id = id;
        this.name = name;
        this.merckEmployee = merckEmployee;
    }

    /**
     * Default constructor
     */
    public Role () {
        super();
    }

    /**
     * Constructor that takes only a name
     *
     * @param name
     *            Name of role
     */
    public Role ( final String name ) {
        this.name = name;
    }

    /**
     * Gets the ID of the role
     *
     * @return id of role as a long integer
     */
    public String getId () {
        return id;
    }

    /**
     * Gets the name of role
     *
     * @return name of role
     */
    public String getName () {
        return name;
    }

    /**
     * Checks if the role is a Merck employee
     *
     * @return merckEmployee
     */
    public boolean isMerckEmployee () {
        return merckEmployee;
    }

    /**
     * @return the users
     */
    public Collection<User> getUsers () {
        return users;
    }

    /**
     * @param users
     *            the users to set
     */
    public void setUsers ( Collection<User> users ) {
        this.users = users;
    }

    /**
     * @return the privileges
     */
    public Collection<Privilege> getPrivileges () {
        return privileges;
    }

    /**
     * @param privileges
     *            the privileges to set
     */
    public void setPrivileges ( Collection<Privilege> privileges ) {
        this.privileges = privileges;
    }

}
