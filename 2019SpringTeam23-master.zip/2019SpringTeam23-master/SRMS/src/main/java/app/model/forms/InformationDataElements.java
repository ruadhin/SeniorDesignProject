package app.model.forms;

import java.util.List;

public class InformationDataElements {

    private List<String> confidentialInfo;
    private String       confidentialInfoOther;
    private String       confidentialInfoOtherText;
    private List<String> merckInfo;
    private String       merckNetwork;
    private String       networkInfo;
    private String       networkInfoOtherText;
    private List<String> generalInfo;
    private List<String> governmentInfo;
    private List<String> financialInfo;
    private List<String> sensitiveInfo;
    private List<String> technicalIdentifiers;
    private List<String> biometricIdentifiers;
    private List<String> whoseInformation;
    private String       whoseInformationOther;
    private String       whoseInformationOtherText;
    private List<String> countriesOfResidence;
    private String       countriesOfResidenceOthers;
    private String       countriesOfResidenceOthersText;
    private String       numberOfRecords;
    
    public boolean isComplete () {
        if ( generalInfo == null || governmentInfo == null || financialInfo == null || sensitiveInfo == null
                || technicalIdentifiers == null || biometricIdentifiers == null || biometricIdentifiers == null
                || whoseInformation == null || countriesOfResidence == null || numberOfRecords == null || merckNetwork == null) {
            return false;
        }
        if (merckInfo.isEmpty() || generalInfo.isEmpty() || governmentInfo.isEmpty() || financialInfo.isEmpty() 
        		|| sensitiveInfo.isEmpty() || technicalIdentifiers.isEmpty() || biometricIdentifiers.isEmpty()) {
        	return false;
        }
        
        if (confidentialInfoOther == null || confidentialInfoOther.isEmpty()) {
        	if ((confidentialInfo == null || confidentialInfo.isEmpty())) {
        		return false;
        	}
        } else if (confidentialInfoOtherText == null || confidentialInfoOtherText.isEmpty()) {
        	return false;
        }
    	
    	if (merckNetwork.equals("Yes")) {
    		if (networkInfo == null) {
    			return false;
    		}
        	if (networkInfo.equals("Other") && (networkInfoOtherText == null || networkInfoOtherText.isEmpty())) {
        		return false;
        	}
    	}
        if (whoseInformationOther == null || whoseInformationOther.isEmpty()) {
        	if ((whoseInformation == null || whoseInformation.isEmpty())) {
        		return false;
        	}
        } else if (whoseInformationOtherText == null || whoseInformationOtherText.isEmpty()) {
        	return false;
        } 
        if (countriesOfResidenceOthers == null || countriesOfResidenceOthers.isEmpty()) {
        	if ((countriesOfResidence == null || countriesOfResidence.isEmpty())) {
        		return false;
        	}
        } else if (countriesOfResidenceOthersText == null || countriesOfResidenceOthersText.isEmpty()) {
        	return false;
        }
        return true;
    }

    public InformationDataElements () {

    }

    public List<String> getConfidentialInfo () {
        return confidentialInfo;
    }

    public void setConfidentialInfo ( List<String> confidentialInfo ) {
        this.confidentialInfo = confidentialInfo;
    }

    /**
     * @return the confidentialInfoOther
     */
    public String getConfidentialInfoOther () {
        return confidentialInfoOther;
    }

    /**
     * @param confidentialInfoOther
     *            the confidentialInfoOther to set
     */
    public void setConfidentialInfoOther ( String confidentialInfoOther ) {
        this.confidentialInfoOther = confidentialInfoOther;
    }

    /**
     * @return the confidentialInfoOtherText
     */
    public String getConfidentialInfoOtherText () {
        return confidentialInfoOtherText;
    }

    /**
     * @param confidentialInfoOtherText
     *            the confidentialInfoOtherText to set
     */
    public void setConfidentialInfoOtherText ( String confidentialInfoOtherText ) {
        this.confidentialInfoOtherText = confidentialInfoOtherText;
    }

    public List<String> getMerckInfo () {
        return merckInfo;
    }

    public void setMerckInfo ( List<String> merckInfo ) {
        this.merckInfo = merckInfo;
    }

    public String getMerckNetwork () {
        return merckNetwork;
    }

    public void setMerckNetwork ( String merckNetwork ) {
        this.merckNetwork = merckNetwork;
    }

    public String getNetworkInfo () {
        return networkInfo;
    }

    public void setNetworkInfo ( String networkInfo ) {
        this.networkInfo = networkInfo;
    }

    public String getNetworkInfoOtherText () {
        return networkInfoOtherText;
    }

    public void setNetworkInfoOtherText ( String networkInfoOtherText ) {
        this.networkInfoOtherText = networkInfoOtherText;
    }

    public List<String> getGeneralInfo () {
        return generalInfo;
    }

    public void setGeneralInfo ( List<String> generalInfo ) {
        this.generalInfo = generalInfo;
    }

    public List<String> getGovernmentInfo () {
        return governmentInfo;
    }

    public void setGovernmentInfo ( List<String> governmentInfo ) {
        this.governmentInfo = governmentInfo;
    }

    public List<String> getFinancialInfo () {
        return financialInfo;
    }

    public void setFinancialInfo ( List<String> financialInfo ) {
        this.financialInfo = financialInfo;
    }

    public List<String> getSensitiveInfo () {
        return sensitiveInfo;
    }

    public void setSensitiveInfo ( List<String> sensitiveInfo ) {
        this.sensitiveInfo = sensitiveInfo;
    }

    public List<String> getTechnicalIdentifiers () {
        return technicalIdentifiers;
    }

    public void setTechnicalIdentifiers ( List<String> technicalIdentifiers ) {
        this.technicalIdentifiers = technicalIdentifiers;
    }

    public List<String> getBiometricIdentifiers () {
        return biometricIdentifiers;
    }

    public void setBiometricIdentifiers ( List<String> biometricIdentifiers ) {
        this.biometricIdentifiers = biometricIdentifiers;
    }

    public List<String> getWhoseInformation () {
        return whoseInformation;
    }

    public void setWhoseInformation ( List<String> whoseInformation ) {
        this.whoseInformation = whoseInformation;
    }

    public String getWhoseInformationOther () {
        return whoseInformationOther;
    }

    public void setWhoseInformationOther ( String whoseInformationOther ) {
        this.whoseInformationOther = whoseInformationOther;
    }

    public String getWhoseInformationOtherText () {
        return whoseInformationOtherText;
    }

    public void setWhoseInformationOtherText ( String whoseInformationOtherText ) {
        this.whoseInformationOtherText = whoseInformationOtherText;
    }

    public List<String> getCountriesOfResidence () {
        return countriesOfResidence;
    }

    public void setCountriesOfResidence ( List<String> countriesOfResidence ) {
        this.countriesOfResidence = countriesOfResidence;
    }

    public String getCountriesOfResidenceOthers () {
        return countriesOfResidenceOthers;
    }

    public void setCountriesOfResidenceOthers ( String countriesOfResidenceOthers ) {
        this.countriesOfResidenceOthers = countriesOfResidenceOthers;
    }

    public String getCountriesOfResidenceOthersText () {
        return countriesOfResidenceOthersText;
    }

    public void setCountriesOfResidenceOthersText ( String countriesOfResidenceOthersText ) {
        this.countriesOfResidenceOthersText = countriesOfResidenceOthersText;
    }

    public String getNumberOfRecords () {
        return numberOfRecords;
    }

    public void setNumberOfRecords ( String numberOfRecords ) {
        this.numberOfRecords = numberOfRecords;
    }

}
