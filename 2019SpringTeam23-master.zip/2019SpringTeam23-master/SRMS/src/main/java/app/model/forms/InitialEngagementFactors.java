package app.model.forms;

import java.util.List;

public class InitialEngagementFactors {

    private List<String> serviceType;
    private String       serviceTypeOther;
    private String       serviceTypeOtherText;
    private String       cloudHosted;
    private String       cloudProvider;
    private String       cloudProviderOtherText;
    private String       approval;
    private String       approvalDate;

    public InitialEngagementFactors () {
    	
    }

    public List<String> getServiceType () {
        return serviceType;
    }

    public void setServiceType ( List<String> serviceType ) {
        this.serviceType = serviceType;
    }

    public String getServiceTypeOther () {
        return serviceTypeOther;
    }

    public void setServiceTypeOther ( String serviceTypeOther ) {
        this.serviceTypeOther = serviceTypeOther;
    }

    public String getServiceTypeOtherText () {
        return serviceTypeOtherText;
    }

    public void setServiceTypeOtherText ( String serviceTypeOtherText ) {
        this.serviceTypeOtherText = serviceTypeOtherText;
    }

    public String getCloudHosted () {
        return cloudHosted;
    }

    public void setCloudHosted ( String cloudHosted ) {
        this.cloudHosted = cloudHosted;
    }

    public String getCloudProvider () {
        return cloudProvider;
    }

    public void setCloudProvider ( String cloudProvider ) {
        this.cloudProvider = cloudProvider;
    }

    public String getCloudProviderOtherText () {
        return cloudProviderOtherText;
    }

    public void setCloudProviderOtherText ( String cloudProviderOtherText ) {
        this.cloudProviderOtherText = cloudProviderOtherText;
    }

    public String getApproval () {
        return approval;
    }

    public void setApproval ( String approval ) {
        this.approval = approval;
    }

    public String getApprovalDate () {
        return approvalDate;
    }

    public void setApprovalDate ( String approvalDate ) {
        this.approvalDate = approvalDate;
    }

    public boolean isComplete () {
        if ( (serviceType == null || serviceType.isEmpty()) && (serviceTypeOther == null || serviceTypeOther.isEmpty())) {
            return false;
        }
        if ( serviceTypeOther != null && (serviceTypeOtherText == null || serviceTypeOtherText.isEmpty()) ) {
            return false;
        }
        if ( cloudHosted == null ) {
            return false;
        }
        if ( cloudHosted.equals( "Yes" ) ) {
            if ( cloudProvider == null || approval == null || approvalDate == null ) {
                return false;
            }
            if ( cloudProvider.equals( "Other" ) && cloudProviderOtherText == null ) {
                return false;
            }
        }
        return true;
    }

}
