package app.model.forms;

public class SeverityRiskQuestions {

    private String financial;
    private String reputational;
    private String legalRegulatoryContractual;
    private String customerOperational;

    public SeverityRiskQuestions () {
    	
    }

    public String getFinancial () {
        return financial;
    }

    public void setFinancial ( String financial ) {
        this.financial = financial;
    }

    public String getReputational () {
        return reputational;
    }

    public void setReputational ( String reputational ) {
        this.reputational = reputational;
    }

    public String getLegalRegulatoryContractual () {
        return legalRegulatoryContractual;
    }

    public void setLegalRegulatoryContractual ( String legalRegulatoryContractual ) {
        this.legalRegulatoryContractual = legalRegulatoryContractual;
    }

    public String getCustomerOperational () {
        return customerOperational;
    }

    public void setCustomerOperational ( String customerOperational ) {
        this.customerOperational = customerOperational;
    }

    public boolean isComplete () {
        if ( financial == null || reputational == null || legalRegulatoryContractual == null
                || customerOperational == null ) {
            return false;
        }
        return true;
    }

}
