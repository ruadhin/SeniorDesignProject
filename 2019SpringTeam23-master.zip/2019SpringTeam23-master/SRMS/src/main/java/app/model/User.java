package app.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Representation model for users used for authorization/authentication in the
 * system. Based on
 * https://www.baeldung.com/role-and-privilege-for-spring-security-registration
 *
 * @author Matt
 * @author Gabriel Gloss
 *
 */
@Document ( collection = "Users" )
public class User {

    /**
     * Used for creating auto-generated data like ID
     */
    @Transient
    public static final String SEQUENCE_NAME = "users_sequence";

    /**
     * ID of user, for database
     */
    @Id
    private String             id;
    /**
     * Username of the user
     */
    private String             username;
    /**
     * Password of the user
     */
    private String             password;
    /**
     * First name of the user
     */
    private String             firstName;
    /**
     * Last name of the user
     */
    private String             lastName;
    /**
     * Email address of the user
     */
    private String             email;
    /**
     * Roles of the user
     */
    private Collection<Role>   roles;
    /**
     * Determines whether account is enabled.
     */
    private boolean            enabled;
    /**
     * Determines whether account is expired.
     */
    private boolean            accountNonExpired;
    /**
     * Determines whether account is locked.
     */
    private boolean            accountNonLocked;
    /**
     * Determines whether credentials are expired.
     */
    private boolean            credentialsNonExpired;
    /**
     * List of Supplier IDs associated with a user IMPORTANT DESIGN NOTE: If the
     * user is a supplier side user (Account Manager or Information Supplier)
     * this List will be of size 1 with the relevant identifying Supplier ID.
     * Merck employees can be associated with multiple suppliers and the List
     * size may or may not be greater than 1 for employees.
     */
    private List<String>       supplierIds;

    /**
     * Empty constructor needed for MongoDB
     */
    public User () {
        this.enabled = true;
        this.accountNonExpired = true;
        this.accountNonLocked = true;
        this.credentialsNonExpired = true;
        supplierIds = new ArrayList<String>();
    }

    /**
     * Generic constructor to create user given all fields
     *
     * @param username
     *            of user
     * @param password
     *            of user
     * @param role
     *            of user
     */
    public User ( final String username, final String password, final Collection<Role> roles ) {
        this.username = username;
        this.password = password;
        this.roles = roles;
        this.enabled = true;
        this.accountNonExpired = true;
        this.accountNonLocked = true;
        this.credentialsNonExpired = true;
    }

    /**
     * Gets the ID of the user
     *
     * @return id of user
     */
    public String getID () {
        return id;
    }

    /**
     * Sets the ID of user
     *
     * @param id
     *            of user
     */
    @Autowired
    public void setID ( final String id ) {
        this.id = id;
    }

    /**
     * Gets the username of the user
     *
     * @return username of user
     */
    public String getUsername () {
        return username;
    }

    /**
     * Sets the username of the user
     *
     * @param username
     *            of user
     */
    public void setUsername ( final String username ) {
        this.username = username;
    }

    /**
     * Gets the password of the user
     *
     * @return password of user
     */
    public String getPassword () {
        return password;
    }

    /**
     * Sets the password of the user
     *
     * @param password
     *            of user
     */
    public void setPassword ( final String password ) {
        this.password = password;
    }

    /**
     * Gets the roles of the user
     *
     * @return roles of user
     */
    public Collection<Role> getRoles () {
        return roles;
    }

    /**
     * Sets the role of user
     *
     * @param role
     *            User role to set
     */
    public void setRoles ( final Collection<Role> roles ) {
        this.roles = roles;
    }

    /**
     * Gets the first name of this User object
     *
     * @return the first name as a String
     */
    public String getFirstName () {
        return firstName;
    }

    /**
     * Sets the first name of this User object
     *
     * @param first
     *            name the first name to set
     */
    public void setFirstName ( final String firstName ) {
        this.firstName = firstName;
    }

    /**
     * Gets the last name of this User object
     *
     * @return the last name as a String
     */
    public String getLastName () {
        return lastName;
    }

    /**
     * Sets the last name of this User object
     *
     * @param lastName
     *            the last name to set
     */
    public void setLastName ( final String lastName ) {
        this.lastName = lastName;
    }

    /**
     * Gets the email of this User object
     *
     * @return the email as a String
     */
    public String getEmail () {
        return email;
    }

    /**
     * Sets the email address of this User object
     *
     * @param email
     *            the email to set
     */
    public void setEmail ( final String email ) {
        this.email = email;
    }

    /**
     * Determines whether this user account is enabled.
     *
     * @return True or False
     */
    public boolean isEnabled () {
        return this.enabled;
    }

    /**
     * Determines whether this user account is expired.
     *
     * @return True or False
     */
    public boolean isAccountNonExpired () {
        return this.accountNonExpired;
    }

    /**
     * Determines whether this user account is locked.
     *
     * @return True or False
     */
    public boolean isAccountNonLocked () {
        return this.accountNonLocked;
    }

    /**
     * Determines whether this user account's credentials are expired.
     *
     * @return True or False
     */
    public boolean isCredentialsNonExpired () {
        return this.credentialsNonExpired;
    }

    public List<String> getSupplierIds () {
        return supplierIds;
    }

    public void addSupplier ( String id ) {
        this.supplierIds.add( id );
    }

    /**
     * Returns some fields of this user
     *
     * @return Fields of this User object
     */
    @Override
    public String toString () {
        return this.getUsername() + ":" + this.getID() + ":" + this.getEmail() + ":" + this.getFirstName() + ":"
                + this.getLastName();
    }

}
