/**
 *
 */
package app.model;

import java.util.Collection;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Used for authorization throughout SRMS. Reference:
 * https://www.baeldung.com/role-and-privilege-for-spring-security-registration
 *
 * @author Gabriel Gloss
 *
 */
@Document ( collection = "Privileges" )
public class Privilege {
	
    public static final String ADMIN       = "ADMIN";
    public static final String PROCUREMENT_ANALYST       = "PROCUREMENT_ANALYST";
    public static final String BUSINESS_OWNER        = "BUSINESS_OWNER";
    public static final String RISK_ANALYST        = "RISK_ANALYST";
    public static final String ACCOUNT_MANAGER         = "ACCOUNT_MANAGER";
    public static final String INFORMATION_SUPPLIER        = "INFORMATION_SUPPLIER";

    /**
     * ID that uniquely identifies this privilege
     */
    @Id
    private String           id;

    /**
     * Name of the privilege
     */
    private String           name;

    /**
     * Roles mapped to this privilege
     */
    private Collection<Role> roles;

    /**
     * Default constructor
     */
    public Privilege () {
        super();
    }

    /**
     * Constructor with privilege name as parameter
     *
     * @param name
     *            String with name of the privilege
     */
    public Privilege ( String name ) {
        super();
        this.name = name;
    }

    /**
     * @return the id
     */
    public String getId () {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId ( String id ) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName () {
        return name;
    }

    /**
     * @param name
     *            the name to set
     */
    public void setName ( String name ) {
        this.name = name;
    }

    /**
     * @return the roles
     */
    public Collection<Role> getRoles () {
        return roles;
    }

    /**
     * @param roles
     *            the roles to set
     */
    public void setRoles ( Collection<Role> roles ) {
        this.roles = roles;
    }

}
