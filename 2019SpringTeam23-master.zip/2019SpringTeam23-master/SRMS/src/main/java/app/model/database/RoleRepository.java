package app.model.database;

import org.springframework.data.mongodb.repository.MongoRepository;

import app.model.Role;

public interface RoleRepository extends MongoRepository<Role, String> {

    public Role findByName ( String name );

    @Override
    void delete ( Role role );

}
