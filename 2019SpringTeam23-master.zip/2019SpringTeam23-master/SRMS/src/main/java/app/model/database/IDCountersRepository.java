package app.model.database;

import org.springframework.data.mongodb.repository.MongoRepository;

import app.util.IDCounter;

public interface IDCountersRepository extends MongoRepository<IDCounter, String> {

}
