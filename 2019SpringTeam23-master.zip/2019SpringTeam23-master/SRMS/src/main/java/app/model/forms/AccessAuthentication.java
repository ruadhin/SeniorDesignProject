package app.model.forms;

public class AccessAuthentication {

    private String accessMethod;
    private String accessMethodOtherText;
    private String webAddress;
    private String authenticationMethod;
    private String dataIntegrity;
    private String customerPublicAccess;
    private String brandImage;

    public AccessAuthentication () {

    }

    public String getAccessMethod () {
        return accessMethod;
    }

    public void setAccessMethod ( String accessMethod ) {
        this.accessMethod = accessMethod;
    }

    public String getAccessMethodOtherText () {
        return accessMethodOtherText;
    }

    public void setAccessMethodOtherText ( String accessMethodOtherText ) {
        this.accessMethodOtherText = accessMethodOtherText;
    }

    public String getWebAddress () {
        return webAddress;
    }

    public void setWebAddress ( String webAddress ) {
        this.webAddress = webAddress;
    }

    public String getAuthenticationMethod () {
        return authenticationMethod;
    }

    public void setAuthenticationMethod ( String authenticationMethod ) {
        this.authenticationMethod = authenticationMethod;
    }

    public String getDataIntegrity () {
        return dataIntegrity;
    }

    public void setDataIntegrity ( String dataIntegrity ) {
        this.dataIntegrity = dataIntegrity;
    }

    public String getCustomerPublicAccess () {
        return customerPublicAccess;
    }

    public void setCustomerPublicAccess ( String customerPublicAccess ) {
        this.customerPublicAccess = customerPublicAccess;
    }

    public String getBrandImage () {
        return brandImage;
    }

    public void setBrandImage ( String brandImage ) {
        this.brandImage = brandImage;
    }

    public boolean isComplete () {
        if ( accessMethod == null || webAddress == null || webAddress.isEmpty() || authenticationMethod == null
                || dataIntegrity == null || customerPublicAccess == null || brandImage == null) {
            return false;
        }
        if (accessMethod.equals("Other") && (accessMethodOtherText == null || accessMethodOtherText.isEmpty())) {
        	return false;
        }
        return true;
    }

}
