package app.model.database;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import app.model.Notification;

public interface NotificationRepository extends MongoRepository<Notification, String> {
    List<Notification> getBySender ( String sender );

    List<Notification> getByReceiver ( String receiver );

}
