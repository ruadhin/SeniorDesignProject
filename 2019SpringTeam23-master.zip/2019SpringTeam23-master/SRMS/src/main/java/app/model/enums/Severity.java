package app.model.enums;

public enum Severity {
	
	MINOR(1),
	MODERATE(2),
	ADVERSE(3),
	SIGNIFICANT(4),
	SEVERE(5);
	
	public final int value;
	
	private Severity(int value) {
		this.value = value;
	}

}
