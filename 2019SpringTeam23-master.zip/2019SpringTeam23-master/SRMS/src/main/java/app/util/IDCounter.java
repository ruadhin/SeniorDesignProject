package app.util;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document ( collection = "IDCounter" )
public class IDCounter {

    @Id
    private String id = "0";
    private long   supplierIdCounter;
    private long   userIdCounter;
    private long   projectIdCounter;
    private long notificationIdCounter;

    public long getSupplierIdCounter () {
        return supplierIdCounter;
    }

    public void setSupplierIdCounter ( long supplierIdCounter ) {
        this.supplierIdCounter = supplierIdCounter;
    }

    public long getUserIdCounter () {
        return userIdCounter;
    }

    public void setUserIdCounter ( long userIdCounter ) {
        this.userIdCounter = userIdCounter;
    }

    public long getProjectIdCounter () {
        return projectIdCounter;
    }

    public void setProjectIdCounter ( long projectIdCounter ) {
        this.projectIdCounter = projectIdCounter;
    }
  
  	public long getNotificationIdCounter() {
		  return notificationIdCounter;
	  }
	
	  public void setNotificationIdCounter(long msgIdCounter) {
		  this.notificationIdCounter = msgIdCounter;
	  }

}
