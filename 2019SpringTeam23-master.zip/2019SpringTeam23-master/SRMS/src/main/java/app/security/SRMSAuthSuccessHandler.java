package app.security;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.WebAttributes;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

// from Spring tutorials: https://www.baeldung.com/spring_redirect_after_login
// @author Gabriel Gloss
@Component
public class SRMSAuthSuccessHandler implements AuthenticationSuccessHandler {

    protected Log            logger           = LogFactory.getLog( this.getClass() );

    private RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();

    @Override
    public void onAuthenticationSuccess ( final HttpServletRequest req, final HttpServletResponse resp,
            final Authentication auth ) throws IOException, ServletException {
        handle( req, resp, auth );
        clearAuthAttributes( req );
    }

    protected void handle ( final HttpServletRequest req, final HttpServletResponse resp, final Authentication auth )
            throws IOException, ServletException {

        final String targetUrl = determineTargetUrl( auth );

        if ( resp.isCommitted() ) {
            logger.debug( "Unable to redirect to " + targetUrl );
            return;
        }

        redirectStrategy.sendRedirect( req, resp, targetUrl );
    }

    protected String determineTargetUrl ( final Authentication auth ) {
        // admin
        boolean isAdmin = false;
        // procurement analyst
        boolean isProc = false;
        // account manager
        boolean isAccMan = false;
        // business owner
        boolean isBusOwner = false;
        // information supplier
        boolean isInfSup = false;
        // risk analyst
        boolean isRiskAnalyst = false;

        // System.out.println( "DEBUG REACHED THIS CODE BLOCK" );
        final Collection< ? extends GrantedAuthority> authorities = auth.getAuthorities();
        // System.out.println( "AUTHORITIES COLLECTION SIZE:" +
        // authorities.size() );
        for ( final GrantedAuthority grantedAuthority : authorities ) {
            // System.out.println( "DEBUG ROLE AUTHORITY 2: " +
            // grantedAuthority.getAuthority() );
            if ( grantedAuthority.getAuthority().equals( "PROCUREMENT_ANALYST" ) ) {
                isProc = true;
                break;
            }
            else if ( grantedAuthority.getAuthority().equals( "ACCOUNT_MANAGER" ) ) {
                isAccMan = true;
                break;
            }
            else if ( grantedAuthority.getAuthority().equals( "BUSINESS_OWNER" ) ) {
                isBusOwner = true;
                break;
            }
            else if ( grantedAuthority.getAuthority().equals( "INFORMATION_SUPPLIER" ) ) {
                isInfSup = true;
                break;
            }
            else if ( grantedAuthority.getAuthority().equals( "RISK_ANALYST" ) ) {
                isRiskAnalyst = true;
                break;
            }
            else if ( grantedAuthority.getAuthority().equals( "ADMIN" ) ) {
                isAdmin = true;
                break;
            }
        }

        if ( isProc ) {
            return "/proc/proc_index";
        }
        else if ( isAccMan ) {
            return "/accman/accman_index";
        }
        else if ( isBusOwner ) {
            return "/busowner/busowner_index";
        }
        else if ( isInfSup ) {
            return "/infsup/infsup_index";
        }
        else if ( isRiskAnalyst ) {
            return "/itrma/itrma_index";
        }
        else if ( isAdmin ) {
            return "/admin/admin_index";
        }
        else {
            throw new IllegalStateException();
        }
    }

    protected void clearAuthAttributes ( final HttpServletRequest req ) {
        final HttpSession sess = req.getSession( false );
        if ( sess == null ) {
            return;
        }
        sess.removeAttribute( WebAttributes.AUTHENTICATION_EXCEPTION );
    }

    public void setRedirectStrategy ( final RedirectStrategy redirectStrategy ) {
        this.redirectStrategy = redirectStrategy;
    }

    protected RedirectStrategy getRedirectStrategy () {
        return redirectStrategy;
    }

}
