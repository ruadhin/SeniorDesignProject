// Partially from http://next.plnkr.co/edit/mUMZ0VGO8l1ufV1JJNQE?p=preview&utm_source=legacy&utm_medium=worker&utm_campaign=next&preview
var myItemsApp = angular.module('NotificationsApp', []);

myItemsApp.factory('itemsFactory', ['$http', function($http){
  var itemsFactory ={
    itemDetails: function() {
      return $http(
      {
        url: "/notifications/getNotificationsForCurrentUser",
        method: "GET",
      })
      .then(function (response) {
        return response.data;
        });
      }
    };
    return itemsFactory;
  
}]);


myItemsApp.controller('NotificationsController', ['$scope', 'itemsFactory', '$window', function($scope, itemsFactory, $window){
	$scope.isActive = function(route) {
		//console.log('isActive function was run');
		//console.log(route);
		var currentUrl = $window.location.href;
		var urlParts = currentUrl.split("/")
		//console.log(urlParts);
		//console.log(urlParts[5] == route)
		return urlParts[5] == route;
	};
	$scope.customSearchFilter = function(row) {
		var lowercased = $scope.inboxSearch;
		if ( $scope.inboxSearch != null ) {
			lowercased = $scope.inboxSearch.toLowerCase();
		}
		//console.log( lowercased );
		//console.log( $scope.inboxSearch );
		//console.log( $scope.inboxSearch == null );
		//console.log( 'Executed custom search filter' );
		//console.log( row );
		return !!((row.sender.toLowerCase().indexOf(lowercased || '') !== -1 || row.subject.toLowerCase().indexOf(lowercased || '') !== -1 || row.notificationTimeReadable.indexOf(lowercased || '') !== -1));
	};
  var promise = itemsFactory.itemDetails();

    promise.then(function (data) {
        $scope.usersNotifications = data;
        //console.log(data);
    });
    $scope.select = function(item) {
      $scope.selected = item;
    }
    $scope.selected = {};
}]);