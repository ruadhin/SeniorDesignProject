var myApp = angular.module('scopingFormsApp', []);

myApp.controller('FormsController', function($scope) {
  
  $scope.form = {
    state: {},
    data: {}
  };
  
  $scope.saveForm = (function() {
	  console.log('Saving form data ...', $scope.form.data);
	  var docForm = document.getElementById('severity_form');
	  console.log( docForm );
	  docForm.submit();
//	  var method = docForm.attr('method').toLowerCase();
//	  var action = $(docForm).attr('action');
//	  console.log(action);
//	  $[method](action, docForm.serialize(), function(data) {
//		  console.log( data );
//	  });
//	  docForm.submit(function() {
//	        $.ajax({
//	            type: 'POST',
//	            url: '/supplier/submitScoping/severityRiskQuestions',
//	            data: $(this).serialize(),
//	            error: function()
//	            {
//	               console.log("Request Failed");
//	            },
//	            success: function(response)
//	            {  
//	            	console.log("Request Successful");
//	            }
//	        });
//	        return false;
//	    }); 
	})
  
});

myApp.directive('autoSaveForm', function($timeout) {
  
  return {
    require: ['^form'],
    link: function($scope, $element, $attrs, $ctrls) {
      
      var $formCtrl = $ctrls[0];
      var savePromise = null;
      var expression = $attrs.autoSaveForm || 'true';
      
      $scope.$watch(function() {
        
        if($formCtrl.$valid && $formCtrl.$dirty) {
          
          if(savePromise) {
            $timeout.cancel(savePromise);
          }
          
          savePromise = $timeout(function() {
            
            savePromise = null;
            
            // Still valid?
            
            if($formCtrl.$valid) {
              
              if($scope.$eval(expression) !== false) {
                console.log('Form data persisted -- setting pristine flag');
                $formCtrl.$setPristine();  
              }
            
            }
            
          }, 500);
        }
        
      });
    }
  };
  
});
