var app = angular.module('TableApp', ['ngTouch', 'ui.bootstrap', 'ui.grid']);

app.controller('TableCtrl', [
'$scope', '$http', '$window', 'uiGridConstants', function($scope, $http, $window, uiGridConstants) {
 
  this.highlightFilteredHeader = function( row, rowRenderIndex, col, colRenderIndex ) {
	  if( col.filters[0].term ){
	      return 'header-filtered';
	    } else {
	      return '';
	    }
  };
  
  //console.log($window.location.search);
  if ( $window.location.search == "?filter=critical" ) {
	  $scope.filterTerm = 'Critical';
  } else if ( $window.location.search == "?filter=high" ) {
	  $scope.filterTerm = 'High';
  } else if ( $window.location.search == "?filter=medium" ) {
	  $scope.filterTerm = 'Medium';
  } else if ( $window.location.search == "?filter=low" ) {
	  $scope.filterTerm = 'Low';
  } else if ( $window.location.search == "?filter=InProgress" ) {
	  $scope.filterTerm = 'In Progress';
  } else {
	  $scope.filterTerm = null;
  }
  
  $scope.gridOptions = {
    data: 'gridOptions.data',
    enableHorizontalScrollbar: 0,
    enableVerticalScrollbar: 0,
    //minimumColumnSize: 200,
    rowHeight: 50,
	enableFiltering: true,
    columnDefs: [
      { field: 'id', displayName: 'ID', cellTemplate: '<div class="ui-grid-solo">{{row.entity.id}}</div>', headerCellClass: this.highlightFilteredHeader, name: 'id', enableSorting: true },
      { field: 'name', cellTemplate: '<div class="ui-grid-solo-button"><a ng-href="/projects?supplierName={{row.entity.name}}"><button type="button" class="btn btn-primary supplierTableButtons"><b><font color="lightgray">{{row.entity.name}}</font></b></button></a></div>', headerCellClass: this.highlightFilteredHeader, name: 'name', enableSorting: true },
      { field: 'parentCompany', cellTemplate: '<div class="ui-grid-solo">{{row.entity.parentCompany}}</div>', headerCellClass: this.highlightFilteredHeader, name: 'parentCompany', enableSorting: true },
      { field: 'duns', cellTemplate: '<div class="ui-grid-solo">{{row.entity.duns}}</div>', displayName: 'DUNS', type: 'number', headerCellClass: this.highlightFilteredHeader, name: 'duns', enableSorting: true },
      { field: 'riskRating', cellTemplate: '<div class="ui-grid-solo-button"><a ng-href="/shared_views/check_override/{{row.entity.id}}"><button type="button" class="btn btn-primary supplierTableButtons"><b><font color="{{row.entity.riskRatingColor}}">{{row.entity.riskRating}}</font></b></button></a></div>', displayName: 'Risk Assessment Score', headerCellClass: this.highlightFilteredHeader, name: 'riskRating', enableSorting: true, filter: {
    	  term: $scope.filterTerm,
    	  type: uiGridConstants.filter.SELECT,
    	  selectOptions: [ { value: 'Critical', label: 'Critical'}, { value: 'High', label: 'High'}, { value: 'Medium', label: 'Medium'}, { value: 'Low', label: 'Low'}, { value: 'In Progress', label: 'In Progress'} ]
      } },
      { field: 'riskAssessmentStatus', cellTemplate: '<div class="ui-grid-solo"><uib-progressbar value="row.entity.riskAssessmentStatus"  type="{{row.entity.riskAssessmentStatusColor}}" animate="false"><font color="black"><b>{{row.entity.riskAssessmentStatus}}</b>%</font></uib-progressbar></div>', displayName: 'Risk Assessment Status', headerCellClass: this.highlightFilteredHeader, type: 'number', name: 'riskAssessmentStatus', enableSorting: true, filters: [
    	  {
    		  condition: uiGridConstants.filter.GREATER_THAN_OR_EQUAL,
    		  placeholder: 'Greater Than Or Equal'
    	  },
    	  {
    		  condition: uiGridConstants.filter.LESS_THAN_OR_EQUAL,
    		  placeholder: 'Less Than Or Equal'
    	  }
      ] }
    ]
  };
 
  $http.get('/supplier/getSuppliersFromUser')
  .then(function (response) {
    var data = response.data;
    //console.log( data );
    $scope.gridOptions.data = data;
  });
  
  $http.get('/supplierTable/getLoggedInRole')
  .then(function (response) {
	//$scope.loggedInRole = response.data.role;
    //console.log( response.data );
    //console.log( response.data.role );
    //console.log( response );
	if ( response.data.role == 'RISK_ANALYST' ) {
		$scope.gridOptions.columnDefs.push({ name: 'override', displayName: 'Override Risk Score', cellTemplate: '<div class="ui-grid-solo-button"><a ng-href="/itrma/override_score/{{row.entity.id}}"><button ng-disabled="!row.entity.overrideable" type="button" class="btn btn-danger supplierTableButtons"><b><font color="black">Override Score</font></b></button></a></div>', enableSorting: false, enableFiltering: false });
		//$scope.gridOptions.columnDefs.push({ field: 'overrideable', cellTemplate: "<div>{{row.entity.overrideable ? 'true' : 'false'}}</div>", displayName: 'Overrideable', headerCellClass: this.highlightFilteredHeader, name: 'overrideable', enableSorting: false, enableFiltering: false });
		//$scope.gridOptions.columnDefs.push({ field: 'overrideable', cellTemplate: '<select class="btn btn-default column-12"  ng-disabled="!row.entity.overrideable" ng-input="COL_FIELD"  ng-model="row.entity.id"><option value="" selected="selected">Select</option><option value="styl_text">styl_text</option><option value="styl_number">styl_number</option><option value="styl_date">styl_date</option><option value="styl_ts">styl_ts</option></select>', displayName: 'Overrideable', headerCellClass: this.highlightFilteredHeader, name: 'overrideable', enableSorting: false, enableFiltering: false });
		for (var i = 0; i < $scope.gridOptions.columnDefs.length; i++) {
		    $scope.gridOptions.columnDefs[i].width = 226;
		}
		//console.log('Set column width to 226px');
		//$scope.gridOptions.minimumColumnSize = 100;
		//$scope.gridOptions.columnSize = 100;
	} else if ( response.data.role == 'PROCUREMENT_ANALYST' ) {
		$scope.gridOptions.columnDefs.push({ name: 'assign', displayName: 'Assign Business Owner', cellTemplate: '<div class="ui-grid-solo-button"><a ng-href="/proc/assign_bo/{{row.entity.id}}"><button ng-disabled="row.entity.assignedToBO" type="button" class="btn btn-danger supplierTableButtons"><b><font color="black">Assign</font></b></button></a></div>', enableSorting: false, enableFiltering: false });
		for (var i = 0; i < $scope.gridOptions.columnDefs.length; i++) {
		    $scope.gridOptions.columnDefs[i].width = 226;
		}
		//for (var i = 0; i < $scope.gridOptions.columnDefs.length; i++) {
		//    $scope.gridOptions.columnDefs[i].width = '20%';
		//}
		//console.log('Set column width to 20');
		//$scope.gridOptions.width = '16.5%';
		//$scope.gridOptions.minimumColumnSize = 200;
	}
  });
  
}
]);