var app = angular.module('ProjectTableApp', ['ngTouch', 'ui.grid']);

app.controller('ProjectTableCtrl', [
'$scope', '$http', '$window', 'uiGridConstants', function($scope, $http, $window, uiGridConstants) {
 
  this.highlightFilteredHeader = function( row, rowRenderIndex, col, colRenderIndex ) {
	  if( col.filters[0].term ){
	      return 'header-filtered';
	    } else {
	      return '';
	    }
  };
  
  $scope.gridOptions = {
    data: 'gridOptions.data',
    enableHorizontalScrollbar: 0,
    enableVerticalScrollbar: 0,
	enableFiltering: true,
	minimumColumnSize: 500,
	enableColumnResizing: true,
    columnDefs: [
      { field: 'id', displayName: 'ID', headerCellClass: this.highlightFilteredHeader, name: 'id', enableSorting: true, width: '*' },
      { field: 'name', displayName: 'Project Name', headerCellClass: this.highlightFilteredHeader, name: 'name', enableSorting: true, width: '*' },
      { field: 'description', displayName: 'Project Description', headerCellClass: this.highlightFilteredHeader, name: 'description', enableSorting: true, width: '*' }
    ]
  };
 
  $http.get('/supplier/getCurrentSupplierProjects')
  .then(function (response) {
    var data = response.data;
    //console.log( data );
    $scope.gridOptions.data = data;
  });
 
}
]);